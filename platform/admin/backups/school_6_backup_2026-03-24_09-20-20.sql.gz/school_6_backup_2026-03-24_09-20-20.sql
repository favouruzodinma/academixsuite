mysqldump: Deprecated program name. It will be removed in a future release, use '/usr/bin/mariadb-dump' instead
/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: school_6
-- ------------------------------------------------------
-- Server version	11.4.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `academic_terms`
--

DROP TABLE IF EXISTS `academic_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `academic_terms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `academic_year_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `campus_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_term_school` (`school_id`,`academic_year_id`,`name`),
  KEY `idx_school` (`school_id`),
  KEY `idx_year` (`academic_year_id`),
  KEY `idx_campus` (`campus_id`),
  CONSTRAINT `fk_academic_terms_campus` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academic_terms`
--

LOCK TABLES `academic_terms` WRITE;
/*!40000 ALTER TABLE `academic_terms` DISABLE KEYS */;
INSERT INTO `academic_terms` VALUES
(1,6,1,'first term','2025-09-08','2025-11-27',0,'2026-03-05 21:06:31',1),
(2,6,1,'second term','2026-01-05','2026-04-15',1,'2026-03-05 21:07:23',1);
/*!40000 ALTER TABLE `academic_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `academic_years`
--

DROP TABLE IF EXISTS `academic_years`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `academic_years` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `status` enum('upcoming','active','completed') DEFAULT 'upcoming',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `campus_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_year_school` (`school_id`,`name`),
  KEY `idx_school` (`school_id`),
  KEY `idx_status` (`status`),
  KEY `idx_campus` (`campus_id`),
  CONSTRAINT `fk_academic_years_campus` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academic_years`
--

LOCK TABLES `academic_years` WRITE;
/*!40000 ALTER TABLE `academic_years` DISABLE KEYS */;
INSERT INTO `academic_years` VALUES
(1,6,'2025-2026','2025-09-08','2026-07-24',1,'active','2026-03-03 13:57:33',1);
/*!40000 ALTER TABLE `academic_years` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admission_applications`
--

DROP TABLE IF EXISTS `admission_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admission_applications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `application_number` varchar(50) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` enum('male','female','other') NOT NULL,
  `nationality` varchar(100) DEFAULT NULL,
  `religion` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `applying_for_class_id` int(10) unsigned NOT NULL,
  `previous_school` varchar(255) DEFAULT NULL,
  `previous_class` varchar(100) DEFAULT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `father_phone` varchar(20) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `mother_phone` varchar(20) DEFAULT NULL,
  `guardian_name` varchar(255) DEFAULT NULL,
  `guardian_phone` varchar(20) DEFAULT NULL,
  `status` enum('pending','reviewed','accepted','rejected','waitlisted') DEFAULT 'pending',
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_application` (`school_id`,`application_number`),
  KEY `idx_status` (`status`),
  KEY `idx_class` (`applying_for_class_id`),
  KEY `idx_school_campus` (`school_id`,`campus_id`),
  CONSTRAINT `fk_admission_applications_class` FOREIGN KEY (`applying_for_class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admission_applications`
--

LOCK TABLES `admission_applications` WRITE;
/*!40000 ALTER TABLE `admission_applications` DISABLE KEYS */;
/*!40000 ALTER TABLE `admission_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admission_documents`
--

DROP TABLE IF EXISTS `admission_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admission_documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `application_id` int(10) unsigned NOT NULL,
  `document_type` varchar(100) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_application` (`application_id`),
  KEY `idx_school_campus` (`school_id`,`campus_id`),
  CONSTRAINT `fk_admission_documents_application` FOREIGN KEY (`application_id`) REFERENCES `admission_applications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admission_documents`
--

LOCK TABLES `admission_documents` WRITE;
/*!40000 ALTER TABLE `admission_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `admission_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alumni`
--

DROP TABLE IF EXISTS `alumni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumni` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned DEFAULT NULL COMMENT 'If they were a student in the system',
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `graduation_year` year(4) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `profile_photo` varchar(500) DEFAULT NULL,
  `is_visible` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_student` (`student_id`),
  KEY `idx_school_campus` (`school_id`,`campus_id`),
  CONSTRAINT `fk_alumni_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumni`
--

LOCK TABLES `alumni` WRITE;
/*!40000 ALTER TABLE `alumni` DISABLE KEYS */;
/*!40000 ALTER TABLE `alumni` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alumni_donations`
--

DROP TABLE IF EXISTS `alumni_donations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumni_donations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `alumni_id` int(10) unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'NGN',
  `donation_date` date NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_alumni` (`alumni_id`),
  KEY `idx_school_campus` (`school_id`,`campus_id`),
  CONSTRAINT `fk_alumni_donations_alumni` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumni_donations`
--

LOCK TABLES `alumni_donations` WRITE;
/*!40000 ALTER TABLE `alumni_donations` DISABLE KEYS */;
/*!40000 ALTER TABLE `alumni_donations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alumni_events`
--

DROP TABLE IF EXISTS `alumni_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumni_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `event_date` date NOT NULL,
  `venue` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school_campus` (`school_id`,`campus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumni_events`
--

LOCK TABLES `alumni_events` WRITE;
/*!40000 ALTER TABLE `alumni_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `alumni_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `target` enum('all','students','teachers','parents','class','section') DEFAULT 'all',
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_published` tinyint(1) DEFAULT 1,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `class_id` (`class_id`),
  KEY `section_id` (`section_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_school` (`school_id`),
  KEY `idx_published` (`is_published`),
  KEY `idx_dates` (`start_date`,`end_date`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES
(1,6,'PTA meeting','testign','all',NULL,NULL,'2026-03-05','2026-03-06',0,1,'2026-03-03 13:58:17'),
(2,6,'School prayer','Pray against Sapa ','all',NULL,NULL,'2026-03-11','2026-03-12',1,1,'2026-03-10 07:36:12');
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `api_key` varchar(100) NOT NULL,
  `api_secret` varchar(100) DEFAULT NULL,
  `permissions` text DEFAULT NULL COMMENT 'JSON encoded permissions',
  `rate_limit_per_minute` int(10) DEFAULT 60,
  `rate_limit_per_hour` int(10) DEFAULT 1000,
  `rate_limit_per_day` int(10) DEFAULT 10000,
  `allowed_ips` text DEFAULT NULL COMMENT 'JSON array of allowed IPs',
  `allowed_origins` text DEFAULT NULL COMMENT 'JSON array of allowed origins',
  `expires_at` timestamp NULL DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_key` (`api_key`),
  KEY `idx_school` (`school_id`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_school_active` (`school_id`,`is_active`,`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_keys`
--

LOCK TABLES `api_keys` WRITE;
/*!40000 ALTER TABLE `api_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_logs`
--

DROP TABLE IF EXISTS `api_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `api_key_id` int(10) unsigned DEFAULT NULL,
  `endpoint` varchar(500) NOT NULL,
  `method` varchar(10) NOT NULL,
  `request_body` text DEFAULT NULL,
  `response_body` text DEFAULT NULL,
  `status_code` int(3) DEFAULT NULL,
  `response_time` decimal(10,4) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `is_success` tinyint(1) DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `api_key_id` (`api_key_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_endpoint` (`endpoint`),
  KEY `idx_status_code` (`status_code`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_school_endpoint` (`school_id`,`endpoint`,`created_at`),
  KEY `idx_api_logs_school_endpoint` (`school_id`,`endpoint`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_logs`
--

LOCK TABLES `api_logs` WRITE;
/*!40000 ALTER TABLE `api_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_usage`
--

DROP TABLE IF EXISTS `api_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_usage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `api_key_id` int(10) unsigned DEFAULT NULL,
  `endpoint` varchar(500) NOT NULL,
  `method` varchar(10) NOT NULL,
  `request_count` int(10) DEFAULT 1,
  `total_response_time` decimal(12,4) DEFAULT 0.0000,
  `failed_count` int(10) DEFAULT 0,
  `period` enum('minute','hour','day','month') DEFAULT 'day',
  `period_start` timestamp NOT NULL,
  `period_end` timestamp NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_api_usage` (`school_id`,`api_key_id`,`endpoint`,`method`,`period`,`period_start`),
  KEY `api_key_id` (`api_key_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_endpoint` (`endpoint`),
  KEY `idx_period` (`period`),
  KEY `idx_period_start` (`period_start`),
  KEY `idx_school_period` (`school_id`,`period`,`period_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_usage`
--

LOCK TABLES `api_usage` WRITE;
/*!40000 ALTER TABLE `api_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_scores`
--

DROP TABLE IF EXISTS `assessment_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_scores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `assessment_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `score` decimal(5,2) NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `entered_by` int(10) unsigned NOT NULL,
  `entered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_score` (`assessment_id`,`student_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_school` (`school_id`),
  KEY `fk_assessment_scores_entered_by` (`entered_by`),
  CONSTRAINT `fk_assessment_scores_assessment` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_assessment_scores_entered_by` FOREIGN KEY (`entered_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_assessment_scores_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_scores`
--

LOCK TABLES `assessment_scores` WRITE;
/*!40000 ALTER TABLE `assessment_scores` DISABLE KEYS */;
/*!40000 ALTER TABLE `assessment_scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_types`
--

DROP TABLE IF EXISTS `assessment_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `weight` decimal(5,2) DEFAULT NULL COMMENT 'Percentage weight towards final grade',
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_name` (`school_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_types`
--

LOCK TABLES `assessment_types` WRITE;
/*!40000 ALTER TABLE `assessment_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `assessment_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessments`
--

DROP TABLE IF EXISTS `assessments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned NOT NULL,
  `teacher_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `assessment_type_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `max_score` decimal(5,2) NOT NULL,
  `date` date NOT NULL,
  `is_published` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_class_subject` (`class_id`,`subject_id`),
  KEY `idx_teacher` (`teacher_id`),
  KEY `idx_term` (`term_id`),
  KEY `idx_type` (`assessment_type_id`),
  KEY `idx_school` (`school_id`),
  KEY `fk_assessments_section` (`section_id`),
  KEY `fk_assessments_subject` (`subject_id`),
  CONSTRAINT `fk_assessments_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_assessments_section` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_assessments_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_assessments_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_assessments_term` FOREIGN KEY (`term_id`) REFERENCES `academic_terms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_assessments_type` FOREIGN KEY (`assessment_type_id`) REFERENCES `assessment_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessments`
--

LOCK TABLES `assessments` WRITE;
/*!40000 ALTER TABLE `assessments` DISABLE KEYS */;
/*!40000 ALTER TABLE `assessments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `date` date NOT NULL,
  `status` enum('present','absent','late','half_day','holiday','sunday') NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `marked_by` int(10) unsigned DEFAULT NULL,
  `session` enum('morning','afternoon','full_day') DEFAULT 'full_day',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_attendance` (`student_id`,`date`,`session`),
  KEY `marked_by` (`marked_by`),
  KEY `idx_school` (`school_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_date` (`date`),
  KEY `idx_class` (`class_id`),
  KEY `idx_attendance_student_date` (`student_id`,`date`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES
(1,6,3,2,'2026-03-08','present','',1,'full_day','2026-03-08 17:31:18'),
(2,6,2,1,'2026-03-08','late','',1,'full_day','2026-03-08 17:34:57');
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `user_type` varchar(50) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(100) DEFAULT NULL,
  `entity_id` int(10) unsigned DEFAULT NULL,
  `old_values` text DEFAULT NULL COMMENT 'JSON encoded old values',
  `new_values` text DEFAULT NULL COMMENT 'JSON encoded new values',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_action` (`action`),
  KEY `idx_entity` (`entity_type`,`entity_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_school_action` (`school_id`,`action`,`created_at`),
  KEY `idx_audit_logs_school_action` (`school_id`,`action`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES
(1,6,1,'admin','academic_year_created','academic_years',1,NULL,'{\"name\":\"2025-2026\",\"start_date\":\"2025-09-08\",\"end_date\":\"2026-07-24\",\"is_default\":1,\"status\":\"active\"}','98.97.76.13','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/settings/general.php','2026-03-03 13:57:33'),
(2,6,1,'admin','announcement_created','announcements',1,NULL,'{\"title\":\"PTA meeting\"}','98.97.76.13','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/settings/general.php','2026-03-03 13:58:17'),
(3,6,1,'admin','subject_created','subjects',1,NULL,'{\"name\":\"mathematic\",\"code\":\"maths\"}','143.105.174.0','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-04 20:29:35'),
(4,6,1,'admin','class_created','classes',1,NULL,'{\"name\":\"grade 10\",\"code\":\"G10\"}','143.105.174.0','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-04 20:30:17'),
(5,6,1,'admin','section_created','sections',1,NULL,'{\"name\":\"section a\",\"code\":\"a\"}','143.105.174.0','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-04 20:30:38'),
(6,6,1,'admin','create','student',1,NULL,'{\"academic_year_id\":1,\"class_id\":1,\"section_id\":1,\"roll_number\":\"3\",\"admission_date\":\"2026-03-05\",\"first_name\":\"favour\",\"middle_name\":\"nzube\",\"last_name\":\"Zubetech\",\"gender\":\"male\",\"date_of_birth\":\"2020-03-05\",\"student_email\":\"zubetechhub@gmail.com\",\"student_phone\":\"09070525288\",\"guardian_name\":\"hennry uzodima\",\"guardian_email\":\"zubetechhub3@gmail.com\",\"guardian_phone\":\"07042424553\",\"guardian_relation\":\"father\",\"guardian_address\":\"chokocho\\r\\netche\",\"existing_parent_id\":null,\"blood_group\":\"A+\",\"allergies\":\"ull\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":\"\",\"current_address\":\"chokocho\",\"permanent_address\":\"etche\",\"previous_school\":\"nobsams\",\"previous_class\":\"ss3\",\"transfer_certificate_no\":\"null\"}','98.97.77.67','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-05 12:59:29'),
(7,6,1,'admin','create','student',2,NULL,'{\"academic_year_id\":1,\"class_id\":1,\"section_id\":1,\"roll_number\":\"3\",\"admission_date\":\"2026-03-05\",\"first_name\":\"Bibi\",\"middle_name\":\"Steph\",\"last_name\":\"Agundu\",\"gender\":\"female\",\"date_of_birth\":\"2006-10-05\",\"student_email\":\"fs@gmail.com\",\"student_phone\":\"080525288\",\"guardian_name\":\"Fatima\",\"guardian_email\":\"fhj@gmail.con\",\"guardian_phone\":\"0804344545\",\"guardian_relation\":\"mother\",\"guardian_address\":\"Etch\",\"existing_parent_id\":null,\"blood_group\":\"O+\",\"allergies\":\"Dust\",\"medical_conditions\":\"Ulcer\",\"doctor_name\":\"\",\"doctor_phone\":\"\",\"current_address\":\"Umuchima\",\"permanent_address\":\"Etche\",\"previous_school\":\"Damtoj\",\"previous_class\":\"Ss3\",\"transfer_certificate_no\":\"2943283\"}','102.90.98.183','Mozilla/5.0 (iPhone; CPU iPhone OS 26_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-05 14:01:27'),
(8,6,1,'admin','update','student',1,NULL,'{\"academic_year_id\":1,\"class_id\":1,\"section_id\":1,\"roll_number\":\"3\",\"admission_number\":\"BIT-2025-0001\",\"first_name\":\"favour\",\"middle_name\":\"nzube\",\"last_name\":\"Zubetech\",\"gender\":\"male\",\"date_of_birth\":\"2020-03-05\",\"student_phone\":\"09070525288\",\"student_email\":\"zubetechhub@gmail.com\",\"blood_group\":\"A+\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"okafor\",\"doctor_phone\":\"08033480654\",\"current_address\":\"chokocho\",\"permanent_address\":\"etche\",\"previous_school\":\"nobsams\",\"previous_class\":\"ss3\",\"transfer_certificate_no\":\"null\"}','98.97.77.67','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-05 16:14:50'),
(9,6,1,'admin','class_created','classes',2,NULL,'{\"name\":\"grade 1\",\"code\":\"g1\"}','98.97.77.67','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-05 18:33:25'),
(10,6,1,'admin','section_created','sections',2,NULL,'{\"name\":\"afternoon\",\"code\":\"noon\"}','98.97.77.67','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-05 18:34:35'),
(11,6,1,'admin','subject_created','subjects',2,NULL,'{\"name\":\"english\",\"code\":\"eng101\"}','98.97.77.67','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-05 18:34:56'),
(12,6,1,'admin','create','teacher',3,NULL,'{\"employee_id\":\"TCH-2026-8367\",\"name\":\"brook harry\",\"email\":\"favouruzodinma55@gmail.com\",\"phone\":\"909888766\",\"gender\":\"male\",\"date_of_birth\":\"1991-06-06\",\"fathers_name\":\"okafor\",\"mothers_name\":\"janet\",\"marital_status\":\"Married\",\"contract_type\":\"Permanent\",\"shift\":\"Day Shift\",\"work_location\":\"o site\",\"joining_date\":\"2026-03-06\",\"qualification\":\"bsc\",\"experience_years\":1,\"blood_group\":\"A+\",\"height\":\"5.4\",\"weight\":\"63\",\"bank_name\":\"kuda\",\"bank_account\":\"2032909568\",\"ifsc_code\":\"23423\",\"national_id\":\"345323434\",\"current_address\":\"Sbagha Bagha\",\"permanent_address\":\"Sbagha Bagha\",\"previous_school\":\"nobsams\",\"previous_school_address\":\"testinng\",\"facebook_link\":\"\",\"linkedin_link\":\"\",\"instagram_link\":\"\",\"youtube_link\":\"\",\"details\":\"null\",\"password\":\"\",\"profile_photo\":null,\"assigned_classes\":[\"1\"],\"assigned_subjects\":[{\"id\":1,\"school_id\":6,\"name\":\"mathematic\",\"code\":\"maths\",\"type\":\"core\",\"description\":\"easy\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-04 21:29:35\"}]}','98.97.77.67','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-05 19:03:03'),
(13,6,1,'admin','suspend','teacher',3,NULL,'{\"reason\":\"\"}','98.97.77.67','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1',NULL,'2026-03-05 19:58:34'),
(14,6,1,'admin','activate','teacher',3,NULL,'{\"status\":\"active\"}','98.97.77.67','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1',NULL,'2026-03-05 19:58:41'),
(15,6,1,'admin','suspend','teacher',3,NULL,'{\"reason\":\"\"}','98.97.77.67','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1',NULL,'2026-03-05 20:08:11'),
(16,6,1,'admin','activate','teacher',3,NULL,'{\"status\":\"active\"}','98.97.77.67','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1',NULL,'2026-03-05 20:08:17'),
(17,6,1,'admin','academic_term_created','academic_terms',1,NULL,'{\"name\":\"first term\",\"academic_year_id\":\"1\"}','98.97.77.67','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-05 21:06:31'),
(18,6,1,'admin','academic_term_created','academic_terms',2,NULL,'{\"name\":\"second term\",\"academic_year_id\":\"1\"}','98.97.77.67','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-05 21:07:23'),
(19,6,1,'admin','create','timetable',1,NULL,'{\"academic_year_id\":1,\"academic_term_id\":2,\"class_id\":2,\"section_id\":null,\"day\":\"monday\",\"period_number\":1,\"start_time\":\"09:00\",\"end_time\":\"09:45\",\"subject_id\":2,\"teacher_id\":9,\"room_number\":\"A101\",\"is_break\":0}','98.97.77.67','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-05 21:08:10'),
(20,6,1,'admin','profile_updated','users',1,NULL,'{\"updated_fields\":[\"action\",\"name\",\"email\",\"phone\",\"gender\",\"date_of_birth\",\"blood_group\",\"religion\",\"address\"]}','129.222.206.213','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/profile.php','2026-03-05 21:45:30'),
(21,6,1,'admin','profile_updated','users',1,NULL,'{\"updated_fields\":[\"action\",\"name\",\"email\",\"phone\",\"gender\",\"date_of_birth\",\"blood_group\",\"religion\",\"address\"]}','129.222.206.213','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/profile.php','2026-03-05 21:45:40'),
(22,6,1,'admin','profile_updated','users',1,NULL,'{\"updated_fields\":[\"action\",\"name\",\"email\",\"phone\",\"gender\",\"date_of_birth\",\"blood_group\",\"religion\",\"address\"]}','129.222.206.213','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1','/tenant/bitflux-wallet-1771434696/admin/profile.php','2026-03-05 21:49:17'),
(23,6,1,'admin','profile_updated','users',1,NULL,'{\"updated_fields\":[\"action\",\"name\",\"email\",\"phone\",\"gender\",\"date_of_birth\",\"blood_group\",\"religion\",\"address\"]}','129.222.206.213','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1','/tenant/bitflux-wallet-1771434696/admin/profile.php','2026-03-05 21:49:24'),
(24,6,1,'admin','profile_updated','users',1,NULL,'{\"updated_fields\":[\"action\",\"name\",\"email\",\"phone\",\"gender\",\"date_of_birth\",\"blood_group\",\"religion\",\"address\"]}','129.222.206.213','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1','/tenant/bitflux-wallet-1771434696/admin/profile.php','2026-03-05 21:49:29'),
(25,6,1,'admin','profile_updated','users',1,NULL,'{\"updated_fields\":[\"action\",\"name\",\"email\",\"phone\",\"gender\",\"date_of_birth\",\"blood_group\",\"religion\",\"address\"]}','129.222.206.213','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/profile.php','2026-03-05 21:57:02'),
(26,6,1,'admin','profile_updated','users',1,NULL,'{\"updated_fields\":[\"action\",\"name\",\"email\",\"phone\",\"gender\",\"date_of_birth\",\"blood_group\",\"religion\",\"address\"]}','129.222.206.213','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/profile.php','2026-03-05 21:57:39'),
(27,6,1,'admin','profile_updated','users',1,NULL,'{\"updated_fields\":[\"action\",\"name\",\"email\",\"phone\",\"gender\",\"date_of_birth\",\"blood_group\",\"religion\",\"address\"]}','129.222.206.213','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/profile.php','2026-03-05 21:59:45'),
(28,6,1,'admin','create','timetable',2,NULL,'{\"academic_year_id\":1,\"academic_term_id\":2,\"class_id\":2,\"section_id\":null,\"day\":\"monday\",\"period_number\":2,\"start_time\":\"09:45\",\"end_time\":\"10:30\",\"subject_id\":1,\"teacher_id\":9,\"room_number\":\"R202\",\"is_break\":0}','102.90.98.183','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1',NULL,'2026-03-06 01:29:55'),
(29,6,1,'admin','create','student',3,NULL,'{\"academic_year_id\":1,\"class_id\":2,\"section_id\":2,\"roll_number\":\"4\",\"admission_date\":\"2026-03-06\",\"first_name\":\"Uzochukwu\",\"middle_name\":\"Kosisochukwu\",\"last_name\":\"Jessica\",\"gender\":\"female\",\"date_of_birth\":\"2007-10-07\",\"student_email\":\"uzochukwukosisochukwu046@gmail.com\",\"student_phone\":\"07041390038\",\"guardian_name\":\"Emezie Ngozi\",\"guardian_email\":\"ngozionyebuchin@gmail.com\",\"guardian_phone\":\"07061052210\",\"guardian_relation\":\"mother\",\"guardian_address\":\"eliozu portharcourt\",\"existing_parent_id\":null,\"blood_group\":\"O+\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":\"\",\"current_address\":\"eliozu portharcourt\",\"permanent_address\":\"2047 Walt Nuzum Farm Road\",\"previous_school\":\"FGGC Abuloma\",\"previous_class\":\"jss3\",\"transfer_certificate_no\":\"null\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-06 07:52:59'),
(30,6,1,'admin','class_created','classes',3,NULL,'{\"name\":\"Primary 3\",\"code\":\"Pri 3\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:00:26'),
(31,6,1,'admin','section_created','sections',3,NULL,'{\"name\":\"evening\",\"code\":\"e\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:02:10'),
(32,6,1,'admin','subject_created','subjects',3,NULL,'{\"name\":\"Basic Science\",\"code\":\"BSc\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:03:35'),
(33,6,1,'admin','subject_created','subjects',4,NULL,'{\"name\":\"Basic Technnology\",\"code\":\"B.tech\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:07:39'),
(34,6,1,'admin','subject_created','subjects',5,NULL,'{\"name\":\"Creative and cultural art\",\"code\":\"CCA\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:09:36'),
(35,6,1,'admin','subject_created','subjects',6,NULL,'{\"name\":\"Civic Education\",\"code\":\"CEd\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:12:06'),
(36,6,1,'admin','subject_created','subjects',7,NULL,'{\"name\":\"French\",\"code\":\"Frn\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:13:22'),
(37,6,1,'admin','subject_created','subjects',8,NULL,'{\"name\":\"Igbo\",\"code\":\"IGB\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:14:34'),
(38,6,1,'admin','subject_created','subjects',9,NULL,'{\"name\":\"Social Studies\",\"code\":\"SOS\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:17:05'),
(39,6,1,'admin','subject_created','subjects',10,NULL,'{\"name\":\"Yoruba\",\"code\":\"YOR\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:18:38'),
(40,6,1,'admin','subject_created','subjects',11,NULL,'{\"name\":\"Hausa\",\"code\":\"HSA\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:19:09'),
(41,6,1,'admin','subject_created','subjects',12,NULL,'{\"name\":\"Christian Religious Knowledge\",\"code\":\"CRK\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:20:53'),
(42,6,1,'admin','subject_created','subjects',13,NULL,'{\"name\":\"History\",\"code\":\"HST\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:21:51'),
(43,6,1,'admin','subject_created','subjects',14,NULL,'{\"name\":\"Geography\",\"code\":\"GEO\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:22:15'),
(44,6,1,'admin','subject_created','subjects',15,NULL,'{\"name\":\"Chemistry\",\"code\":\"CHEM\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:22:35'),
(45,6,1,'admin','subject_created','subjects',16,NULL,'{\"name\":\"Biology \",\"code\":\"BIO\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:22:59'),
(46,6,1,'admin','subject_created','subjects',17,NULL,'{\"name\":\"Physics\",\"code\":\"PHY\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:23:31'),
(47,6,1,'admin','subject_created','subjects',18,NULL,'{\"name\":\"Economics\",\"code\":\"ECO\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:24:40'),
(48,6,1,'admin','subject_created','subjects',19,NULL,'{\"name\":\"Verbal Reasoning\",\"code\":\"VRB\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:26:30'),
(49,6,1,'admin','create','teacher',4,NULL,'{\"employee_id\":\"TCH-2026-2653\",\"name\":\"Maxwell Acheampong\",\"email\":\"bitfluxwallet@gmail.com\",\"phone\":\"8119999755\",\"gender\":\"male\",\"date_of_birth\":\"2026-03-19\",\"fathers_name\":\"obinna max\",\"mothers_name\":\"obinna female\",\"marital_status\":\"Unmarried\",\"contract_type\":\"Permanent\",\"shift\":\"Day Shift\",\"work_location\":\"onsite\",\"joining_date\":\"2026-03-06\",\"qualification\":\"bsc\",\"experience_years\":5,\"blood_group\":\"A-\",\"height\":\"5.9\",\"weight\":\"20\",\"bank_name\":\"\",\"bank_account\":\"\",\"ifsc_code\":\"\",\"national_id\":\"\",\"current_address\":\"123 walkers street\",\"permanent_address\":\"123 walkers street\",\"previous_school\":\"futo\",\"previous_school_address\":\"owerri\",\"facebook_link\":\"\",\"linkedin_link\":\"\",\"instagram_link\":\"\",\"youtube_link\":\"\",\"details\":\"new tacher\",\"password\":\"\",\"profile_photo\":null,\"assigned_classes\":[\"3\"],\"assigned_subjects\":[{\"id\":4,\"school_id\":6,\"name\":\"Basic Technnology\",\"code\":\"B.tech\",\"type\":\"core\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:07:39\"},{\"id\":15,\"school_id\":6,\"name\":\"Chemistry\",\"code\":\"CHEM\",\"type\":\"core\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:22:35\"}]}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-06 08:28:09'),
(50,6,1,'admin','subject_created','subjects',20,NULL,'{\"name\":\"Quantitative Reasoning \",\"code\":\"QTR\"}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:28:51'),
(51,6,1,'admin','subject_created','subjects',21,NULL,'{\"name\":\"Further Mathematics\",\"code\":\"F.Maths\"}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:34:22'),
(52,6,1,'admin','class_created','classes',4,NULL,'{\"name\":\"Kindergaten\",\"code\":\"KG\"}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:41:57'),
(53,6,1,'admin','class_created','classes',5,NULL,'{\"name\":\"Nursery 1\",\"code\":\"NUR 1\"}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:45:53'),
(54,6,1,'admin','class_created','classes',6,NULL,'{\"name\":\"Nursery 2\",\"code\":\"NUR 2\"}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:48:10'),
(55,6,1,'admin','class_created','classes',7,NULL,'{\"name\":\"Nursery 3\",\"code\":\"NUR 3\"}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:49:19'),
(56,6,1,'admin','class_created','classes',8,NULL,'{\"name\":\"Primary 1\",\"code\":\"PRY 1\"}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:53:40'),
(57,6,1,'admin','class_created','classes',9,NULL,'{\"name\":\"Primary 2\",\"code\":\"PRY 2\"}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:55:20'),
(58,6,1,'admin','class_created','classes',10,NULL,'{\"name\":\"Primary 4\",\"code\":\"PRY 4\"}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 08:59:16'),
(59,6,1,'admin','class_created','classes',11,NULL,'{\"name\":\"Primary 5\",\"code\":\"PRY 5\"}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 09:00:49'),
(60,6,1,'admin','class_created','classes',12,NULL,'{\"name\":\"Junior Secondary School 1\",\"code\":\"JSS1\"}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 09:02:37'),
(61,6,1,'admin','class_created','classes',13,NULL,'{\"name\":\"Junior Secondary School 3\",\"code\":\"JSS3\"}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 09:04:10'),
(62,6,1,'admin','class_created','classes',14,NULL,'{\"name\":\"Senior Secondary School 1\",\"code\":\"SSS1\"}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 09:11:37'),
(63,6,1,'admin','class_created','classes',15,NULL,'{\"name\":\"Senior Secondary School 2\",\"code\":\"SSS2\"}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 09:12:39'),
(64,6,1,'admin','class_created','classes',16,NULL,'{\"name\":\"Senior Secondary School 3\",\"code\":\"SSS3\"}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-06 09:13:33'),
(65,6,1,'admin','create','guardian',13,NULL,'{\"guardian_name\":\"Emezie IKe\",\"guardian_type\":\"father\",\"phone\":\"585-415-1576\",\"email\":\"mutexia21@gmail.com\",\"occupation\":\"hunter\",\"address\":\"2047 Walt Nuzum Farm Road\",\"gender\":\"male\",\"instagram\":\"@jsjs\",\"guardian_photo\":null}','102.90.96.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-06 09:16:26'),
(66,6,1,'admin','create','guardian',12,NULL,'{\"guardian_name\":\"promise uzodinma\",\"guardian_type\":\"mother\",\"phone\":\"811-999-9755\",\"email\":\"bitfluxwallet@gmail.com\",\"occupation\":\"trader\",\"address\":\"123 walkers street\",\"gender\":\"female\",\"instagram\":\"@promise\",\"guardian_photo\":null,\"student_ids\":[\"3\"],\"relationships\":{\"3\":\"guardian\"},\"can_pickup\":{\"3\":\"1\"},\"emergency_contact\":{\"3\":\"0\"}}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-06 09:46:16'),
(67,6,1,'admin','create','guardian',12,NULL,'{\"guardian_name\":\"promise uzodinma\",\"guardian_type\":\"mother\",\"phone\":\"811-999-9755\",\"email\":\"bitfluxwallet@gmail.com\",\"occupation\":\"trader\",\"address\":\"123 walkers street\",\"gender\":\"male\",\"instagram\":\"@promise\",\"guardian_photo\":null,\"student_ids\":[\"2\"],\"relationships\":{\"2\":\"guardian\"},\"can_pickup\":{\"2\":\"1\"},\"emergency_contact\":{\"2\":\"0\"}}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-06 09:57:25'),
(68,6,1,'admin','create','guardian',12,NULL,'{\"guardian_name\":\"promise uzodinma\",\"guardian_type\":\"mother\",\"phone\":\"811-999-9755\",\"email\":\"bitfluxwallet@gmail.com\",\"occupation\":\"trader\",\"address\":\"123 walkers street\",\"gender\":\"male\",\"instagram\":\"@promise\",\"guardian_photo\":null,\"student_ids\":[\"2\"],\"relationships\":{\"2\":\"sister\"}}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-06 10:07:15'),
(69,6,1,'admin','create','guardian',12,NULL,'{\"guardian_name\":\"promise uzodinma\",\"guardian_type\":\"mother\",\"phone\":\"811-999-9755\",\"email\":\"bitfluxwallet@gmail.com\",\"occupation\":\"trader\",\"address\":\"123 walkers street\",\"gender\":\"male\",\"instagram\":\"@promise\",\"guardian_photo\":null,\"student_ids\":[\"2\"],\"relationships\":{\"2\":\"guardian\"}}','102.90.96.225','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-06 11:03:31'),
(70,6,1,'admin','update','guardian',13,NULL,'{\"csrf_token\":\"528d48f4fda54a21fe86ca1825ce2eb403760bcca687bd28faf9054b2e377bfb\",\"guardian_type\":\"brother\",\"guardian_name\":\"Emezie IKe\",\"instagram\":\"\",\"phone\":\"585-415-1576\",\"occupation\":\"\",\"address\":\"2047 Walt Nuzum Farm Road\",\"gender\":\"male\",\"email\":\"mutexia21@gmail.com\",\"password\":\"\"}','98.97.79.44','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/edit-guardian.php?id=13','2026-03-06 18:15:42'),
(71,6,1,'admin','delete','announcement',1,'{\"title\":\"PTA meeting\"}',NULL,'98.97.79.44','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/notice-board.php?id=1','2026-03-06 19:30:29'),
(72,6,1,'admin','create','events',1,NULL,'{\"title\":\"pta meeting\",\"type\":\"meeting\",\"start_date\":\"2026-03-12\"}','98.97.79.44','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/event.php','2026-03-06 21:43:54'),
(73,6,1,'admin','create','events',2,NULL,'{\"title\":\"pta meeting\",\"type\":\"meeting\",\"start_date\":\"2026-03-12\"}','98.97.79.44','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/event.php','2026-03-06 21:44:02'),
(74,6,1,'admin','delete','events',2,'{\"id\":2,\"school_id\":6,\"title\":\"pta meeting\",\"description\":\"a guadian to a student must be present\",\"type\":\"meeting\",\"start_date\":\"2026-03-12\",\"end_date\":\"2026-03-12\",\"start_time\":\"10:30:00\",\"end_time\":\"12:30:00\",\"venue\":\"school hall\",\"is_public\":1,\"created_by\":1,\"created_at\":\"2026-03-06 22:44:02\",\"created_by_name\":\"bitflux wallet\",\"created_by_email\":\"safebit99@gmail.com\",\"status\":\"upcoming\"}',NULL,'98.97.79.44','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/event.php?id=2','2026-03-06 21:51:01'),
(75,6,1,'admin','delete','announcement',1,'{\"title\":\"PTA meeting\"}',NULL,'102.90.100.79','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1','/tenant/bitflux-wallet-1771434696/admin/notice-board.php','2026-03-07 02:45:00'),
(76,6,1,'admin','delete','announcement',1,'{\"title\":\"PTA meeting\"}',NULL,'102.90.100.79','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1','/tenant/bitflux-wallet-1771434696/admin/notice-board.php','2026-03-07 02:45:11'),
(77,6,1,'admin','create','student',4,NULL,'{\"academic_year_id\":1,\"class_id\":2,\"section_id\":2,\"roll_number\":\"2\",\"admission_date\":\"2026-03-09\",\"first_name\":\"Allen\",\"middle_name\":\"Firi\",\"last_name\":\"Faith\",\"gender\":\"female\",\"date_of_birth\":\"2006-06-23\",\"student_email\":\"amina2006@gmail.com\",\"student_phone\":\"0907052500\",\"guardian_name\":\"Allen Ateli\",\"guardian_email\":\"aminfather@gmail.com\",\"guardian_phone\":\"07061052211\",\"guardian_relation\":\"father\",\"guardian_address\":\"chokocho\\r\\netche\",\"existing_parent_id\":null,\"blood_group\":\"B+\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":\"\",\"current_address\":\"etche\",\"permanent_address\":\"igbo etech\",\"previous_school\":\"International Unity School\",\"previous_class\":\"JSS1\",\"transfer_certificate_no\":\"null\"}','98.97.76.218','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-09 10:14:58'),
(78,6,1,'admin','create','student',5,NULL,'{\"academic_year_id\":1,\"class_id\":2,\"section_id\":2,\"roll_number\":\"1\",\"admission_date\":\"2026-03-09\",\"first_name\":\"obinna\",\"middle_name\":\"emmanuel\",\"last_name\":\"uzodinma\",\"gender\":\"male\",\"date_of_birth\":\"2006-03-09\",\"student_email\":\"emmaobinna@gmail.com\",\"student_phone\":\"08119999775\",\"guardian_name\":\"\",\"guardian_email\":\"\",\"guardian_phone\":\"\",\"guardian_relation\":null,\"guardian_address\":\"\",\"existing_parent_id\":4,\"blood_group\":\"A-\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":\"\",\"current_address\":\"chokocho etche rivers state\",\"permanent_address\":\"etche\",\"previous_school\":\"ulakwo primary school\",\"previous_class\":\"primary 5\",\"transfer_certificate_no\":\"2005-3949\"}','98.97.76.218','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-09 11:30:05'),
(79,6,1,'admin','create','events',3,NULL,'{\"title\":\"Inter-house sports\",\"type\":\"sports\",\"start_date\":\"2026-03-27\"}','98.97.76.218','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/event.php','2026-03-09 11:39:38'),
(80,6,1,'admin','create','events',4,NULL,'{\"title\":\"Inter-house sports\",\"type\":\"sports\",\"start_date\":\"2026-03-27\"}','98.97.76.218','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/event.php','2026-03-09 11:39:47'),
(81,6,1,'admin','delete','events',4,'{\"id\":4,\"school_id\":6,\"title\":\"Inter-house sports\",\"description\":\"\",\"type\":\"sports\",\"start_date\":\"2026-03-27\",\"end_date\":\"2026-03-27\",\"start_time\":\"08:30:00\",\"end_time\":\"16:00:00\",\"venue\":\"School Field\",\"is_public\":1,\"created_by\":1,\"created_at\":\"2026-03-09 12:39:47\",\"created_by_name\":\"bitflux wallet\",\"created_by_email\":\"safebit99@gmail.com\",\"status\":\"upcoming\"}',NULL,'98.97.76.218','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/event.php?id=4&school_slug=bitflux-wallet-1771434696','2026-03-09 11:40:17'),
(82,6,1,'admin','create','teacher',5,NULL,'{\"employee_id\":\"TCH-2026-3448\",\"name\":\"Samuel Sharon\",\"email\":\"samuelsharon@gmail.com\",\"phone\":\"08144162281\",\"gender\":\"female\",\"date_of_birth\":\"2002-07-02\",\"fathers_name\":\"Mr. Samuel James\",\"mothers_name\":\"Mrs. Samuel Joan\",\"marital_status\":\"Unmarried\",\"contract_type\":\"Permanent\",\"shift\":\"Day Shift\",\"work_location\":\"onsite\",\"joining_date\":\"2026-03-08\",\"qualification\":\"bsc\",\"experience_years\":3,\"blood_group\":\"B+\",\"height\":\"5&quot;7\",\"weight\":\"57kg\",\"bank_name\":\"\",\"bank_account\":\"1874611392\",\"ifsc_code\":\"\",\"national_id\":\"\",\"current_address\":\"Rumuodumaya, Rivers State.\",\"permanent_address\":\"Rumuodumaya, Rivers State.\",\"previous_school\":\"Girls&#039; Grammar School, Rumueme\",\"previous_school_address\":\"Rumueme, Rivers State\",\"facebook_link\":\"\",\"linkedin_link\":\"\",\"instagram_link\":\"\",\"youtube_link\":\"\",\"details\":\"\",\"password\":\"\",\"profile_photo\":null,\"assigned_classes\":[\"12\"],\"assigned_subjects\":[{\"id\":12,\"school_id\":6,\"name\":\"Christian Religious Knowledge\",\"code\":\"CRK\",\"type\":\"elective\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:20:53\"},{\"id\":6,\"school_id\":6,\"name\":\"Civic Education\",\"code\":\"CEd\",\"type\":\"elective\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:12:06\"}]}','98.97.76.218','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-09 11:52:42'),
(83,6,1,'admin','section_created','sections',4,NULL,'{\"name\":\"Section A\",\"code\":\"A\"}','98.97.76.218','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/general.php','2026-03-09 11:54:33'),
(84,6,1,'admin','create','teacher',6,NULL,'{\"employee_id\":\"TCH-2026-4791\",\"name\":\"Ibim Dokubo Shannel\",\"email\":\"shannelibimdokubo@gmail.com\",\"phone\":\"08177896543\",\"gender\":\"female\",\"date_of_birth\":\"2005-06-10\",\"fathers_name\":\"Mr. Ibim Dokubo John\",\"mothers_name\":\"Mrs. Ibim Dokubo Elizabeth\",\"marital_status\":\"Married\",\"contract_type\":\"Permanent\",\"shift\":\"Day Shift\",\"work_location\":\"onsite\",\"joining_date\":\"2026-03-02\",\"qualification\":\"Bsc\",\"experience_years\":2,\"blood_group\":\"O+\",\"height\":\"5&quot;5\",\"weight\":\"55kg\",\"bank_name\":\"\",\"bank_account\":\"\",\"ifsc_code\":\"\",\"national_id\":\"\",\"current_address\":\"AGIP, Port Harcourt\",\"permanent_address\":\"AGIP, Port Harcourt\",\"previous_school\":\"Staff School, Abuloma\",\"previous_school_address\":\"Abuloma, Rivers State\",\"facebook_link\":\"\",\"linkedin_link\":\"\",\"instagram_link\":\"\",\"youtube_link\":\"\",\"details\":\"\",\"password\":\"\",\"profile_photo\":null,\"assigned_classes\":[],\"assigned_subjects\":[{\"id\":1,\"school_id\":6,\"name\":\"mathematic\",\"code\":\"maths\",\"type\":\"core\",\"description\":\"easy\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-04 21:29:35\"},{\"id\":20,\"school_id\":6,\"name\":\"Quantitative Reasoning \",\"code\":\"QTR\",\"type\":\"elective\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:28:51\"}]}','98.97.76.218','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-09 12:23:49'),
(85,6,1,'admin','create','teacher',7,NULL,'{\"employee_id\":\"TCH-2026-0542\",\"name\":\"Onyebuchi Maurice\",\"email\":\"mauricechukwunenye@gmail.com\",\"phone\":\"07011432678\",\"gender\":\"male\",\"date_of_birth\":\"1999-04-26\",\"fathers_name\":\"Onyebuchi Solomon\",\"mothers_name\":\"Onyebuchi Bridget\",\"marital_status\":\"Married\",\"contract_type\":\"Temporary\",\"shift\":\"Afternoon Shift\",\"work_location\":\"onsite\",\"joining_date\":\"2026-02-20\",\"qualification\":\"Bsc\",\"experience_years\":7,\"blood_group\":\"B-\",\"height\":\"6&quot;0\",\"weight\":\"62kg\",\"bank_name\":\"\",\"bank_account\":\"\",\"ifsc_code\":\"\",\"national_id\":\"\",\"current_address\":\"Rumuomasi, Rivers State\",\"permanent_address\":\"Lekki, Lagos\",\"previous_school\":\"Queens&#039; College\",\"previous_school_address\":\"Yaba, Lagos state\",\"facebook_link\":\"\",\"linkedin_link\":\"\",\"instagram_link\":\"\",\"youtube_link\":\"\",\"details\":\"\",\"password\":\"\",\"profile_photo\":null,\"assigned_classes\":[],\"assigned_subjects\":[{\"id\":21,\"school_id\":6,\"name\":\"Further Mathematics\",\"code\":\"F.Maths\",\"type\":\"elective\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:34:22\"},{\"id\":1,\"school_id\":6,\"name\":\"mathematic\",\"code\":\"maths\",\"type\":\"core\",\"description\":\"easy\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-04 21:29:35\"},{\"id\":17,\"school_id\":6,\"name\":\"Physics\",\"code\":\"PHY\",\"type\":\"core\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:23:31\"}]}','98.97.76.218','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-09 12:31:48'),
(86,6,1,'admin','create','teacher',8,NULL,'{\"employee_id\":\"TCH-2026-8371\",\"name\":\"Nwosu Jude\",\"email\":\"judejudon114@gmail.com\",\"phone\":\"08076593005\",\"gender\":\"male\",\"date_of_birth\":\"2002-08-19\",\"fathers_name\":\"Mr. Nwosu Nnaagu\",\"mothers_name\":\"Mrs. Nwosu Queeneth\",\"marital_status\":\"Married\",\"contract_type\":\"Permanent\",\"shift\":\"Afternoon Shift\",\"work_location\":\"onsite\",\"joining_date\":\"2023-03-13\",\"qualification\":\"Bsc\",\"experience_years\":9,\"blood_group\":\"O-\",\"height\":\"5&quot;7\",\"weight\":\"60kg\",\"bank_name\":\"\",\"bank_account\":\"\",\"ifsc_code\":\"\",\"national_id\":\"\",\"current_address\":\"Amadi Road, Rivers State.\",\"permanent_address\":\"Amadi Road, Rivers State.\",\"previous_school\":\"Bereton Nursery and Primary School, Elekahia, Rivers State\",\"previous_school_address\":\"Elekahia, Rivers State\",\"facebook_link\":\"\",\"linkedin_link\":\"\",\"instagram_link\":\"\",\"youtube_link\":\"\",\"details\":\"\",\"password\":\"\",\"profile_photo\":null,\"assigned_classes\":[],\"assigned_subjects\":[{\"id\":3,\"school_id\":6,\"name\":\"Basic Science\",\"code\":\"BSc\",\"type\":\"core\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:03:35\"},{\"id\":4,\"school_id\":6,\"name\":\"Basic Technnology\",\"code\":\"B.tech\",\"type\":\"core\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:07:39\"},{\"id\":16,\"school_id\":6,\"name\":\"Biology \",\"code\":\"BIO\",\"type\":\"core\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:22:59\"}]}','98.97.76.218','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-09 12:46:31'),
(87,6,1,'admin','suspend','teacher',3,NULL,'{\"reason\":\"\"}','129.222.206.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-09 20:33:04'),
(88,6,1,'admin','activate','teacher',3,NULL,'{\"status\":\"active\"}','129.222.206.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-09 20:33:12'),
(89,6,1,'admin','create','announcement',2,NULL,'{\"title\":\"School prayer\"}','197.210.54.222','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1','/tenant/bitflux-wallet-1771434696/admin/notice-board.php','2026-03-10 07:36:12'),
(90,6,1,'admin','create','timetable',3,NULL,'{\"academic_year_id\":1,\"academic_term_id\":2,\"class_id\":12,\"section_id\":null,\"day\":\"tuesday\",\"period_number\":3,\"start_time\":\"09:00\",\"end_time\":\"09:45\",\"subject_id\":1,\"teacher_id\":19,\"room_number\":\"A1\",\"is_break\":0}','102.90.99.97','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36',NULL,'2026-03-10 12:32:05'),
(91,6,1,'admin','create','timetable',4,NULL,'{\"academic_year_id\":1,\"academic_term_id\":2,\"class_id\":2,\"section_id\":null,\"day\":\"monday\",\"period_number\":3,\"start_time\":\"10:00\",\"end_time\":\"10:45\",\"subject_id\":5,\"teacher_id\":19,\"room_number\":\"D101\",\"is_break\":0}','102.90.81.13','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-10 12:36:01'),
(92,6,1,'admin','create','student',14,NULL,'{\"academic_year_id\":1,\"class_id\":13,\"section_id\":null,\"roll_number\":\"1\",\"admission_date\":\"2026-03-11\",\"first_name\":\"prosper\",\"middle_name\":\"eche\",\"last_name\":\"checz\",\"gender\":\"male\",\"date_of_birth\":\"1998-09-02\",\"student_email\":\"prosper.checz@student.bitflux-wallet-1771434696\",\"student_phone\":\"\",\"guardian_name\":\"james checz\",\"guardian_email\":\"jameschecz@gmail.com\",\"guardian_phone\":\"0908888288\",\"guardian_relation\":\"father\",\"guardian_address\":\"umuahia town , gae junction\",\"existing_parent_id\":null,\"blood_group\":\"O+\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":\"\",\"current_address\":\"etche\",\"permanent_address\":\"chokocho\\r\\netche\",\"previous_school\":\"Wisdom Gate\",\"previous_class\":\"jss2\",\"transfer_certificate_no\":\"2098-2982\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-11 07:12:33'),
(93,6,1,'admin','create','teacher',9,NULL,'{\"employee_id\":\"TCH-2026-8372\",\"name\":\"Solomon amaechi\",\"email\":\"solomon@gmail.com\",\"phone\":\"08119999755\",\"gender\":\"male\",\"date_of_birth\":\"1986-03-12\",\"fathers_name\":\"Amadi johnson\",\"mothers_name\":\"Nkechi amadi\",\"marital_status\":\"Unmarried\",\"contract_type\":\"Permanent\",\"shift\":\"Day Shift\",\"work_location\":\"On shite\",\"joining_date\":\"2026-03-12\",\"qualification\":\"O level\",\"experience_years\":1,\"blood_group\":\"AB+\",\"height\":\"6\",\"weight\":\"56kg\",\"bank_name\":\"\",\"bank_account\":\"\",\"ifsc_code\":\"\",\"national_id\":\"\",\"current_address\":\"\",\"permanent_address\":\"\",\"previous_school\":\"\",\"previous_school_address\":\"\",\"facebook_link\":\"\",\"linkedin_link\":\"\",\"instagram_link\":\"\",\"youtube_link\":\"\",\"details\":\"\",\"password\":\"\",\"profile_photo\":null,\"assigned_classes\":[\"15\"],\"assigned_subjects\":[{\"id\":10,\"school_id\":6,\"name\":\"Yoruba\",\"code\":\"YOR\",\"type\":\"elective\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:18:38\"}]}','102.90.79.148','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1',NULL,'2026-03-11 18:09:55'),
(94,6,1,'admin','create','guardian',52,NULL,'{\"guardian_name\":\"Uzochukwu Uzomaka Rachael\",\"guardian_type\":\"mother\",\"phone\":\"707-308-9496\",\"email\":\"uzoamakarach678@mail.com\",\"occupation\":\"Tailor\",\"address\":\"Igwuruta, Rivers State\",\"gender\":\"female\",\"instagram\":\"null\",\"guardian_photo\":null,\"student_ids\":[],\"relationships\":[]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-12 09:19:07'),
(95,6,1,'admin','create','guardian',53,NULL,'{\"guardian_name\":\"Unagbu Udochukwu Simon\",\"guardian_type\":\"father\",\"phone\":\"707-571-2549\",\"email\":\"unagbusimon098@gmail.com\",\"occupation\":\"Engineer\",\"address\":\"Okomoko, Rivers State\",\"gender\":\"male\",\"instagram\":\"\",\"guardian_photo\":null,\"student_ids\":[],\"relationships\":[]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-12 09:23:53'),
(96,6,1,'admin','create','guardian',54,NULL,'{\"guardian_name\":\"Okoye Ifunnanya Jennifer\",\"guardian_type\":\"mother\",\"phone\":\"706-105-2210\",\"email\":\"ifunnanyajenn09@gmail.com\",\"occupation\":\"Accountant\",\"address\":\"Igbo-Etche, Rivers State\",\"gender\":\"female\",\"instagram\":\"\",\"guardian_photo\":null,\"student_ids\":[],\"relationships\":[]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-12 09:27:54'),
(97,6,1,'admin','create','guardian',55,NULL,'{\"guardian_name\":\"Adeyemi Kehinde Joshua\",\"guardian_type\":\"father\",\"phone\":\"814-416-2281\",\"email\":\"adeyemijoshua@gmail.com\",\"occupation\":\"Teacher\",\"address\":\"Umuechem, Rivers State\",\"gender\":\"male\",\"instagram\":\"\",\"guardian_photo\":null,\"student_ids\":[],\"relationships\":[]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-12 09:31:23'),
(98,6,1,'admin','create','guardian',56,NULL,'{\"guardian_name\":\"Adetifa Ayomide Shedrach\",\"guardian_type\":\"father\",\"phone\":\"700-896-9436\",\"email\":\"sheddytifa1972@gmail.com\",\"occupation\":\"CEO\",\"address\":\"Okomoko, Rivers State\",\"gender\":\"male\",\"instagram\":\"Sheddy_tifa\",\"guardian_photo\":null,\"student_ids\":[],\"relationships\":[]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-12 09:36:58'),
(99,6,1,'admin','create','guardian',57,NULL,'{\"guardian_name\":\"Ovieva Oghenerukevwe Simona\",\"guardian_type\":\"mother\",\"phone\":\"814-415-7784\",\"email\":\"oghenerukevwemona@gmail.com\",\"occupation\":\"Business Woman\",\"address\":\"Umuechem, Rivers State\",\"gender\":\"female\",\"instagram\":\"\",\"guardian_photo\":null,\"student_ids\":[],\"relationships\":[]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-12 09:42:23'),
(100,6,1,'admin','create','guardian',58,NULL,'{\"guardian_name\":\"Pere Tokoni Joy\",\"guardian_type\":\"grandmother\",\"phone\":\"911-846-0472\",\"email\":\"tokonipere001@gmail.com\",\"occupation\":\"\",\"address\":\"Igbo-Etche, Rivers State\",\"gender\":\"female\",\"instagram\":\"\",\"guardian_photo\":null,\"student_ids\":[],\"relationships\":[]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-12 09:47:16'),
(101,6,1,'admin','create','section',5,NULL,'{\"name\":\"Section A\",\"code\":\"A\",\"class_id\":\"4\"}','98.97.77.110','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/section-list.php?class_id=4','2026-03-12 09:47:57'),
(102,6,1,'admin','create','guardian',59,NULL,'{\"guardian_name\":\"Bagshaw Boma Hephzibah\",\"guardian_type\":\"mother\",\"phone\":\"907-536-3889\",\"email\":\"bomahephzibah@gmail.com\",\"occupation\":\"Nurse\",\"address\":\"Igwuruta, Rivers State\",\"gender\":\"female\",\"instagram\":\"\",\"guardian_photo\":null,\"student_ids\":[],\"relationships\":[]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-12 09:53:57'),
(103,6,1,'admin','create','section',6,NULL,'{\"name\":\"section b\",\"code\":\"SEc B\",\"class_id\":\"12\"}','98.97.77.110','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/section-list.php?class_id=12','2026-03-12 09:57:10'),
(104,6,1,'admin','create','guardian',60,NULL,'{\"guardian_name\":\"Ogbuogu Chukwuma Benson\",\"guardian_type\":\"father\",\"phone\":\"816-744-9957\",\"email\":\"bennchukss111@gmail.com\",\"occupation\":\"Progammer\",\"address\":\"Umuechem, Rivers State\",\"gender\":\"male\",\"instagram\":\"Benn Chuks\",\"guardian_photo\":null,\"student_ids\":[],\"relationships\":[]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-12 09:58:00'),
(105,6,1,'admin','create','guardian',61,NULL,'{\"guardian_name\":\"Sylvester Chioma Monica\",\"guardian_type\":\"sister\",\"phone\":\"809-655-4738\",\"email\":\"monicachioma002@gmail.com\",\"occupation\":\"Student\",\"address\":\"Chokocho, Rivers State\",\"gender\":\"female\",\"instagram\":\"Mon_nique\",\"guardian_photo\":null,\"student_ids\":[],\"relationships\":[]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-12 10:04:57'),
(106,6,1,'admin','create','guardian',62,NULL,'{\"guardian_name\":\"Okere Chiamaka Juliet\",\"guardian_type\":\"mother\",\"phone\":\"806-277-2775\",\"email\":\"okerejuliet90@gmail.com\",\"occupation\":\"Farmer\",\"address\":\"Chokocho, Rivers State\",\"gender\":\"female\",\"instagram\":\"\",\"guardian_photo\":null,\"student_ids\":[],\"relationships\":[]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-12 10:14:39'),
(107,6,1,'admin','create','guardian',63,NULL,'{\"guardian_name\":\"Amadi Otonsiki Benita\",\"guardian_type\":\"mother\",\"phone\":\"708-966-5434\",\"email\":\"otonsikibenita@gmail.com\",\"occupation\":\"Teacher\",\"address\":\"Umuechem, Rivers State\",\"gender\":\"female\",\"instagram\":\"\",\"guardian_photo\":null,\"student_ids\":[],\"relationships\":[]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-guardian.php','2026-03-12 10:19:19'),
(108,6,1,'admin','create','student',21,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":null,\"roll_number\":\"1\",\"admission_date\":\"2025-09-11\",\"first_name\":\"Uzochukwu\",\"middle_name\":\"Chiemela\",\"last_name\":\"Victory\",\"gender\":\"female\",\"date_of_birth\":\"2023-11-02\",\"student_email\":\"zubuetechhub@gmail.com\",\"student_phone\":\"09099926700\",\"guardian_name\":\"\",\"guardian_email\":\"\",\"guardian_phone\":\"\",\"guardian_relation\":\"\",\"guardian_address\":\"\",\"existing_parent_id\":52,\"blood_group\":\"\",\"allergies\":\"null\",\"medical_conditions\":\"Asthma\",\"doctor_name\":\"\",\"doctor_phone\":\"\",\"current_address\":\"Igwuruta, Rivers State\",\"permanent_address\":\"Igwuruta, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-12 10:28:06'),
(109,6,1,'admin','assign_subjects','class',4,NULL,'{\"subjects\":[\"7\",\"21\",\"13\",\"17\",\"19\"]}','98.97.77.110','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/assign-subjects.php?class_id=4','2026-03-12 10:30:22'),
(110,6,1,'admin','create','student',22,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"1\",\"admission_date\":\"2025-09-11\",\"first_name\":\"Unagbu\",\"middle_name\":\"Chioma\",\"last_name\":\"Rita\",\"gender\":\"female\",\"date_of_birth\":\"2023-07-09\",\"student_email\":\"unagbusimon018@gmail.com\",\"student_phone\":\"08172689365\",\"guardian_name\":\"\",\"guardian_email\":\"\",\"guardian_phone\":\"\",\"guardian_relation\":null,\"guardian_address\":\"\",\"existing_parent_id\":53,\"blood_group\":\"O-\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":\"\",\"current_address\":\"Okomoko, Rivers State\",\"permanent_address\":\"Okomoko, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-12 10:33:48'),
(111,6,1,'admin','assign_subjects','class',4,NULL,'{\"subjects\":[\"3\",\"4\",\"16\",\"15\",\"12\",\"6\",\"5\",\"18\",\"2\",\"7\",\"21\",\"14\"]}','98.97.77.110','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1','/tenant/bitflux-wallet-1771434696/admin/assign-subjects.php?class_id=4','2026-03-12 10:35:50'),
(112,6,1,'admin','assign_subjects','class',12,NULL,'{\"subjects\":[\"3\",\"4\",\"16\",\"15\",\"12\",\"6\",\"5\",\"18\",\"2\",\"7\",\"21\",\"14\",\"11\",\"13\",\"8\",\"1\",\"17\",\"20\",\"9\",\"19\",\"10\"]}','98.97.77.110','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1','/tenant/bitflux-wallet-1771434696/admin/assign-subjects.php?class_id=12','2026-03-12 10:36:43'),
(113,6,1,'admin','assign_subjects','class',12,NULL,'{\"subjects\":[\"16\",\"15\",\"12\",\"6\",\"5\",\"18\",\"2\",\"7\",\"21\",\"14\",\"11\",\"13\",\"8\",\"1\",\"17\",\"9\",\"10\"]}','98.97.77.110','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1','/tenant/bitflux-wallet-1771434696/admin/assign-subjects.php?class_id=12','2026-03-12 10:37:01'),
(114,6,1,'admin','create','student',23,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":null,\"roll_number\":\"1\",\"admission_date\":\"2025-09-11\",\"first_name\":\"Okoye\",\"middle_name\":\"Nwabuogo\",\"last_name\":\"Maryann\",\"gender\":\"female\",\"date_of_birth\":\"2023-04-08\",\"student_email\":\"okoye.maryann@student.bitflux-wallet-1771434696.1773311892\",\"student_phone\":\"08144162280\",\"guardian_name\":\"\",\"guardian_email\":\"\",\"guardian_phone\":\"\",\"guardian_relation\":\"\",\"guardian_address\":\"\",\"existing_parent_id\":54,\"blood_group\":\"\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":\"\",\"current_address\":\"Igbo-Etche, Rivers State\",\"permanent_address\":\"Igbo-Etche, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-12 10:38:13'),
(115,6,1,'admin','update','student',23,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"1\",\"admission_number\":\"BIT-2025-0009\",\"first_name\":\"Okoye\",\"middle_name\":\"Nwabuogo\",\"last_name\":\"Maryann\",\"gender\":\"female\",\"date_of_birth\":\"2023-04-08\",\"student_phone\":\"08144162280\",\"student_email\":\"okoye.maryann@student.bitflux-wallet-1771434696.1773311892\",\"blood_group\":\"\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":\"\",\"current_address\":\"Igbo-Etche, Rivers State\",\"permanent_address\":\"Igbo-Etche, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-12 10:39:00'),
(116,6,1,'admin','update','student',21,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"1\",\"admission_number\":\"BIT-2025-0007\",\"first_name\":\"Uzochukwu\",\"middle_name\":\"Chiemela\",\"last_name\":\"Victory\",\"gender\":\"female\",\"date_of_birth\":\"2023-11-02\",\"student_phone\":\"09099926700\",\"student_email\":\"zubuetechhub@gmail.com\",\"blood_group\":\"\",\"allergies\":\"null\",\"medical_conditions\":\"Asthma\",\"doctor_name\":\"\",\"doctor_phone\":\"\",\"current_address\":\"Igwuruta, Rivers State\",\"permanent_address\":\"Igwuruta, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-12 10:39:27'),
(117,6,1,'admin','create','student',24,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"1\",\"admission_date\":\"2025-09-11\",\"first_name\":\"Adeyemi\",\"middle_name\":\"Toluwani\",\"last_name\":\"Hephzibah\",\"gender\":\"female\",\"date_of_birth\":\"2023-08-19\",\"student_email\":\"adeyemi.hephzibah@student.bitflux-wallet-1771434696\",\"student_phone\":null,\"guardian_name\":\"\",\"guardian_email\":\"\",\"guardian_phone\":null,\"guardian_relation\":null,\"guardian_address\":\"\",\"existing_parent_id\":55,\"blood_group\":\"B+\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":null,\"current_address\":\"Umuechem, Rivers State\",\"permanent_address\":\"Umuechem, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-12 10:43:02'),
(118,6,1,'admin','assign_subjects','class',2,NULL,'{\"subjects\":[\"4\",\"12\",\"6\",\"5\",\"2\",\"7\",\"21\",\"11\",\"13\",\"8\",\"1\",\"20\",\"9\",\"19\",\"10\"]}','98.97.77.110','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/assign-subjects.php?class_id=2','2026-03-12 10:50:18'),
(119,6,1,'admin','create','student',25,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"2\",\"admission_date\":\"2025-09-11\",\"first_name\":\"Adetifa\",\"middle_name\":\"Mayorkun\",\"last_name\":\"Israel\",\"gender\":\"male\",\"date_of_birth\":\"2023-10-01\",\"student_email\":\"adetifa.israel@student.bitflux-wallet-1771434696\",\"student_phone\":null,\"guardian_name\":\"\",\"guardian_email\":\"\",\"guardian_phone\":null,\"guardian_relation\":null,\"guardian_address\":\"\",\"existing_parent_id\":56,\"blood_group\":\"B-\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":null,\"current_address\":\"Okomoko, Rivers State\",\"permanent_address\":\"Okomoko, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-12 10:50:43'),
(120,6,1,'admin','create','student',26,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"2\",\"admission_date\":\"2025-09-11\",\"first_name\":\"Ovieva\",\"middle_name\":\"Oghenetega\",\"last_name\":\"Favour\",\"gender\":\"male\",\"date_of_birth\":\"2023-10-04\",\"student_email\":\"ovieva.favour@student.bitflux-wallet-1771434696\",\"student_phone\":null,\"guardian_name\":\"\",\"guardian_email\":\"\",\"guardian_phone\":null,\"guardian_relation\":null,\"guardian_address\":\"\",\"existing_parent_id\":57,\"blood_group\":\"O-\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":null,\"current_address\":\"Umuechem, Rivers State\",\"permanent_address\":\"Umuechem, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-12 10:57:28'),
(121,6,1,'admin','create','student',27,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"2\",\"admission_date\":\"2025-09-11\",\"first_name\":\"Tamuno\",\"middle_name\":\"Biebele\",\"last_name\":\"Rejoice\",\"gender\":\"female\",\"date_of_birth\":\"2023-02-07\",\"student_email\":\"tamuno.rejoice@student.bitflux-wallet-1771434696\",\"student_phone\":null,\"guardian_name\":\"\",\"guardian_email\":\"\",\"guardian_phone\":null,\"guardian_relation\":null,\"guardian_address\":\"\",\"existing_parent_id\":58,\"blood_group\":\"O-\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":null,\"current_address\":\"Igbo-Etche, Rivers State\",\"permanent_address\":\"Igbo-Etche, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-12 11:00:17'),
(122,6,1,'admin','create','student',28,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"2\",\"admission_date\":\"2025-09-11\",\"first_name\":\"Bagshaw\",\"middle_name\":\"Biobele\",\"last_name\":\"Joy\",\"gender\":\"female\",\"date_of_birth\":\"2023-05-12\",\"student_email\":\"bagshaw.joy@student.bitflux-wallet-1771434696\",\"student_phone\":null,\"guardian_name\":\"\",\"guardian_email\":\"\",\"guardian_phone\":null,\"guardian_relation\":null,\"guardian_address\":\"\",\"existing_parent_id\":59,\"blood_group\":\"B-\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":null,\"current_address\":\"Igwuruta, Rivers State\",\"permanent_address\":\"Igwuruta, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-12 11:05:59'),
(123,6,1,'admin','create','student',29,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"3\",\"admission_date\":\"2025-09-11\",\"first_name\":\"Ogbuogu\",\"middle_name\":\"Chibuenyim\",\"last_name\":\"Christopher\",\"gender\":\"male\",\"date_of_birth\":\"2023-04-06\",\"student_email\":\"ogbuogu.christopher@student.bitflux-wallet-1771434696\",\"student_phone\":null,\"guardian_name\":\"\",\"guardian_email\":\"\",\"guardian_phone\":null,\"guardian_relation\":null,\"guardian_address\":\"\",\"existing_parent_id\":60,\"blood_group\":\"O-\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":null,\"current_address\":\"Umuechem, Rivers State\",\"permanent_address\":\"Umuechem, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-12 11:08:19'),
(124,6,1,'admin','create','student',30,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"3\",\"admission_date\":\"2025-09-11\",\"first_name\":\"Sylvester\",\"middle_name\":\"Onyedikachi\",\"last_name\":\"Favour\",\"gender\":\"\",\"date_of_birth\":\"2023-12-06\",\"student_email\":\"sylvester.favour@student.bitflux-wallet-1771434696\",\"student_phone\":null,\"guardian_name\":\"\",\"guardian_email\":\"\",\"guardian_phone\":null,\"guardian_relation\":null,\"guardian_address\":\"\",\"existing_parent_id\":61,\"blood_group\":\"O+\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":null,\"current_address\":\"Chokocho, Rivers State\",\"permanent_address\":\"Chokocho, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-12 11:11:28'),
(125,6,1,'admin','create','student',31,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"3\",\"admission_date\":\"2025-09-11\",\"first_name\":\"Okere\",\"middle_name\":\"Iheanyi\",\"last_name\":\"Francis\",\"gender\":\"male\",\"date_of_birth\":\"2023-02-12\",\"student_email\":\"okere.francis@student.bitflux-wallet-1771434696\",\"student_phone\":null,\"guardian_name\":\"\",\"guardian_email\":\"\",\"guardian_phone\":null,\"guardian_relation\":null,\"guardian_address\":\"\",\"existing_parent_id\":62,\"blood_group\":\"AB+\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":null,\"current_address\":\"Chokocho, Rivers State\",\"permanent_address\":\"Chokocho, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-12 11:13:52'),
(126,6,1,'admin','create','student',32,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"3\",\"admission_date\":\"2025-09-11\",\"first_name\":\"Amadi\",\"middle_name\":\"Kelechi\",\"last_name\":\"ThankGod\",\"gender\":\"male\",\"date_of_birth\":\"2023-03-12\",\"student_email\":\"amadi.thankgod@student.bitflux-wallet-1771434696\",\"student_phone\":null,\"guardian_name\":\"\",\"guardian_email\":\"\",\"guardian_phone\":null,\"guardian_relation\":null,\"guardian_address\":\"\",\"existing_parent_id\":63,\"blood_group\":\"AB+\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":null,\"current_address\":\"Umuchem, Rivers State\",\"permanent_address\":\"Umuchem, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-12 11:21:26'),
(127,6,1,'admin','update','student',30,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"3\",\"admission_number\":\"BIT-2025-0016\",\"first_name\":\"Sylvester\",\"middle_name\":\"Onyedikachi\",\"last_name\":\"Favour\",\"gender\":\"male\",\"date_of_birth\":\"2023-12-06\",\"student_phone\":null,\"student_email\":\"sylvester.favour@student.bitflux-wallet-1771434696\",\"blood_group\":\"O+\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":null,\"current_address\":\"Chokocho, Rivers State\",\"permanent_address\":\"Chokocho, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\",\"password\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/edit-student.php?id=30','2026-03-12 11:58:30'),
(128,6,1,'admin','update','student',32,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"3\",\"admission_number\":\"BIT-2025-0018\",\"first_name\":\"Amadi\",\"middle_name\":\"Kelechi\",\"last_name\":\"ThankGod\",\"gender\":\"female\",\"date_of_birth\":\"2023-03-12\",\"student_phone\":null,\"student_email\":\"amadi.thankgod@student.bitflux-wallet-1771434696\",\"blood_group\":\"AB+\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":null,\"current_address\":\"Umuchem, Rivers State\",\"permanent_address\":\"Umuchem, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\",\"password\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/edit-student.php?id=32','2026-03-12 12:06:21'),
(129,6,1,'admin','update','student',32,NULL,'{\"academic_year_id\":1,\"class_id\":4,\"section_id\":5,\"roll_number\":\"3\",\"admission_number\":\"BIT-2025-0018\",\"first_name\":\"Amadi\",\"middle_name\":\"Kelechi\",\"last_name\":\"ThankGod\",\"gender\":\"male\",\"date_of_birth\":\"2023-03-12\",\"student_phone\":null,\"student_email\":\"amadi.thankgod@student.bitflux-wallet-1771434696\",\"blood_group\":\"AB+\",\"allergies\":\"null\",\"medical_conditions\":\"null\",\"doctor_name\":\"\",\"doctor_phone\":null,\"current_address\":\"Umuchem, Rivers State\",\"permanent_address\":\"Umuchem, Rivers State\",\"previous_school\":\"\",\"previous_class\":\"\",\"transfer_certificate_no\":\"\",\"password\":\"\"}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/edit-student.php?id=32','2026-03-12 12:06:46'),
(130,6,1,'admin','create','teacher',10,NULL,'{\"employee_id\":\"TCH-2026-8373\",\"name\":\"Uzodinma Udochukwu Timothy\",\"email\":\"zubetechub@gmail.com\",\"phone\":\"09070520000\",\"gender\":\"male\",\"date_of_birth\":\"2004-09-02\",\"fathers_name\":\"Uzodinma Nzubechukwu Henry\",\"mothers_name\":\"Uzodinma Amarachi Promise\",\"marital_status\":\"Unmarried\",\"contract_type\":\"Permanent\",\"shift\":\"Day Shift\",\"work_location\":\"onsite\",\"joining_date\":\"2019-04-12\",\"qualification\":\"B.Sc\",\"experience_years\":7,\"blood_group\":\"AB+\",\"height\":\"5&quot;8\",\"weight\":\"60kg\",\"bank_name\":\"\",\"bank_account\":\"\",\"ifsc_code\":\"\",\"national_id\":\"\",\"current_address\":\"chokocho\",\"permanent_address\":\"etche\",\"previous_school\":\"\",\"previous_school_address\":\"chokocho, etche\",\"facebook_link\":\"\",\"linkedin_link\":\"\",\"instagram_link\":\"\",\"youtube_link\":\"\",\"details\":\"\",\"password\":\"\",\"profile_photo\":null,\"assigned_classes\":[],\"assigned_subjects\":[{\"id\":1,\"school_id\":6,\"name\":\"mathematic\",\"code\":\"maths\",\"type\":\"core\",\"description\":\"easy\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-04 21:29:35\"},{\"id\":20,\"school_id\":6,\"name\":\"Quantitative Reasoning \",\"code\":\"QTR\",\"type\":\"elective\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:28:51\"}]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-12 12:45:51'),
(131,6,1,'admin','create','teacher',11,NULL,'{\"employee_id\":\"TCH-2026-8374\",\"name\":\"Okpobiri Ijeoma Felicia\",\"email\":\"feliciaonyebuchi@gmail.com\",\"phone\":\"08057646999\",\"gender\":\"female\",\"date_of_birth\":\"1971-06-11\",\"fathers_name\":\"Onyebuchi Emezie Solomon\",\"mothers_name\":\"Onyebuchi Bridget\",\"marital_status\":\"Married\",\"contract_type\":\"Permanent\",\"shift\":\"Day Shift\",\"work_location\":\"onsite\",\"joining_date\":\"2020-08-19\",\"qualification\":\"B.Ed\",\"experience_years\":6,\"blood_group\":\"B+\",\"height\":\"5&quot;6\",\"weight\":\"60kg\",\"bank_name\":\"\",\"bank_account\":\"\",\"ifsc_code\":\"\",\"national_id\":\"\",\"current_address\":\"chokocho\",\"permanent_address\":\"etche\",\"previous_school\":\"\",\"previous_school_address\":\"chokocho, etche\",\"facebook_link\":\"\",\"linkedin_link\":\"\",\"instagram_link\":\"\",\"youtube_link\":\"\",\"details\":\"\",\"password\":\"\",\"profile_photo\":null,\"assigned_classes\":[],\"assigned_subjects\":[{\"id\":2,\"school_id\":6,\"name\":\"english\",\"code\":\"eng101\",\"type\":\"core\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-05 19:34:56\"},{\"id\":9,\"school_id\":6,\"name\":\"Social Studies\",\"code\":\"SOS\",\"type\":\"core\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:17:05\"},{\"id\":19,\"school_id\":6,\"name\":\"Verbal Reasoning\",\"code\":\"VRB\",\"type\":\"elective\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:26:30\"}]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-12 12:55:41'),
(132,6,1,'admin','create','teacher',12,NULL,'{\"employee_id\":\"TCH-2026-8375\",\"name\":\"Onyeuchi Nkechi Katherine\",\"email\":\"katrell009@gmail.com\",\"phone\":\"08097667541\",\"gender\":\"female\",\"date_of_birth\":\"1983-04-09\",\"fathers_name\":\"Onyebuchi Obinna Martin\",\"mothers_name\":\"Onyebuchi Chinonyelum Cecilia\",\"marital_status\":\"Unmarried\",\"contract_type\":\"Permanent\",\"shift\":\"Day Shift\",\"work_location\":\"onsite\",\"joining_date\":\"2020-07-10\",\"qualification\":\"B.Ed\",\"experience_years\":8,\"blood_group\":\"O-\",\"height\":\"5&quot;5\",\"weight\":\"55kg\",\"bank_name\":\"\",\"bank_account\":\"\",\"ifsc_code\":\"\",\"national_id\":\"\",\"current_address\":\"chokocho\",\"permanent_address\":\"etche\",\"previous_school\":\"International Unity School\",\"previous_school_address\":\"chokocho, etche\",\"facebook_link\":\"\",\"linkedin_link\":\"\",\"instagram_link\":\"\",\"youtube_link\":\"\",\"details\":\"\",\"password\":\"\",\"profile_photo\":null,\"assigned_classes\":[],\"assigned_subjects\":[{\"id\":12,\"school_id\":6,\"name\":\"Christian Religious Knowledge\",\"code\":\"CRK\",\"type\":\"elective\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:20:53\"},{\"id\":6,\"school_id\":6,\"name\":\"Civic Education\",\"code\":\"CEd\",\"type\":\"elective\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:12:06\"},{\"id\":18,\"school_id\":6,\"name\":\"Economics\",\"code\":\"ECO\",\"type\":\"elective\",\"description\":\"\",\"credit_hours\":\"1.0\",\"is_active\":1,\"created_at\":\"2026-03-06 09:24:40\"}]}','98.97.77.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,'2026-03-12 13:11:43'),
(133,6,1,'admin','create','student',33,NULL,'{\"academic_year_id\":1,\"class_id\":2,\"section_id\":2,\"roll_number\":\"5\",\"admission_date\":\"2026-03-14\",\"first_name\":\"David\",\"middle_name\":\"Chi\",\"last_name\":\"Aniago\",\"gender\":\"male\",\"date_of_birth\":\"2020-03-14\",\"student_email\":\"daveaniago91@gmail.com\",\"student_phone\":null,\"guardian_name\":\"Beatrice\",\"guardian_email\":\"davidaniag78@gmail.com\",\"guardian_phone\":\"023\",\"guardian_relation\":\"guardian\",\"guardian_address\":\"Gu\",\"existing_parent_id\":null,\"blood_group\":\"O-\",\"allergies\":\"Null\",\"medical_conditions\":\"Null\",\"doctor_name\":\"\",\"doctor_phone\":null,\"current_address\":\"Bom\",\"permanent_address\":\"Bag\",\"previous_school\":\"Gh\",\"previous_class\":\"R\",\"transfer_certificate_no\":\"34\"}','102.90.116.109','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/add-new-student.php','2026-03-14 04:29:07'),
(134,6,1,'admin','assign_subjects','class',4,NULL,'{\"subjects\":[\"3\",\"4\",\"16\",\"15\",\"12\",\"6\",\"5\",\"18\",\"2\",\"7\",\"21\",\"14\",\"11\",\"1\",\"9\"]}','102.90.116.184','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','/tenant/bitflux-wallet-1771434696/admin/assign-subjects.php?class_id=4','2026-03-14 16:37:15');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_history`
--

DROP TABLE IF EXISTS `backup_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `backup_type` enum('full','incremental','differential','schema_only') DEFAULT 'full',
  `storage_type` enum('local','s3','ftp','google_drive') DEFAULT 'local',
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `database_size` bigint(20) DEFAULT NULL,
  `table_count` int(10) DEFAULT NULL,
  `status` enum('pending','in_progress','completed','failed','cancelled') DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `retention_days` int(10) DEFAULT 30,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_backup_type` (`backup_type`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_school_status` (`school_id`,`status`,`created_at`),
  KEY `idx_backup_history_school_status` (`school_id`,`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_history`
--

LOCK TABLES `backup_history` WRITE;
/*!40000 ALTER TABLE `backup_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_history`
--

DROP TABLE IF EXISTS `billing_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `billing_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `subscription_id` int(10) unsigned DEFAULT NULL,
  `invoice_number` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `tax_amount` decimal(10,2) DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'NGN',
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_status` enum('pending','paid','failed','refunded') DEFAULT 'pending',
  `payment_date` timestamp NULL DEFAULT NULL,
  `due_date` date NOT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `payment_gateway` varchar(50) DEFAULT NULL,
  `gateway_response` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `subscription_id` (`subscription_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_payment_status` (`payment_status`),
  KEY `idx_payment_date` (`payment_date`),
  KEY `idx_school_status` (`school_id`,`payment_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_history`
--

LOCK TABLES `billing_history` WRITE;
/*!40000 ALTER TABLE `billing_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campuses`
--

DROP TABLE IF EXISTS `campuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL COMMENT 'For geofencing',
  `longitude` decimal(11,8) DEFAULT NULL COMMENT 'For geofencing',
  `radius` int(10) unsigned DEFAULT NULL COMMENT 'Allowed radius in meters',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_campus_code` (`school_id`,`code`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campuses`
--

LOCK TABLES `campuses` WRITE;
/*!40000 ALTER TABLE `campuses` DISABLE KEYS */;
INSERT INTO `campuses` VALUES
(1,6,'Main Campus','MAIN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-03-16 07:23:11','2026-03-16 07:23:11');
/*!40000 ALTER TABLE `campuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cbt_attempts`
--

DROP TABLE IF EXISTS `cbt_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cbt_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `start_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `end_time` timestamp NULL DEFAULT NULL,
  `status` enum('in_progress','completed','scored','expired') DEFAULT 'in_progress',
  `total_score` decimal(5,2) DEFAULT NULL,
  `percentage` decimal(5,2) DEFAULT NULL,
  `graded_by` int(10) unsigned DEFAULT NULL COMMENT 'For essay questions graded manually',
  `graded_at` timestamp NULL DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_test` (`test_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_graded_by` (`graded_by`),
  CONSTRAINT `fk_cbt_attempts_graded_by` FOREIGN KEY (`graded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_cbt_attempts_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_cbt_attempts_test` FOREIGN KEY (`test_id`) REFERENCES `cbt_tests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cbt_attempts`
--

LOCK TABLES `cbt_attempts` WRITE;
/*!40000 ALTER TABLE `cbt_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `cbt_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cbt_options`
--

DROP TABLE IF EXISTS `cbt_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cbt_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question_id` int(10) unsigned NOT NULL,
  `option_text` text NOT NULL,
  `is_correct` tinyint(1) DEFAULT 0,
  `order` int(10) unsigned DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_question` (`question_id`),
  CONSTRAINT `fk_cbt_options_question` FOREIGN KEY (`question_id`) REFERENCES `cbt_questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cbt_options`
--

LOCK TABLES `cbt_options` WRITE;
/*!40000 ALTER TABLE `cbt_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `cbt_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cbt_questions`
--

DROP TABLE IF EXISTS `cbt_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cbt_questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_id` int(10) unsigned NOT NULL,
  `question_text` text NOT NULL,
  `question_type` enum('multiple_choice','true_false','essay') NOT NULL,
  `marks` decimal(5,2) NOT NULL,
  `difficulty_level` enum('easy','medium','hard') DEFAULT 'medium',
  `attachment` varchar(500) DEFAULT NULL COMMENT 'Image/audio/video path',
  `order` int(10) unsigned DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_test` (`test_id`),
  CONSTRAINT `fk_cbt_questions_test` FOREIGN KEY (`test_id`) REFERENCES `cbt_tests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cbt_questions`
--

LOCK TABLES `cbt_questions` WRITE;
/*!40000 ALTER TABLE `cbt_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `cbt_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cbt_responses`
--

DROP TABLE IF EXISTS `cbt_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cbt_responses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attempt_id` int(10) unsigned NOT NULL,
  `question_id` int(10) unsigned NOT NULL,
  `selected_option_id` int(10) unsigned DEFAULT NULL COMMENT 'For MCQ',
  `answer_text` text DEFAULT NULL COMMENT 'For essay',
  `is_correct` tinyint(1) DEFAULT NULL COMMENT 'For auto-graded questions',
  `marks_obtained` decimal(5,2) DEFAULT NULL,
  `graded_by` int(10) unsigned DEFAULT NULL,
  `graded_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_attempt` (`attempt_id`),
  KEY `idx_question` (`question_id`),
  KEY `idx_option` (`selected_option_id`),
  KEY `idx_graded_by` (`graded_by`),
  CONSTRAINT `fk_cbt_responses_attempt` FOREIGN KEY (`attempt_id`) REFERENCES `cbt_attempts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_cbt_responses_graded_by` FOREIGN KEY (`graded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_cbt_responses_option` FOREIGN KEY (`selected_option_id`) REFERENCES `cbt_options` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_cbt_responses_question` FOREIGN KEY (`question_id`) REFERENCES `cbt_questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cbt_responses`
--

LOCK TABLES `cbt_responses` WRITE;
/*!40000 ALTER TABLE `cbt_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `cbt_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cbt_results`
--

DROP TABLE IF EXISTS `cbt_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cbt_results` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attempt_id` int(10) unsigned NOT NULL,
  `rank` int(10) unsigned DEFAULT NULL,
  `grade` varchar(5) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `published` tinyint(1) DEFAULT 0,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `attempt_id` (`attempt_id`),
  CONSTRAINT `fk_cbt_results_attempt` FOREIGN KEY (`attempt_id`) REFERENCES `cbt_attempts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cbt_results`
--

LOCK TABLES `cbt_results` WRITE;
/*!40000 ALTER TABLE `cbt_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `cbt_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cbt_tests`
--

DROP TABLE IF EXISTS `cbt_tests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cbt_tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `paper_id` int(10) unsigned NOT NULL,
  `is_random_questions` tinyint(1) DEFAULT 0,
  `is_random_options` tinyint(1) DEFAULT 0,
  `allow_review` tinyint(1) DEFAULT 1 COMMENT 'Can student review answers after submission?',
  `show_result_immediately` tinyint(1) DEFAULT 0,
  `scheduled_start` datetime DEFAULT NULL COMMENT 'If null, available anytime',
  `scheduled_end` datetime DEFAULT NULL,
  `pass_marks` decimal(5,2) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `paper_id` (`paper_id`),
  KEY `idx_created_by` (`created_by`),
  CONSTRAINT `fk_cbt_tests_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_cbt_tests_paper` FOREIGN KEY (`paper_id`) REFERENCES `exam_papers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cbt_tests`
--

LOCK TABLES `cbt_tests` WRITE;
/*!40000 ALTER TABLE `cbt_tests` DISABLE KEYS */;
/*!40000 ALTER TABLE `cbt_tests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificate_templates`
--

DROP TABLE IF EXISTS `certificate_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificate_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` enum('leaving','character','achievement','participation','other') DEFAULT 'other',
  `template_html` text NOT NULL,
  `orientation` enum('portrait','landscape') DEFAULT 'portrait',
  `default_fields` text DEFAULT NULL COMMENT 'JSON of placeholder fields',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificate_templates`
--

LOCK TABLES `certificate_templates` WRITE;
/*!40000 ALTER TABLE `certificate_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `certificate_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificates_issued`
--

DROP TABLE IF EXISTS `certificates_issued`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificates_issued` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `template_id` int(10) unsigned DEFAULT NULL,
  `certificate_number` varchar(100) NOT NULL,
  `issue_date` date NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL COMMENT 'Generated PDF path',
  `metadata` text DEFAULT NULL COMMENT 'JSON of dynamic data used',
  `issued_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `certificate_number` (`certificate_number`),
  KEY `idx_school` (`school_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_template` (`template_id`),
  KEY `idx_issued_by` (`issued_by`),
  CONSTRAINT `fk_certificates_issued_issued_by` FOREIGN KEY (`issued_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_certificates_issued_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_certificates_issued_template` FOREIGN KEY (`template_id`) REFERENCES `certificate_templates` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificates_issued`
--

LOCK TABLES `certificates_issued` WRITE;
/*!40000 ALTER TABLE `certificates_issued` DISABLE KEYS */;
/*!40000 ALTER TABLE `certificates_issued` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `class_subjects`
--

DROP TABLE IF EXISTS `class_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `class_subjects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` int(10) unsigned NOT NULL,
  `subject_id` int(10) unsigned NOT NULL,
  `teacher_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_class_subject` (`class_id`,`subject_id`),
  KEY `subject_id` (`subject_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_teacher` (`teacher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_subjects`
--

LOCK TABLES `class_subjects` WRITE;
/*!40000 ALTER TABLE `class_subjects` DISABLE KEYS */;
INSERT INTO `class_subjects` VALUES
(50,12,16,NULL,'2026-03-12 10:37:01'),
(51,12,15,NULL,'2026-03-12 10:37:01'),
(52,12,12,NULL,'2026-03-12 10:37:01'),
(53,12,6,NULL,'2026-03-12 10:37:01'),
(54,12,5,NULL,'2026-03-12 10:37:01'),
(55,12,18,NULL,'2026-03-12 10:37:01'),
(56,12,2,NULL,'2026-03-12 10:37:01'),
(57,12,7,NULL,'2026-03-12 10:37:01'),
(58,12,21,NULL,'2026-03-12 10:37:01'),
(59,12,14,NULL,'2026-03-12 10:37:01'),
(60,12,11,NULL,'2026-03-12 10:37:01'),
(61,12,13,NULL,'2026-03-12 10:37:01'),
(62,12,8,NULL,'2026-03-12 10:37:01'),
(63,12,1,78,'2026-03-12 10:37:01'),
(64,12,17,NULL,'2026-03-12 10:37:01'),
(65,12,9,79,'2026-03-12 10:37:01'),
(66,12,10,NULL,'2026-03-12 10:37:01'),
(67,2,4,NULL,'2026-03-12 10:50:18'),
(68,2,12,NULL,'2026-03-12 10:50:18'),
(69,2,6,NULL,'2026-03-12 10:50:18'),
(70,2,5,NULL,'2026-03-12 10:50:18'),
(71,2,2,NULL,'2026-03-12 10:50:18'),
(72,2,7,NULL,'2026-03-12 10:50:18'),
(73,2,21,NULL,'2026-03-12 10:50:18'),
(74,2,11,NULL,'2026-03-12 10:50:18'),
(75,2,13,NULL,'2026-03-12 10:50:18'),
(76,2,8,NULL,'2026-03-12 10:50:18'),
(77,2,1,NULL,'2026-03-12 10:50:18'),
(78,2,20,78,'2026-03-12 10:50:18'),
(79,2,9,NULL,'2026-03-12 10:50:18'),
(80,2,19,79,'2026-03-12 10:50:18'),
(81,2,10,NULL,'2026-03-12 10:50:18'),
(82,4,3,NULL,'2026-03-14 16:37:15'),
(83,4,4,NULL,'2026-03-14 16:37:15'),
(84,4,16,NULL,'2026-03-14 16:37:15'),
(85,4,15,NULL,'2026-03-14 16:37:15'),
(86,4,12,NULL,'2026-03-14 16:37:15'),
(87,4,6,NULL,'2026-03-14 16:37:15'),
(88,4,5,NULL,'2026-03-14 16:37:15'),
(89,4,18,NULL,'2026-03-14 16:37:15'),
(90,4,2,NULL,'2026-03-14 16:37:15'),
(91,4,7,NULL,'2026-03-14 16:37:15'),
(92,4,21,NULL,'2026-03-14 16:37:15'),
(93,4,14,NULL,'2026-03-14 16:37:15'),
(94,4,11,NULL,'2026-03-14 16:37:15'),
(95,4,1,NULL,'2026-03-14 16:37:15'),
(96,4,9,NULL,'2026-03-14 16:37:15');
/*!40000 ALTER TABLE `class_subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `grade_level` varchar(50) DEFAULT NULL,
  `class_teacher_id` int(10) unsigned DEFAULT NULL,
  `capacity` int(10) unsigned DEFAULT 40,
  `room_number` varchar(50) DEFAULT NULL,
  `academic_year_id` int(10) unsigned NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_class_school` (`school_id`,`academic_year_id`,`code`),
  KEY `class_teacher_id` (`class_teacher_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_year` (`academic_year_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
INSERT INTO `classes` VALUES
(1,6,NULL,'grade 10','G10','learning','Junior secoundary school 2',9,20,'A101',1,1,'2026-03-04 20:30:17'),
(2,6,NULL,'grade 1','g1','','primary',NULL,19,'b202',1,1,'2026-03-05 18:33:25'),
(3,6,NULL,'Primary 3','Pri 3','','primary',12,16,'c303',1,1,'2026-03-06 08:00:26'),
(4,6,NULL,'Kindergaten','KG','','Kindergaten',NULL,12,'A1',1,1,'2026-03-06 08:41:57'),
(5,6,NULL,'Nursery 1','NUR 1','','Nursery',NULL,23,'B1',1,1,'2026-03-06 08:45:53'),
(6,6,NULL,'Nursery 2','NUR 2','','Nursery',NULL,20,'B2',1,1,'2026-03-06 08:48:10'),
(7,6,NULL,'Nursery 3','NUR 3','','Nursery',NULL,19,'B3',1,1,'2026-03-06 08:49:19'),
(8,6,NULL,'Primary 1','PRY 1','','Primary',NULL,24,'C1',1,1,'2026-03-06 08:53:40'),
(9,6,NULL,'Primary 2','PRY 2','','Primary',NULL,25,'C2',1,1,'2026-03-06 08:55:20'),
(10,6,NULL,'Primary 4','PRY 4','','Primary',NULL,24,'C4',1,1,'2026-03-06 08:59:16'),
(11,6,NULL,'Primary 5','PRY 5','','Primary',NULL,26,'C5',1,1,'2026-03-06 09:00:49'),
(12,6,NULL,'Junior Secondary School 1','JSS1','','Secondary',17,30,'D1',1,1,'2026-03-06 09:02:37'),
(13,6,NULL,'Junior Secondary School 3','JSS3','','Secondary',NULL,28,'D3',1,1,'2026-03-06 09:04:10'),
(14,6,NULL,'Senior Secondary School 1','SSS1','','Secondary',NULL,33,'DD1',1,1,'2026-03-06 09:11:37'),
(15,6,NULL,'Senior Secondary School 2','SSS2','','Secondary',39,35,'DD2',1,1,'2026-03-06 09:12:39'),
(16,6,NULL,'Senior Secondary School 3','SSS3','','Secondary',NULL,31,'DD3',1,1,'2026-03-06 09:13:33');
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation_participants`
--

DROP TABLE IF EXISTS `conversation_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversation_participants` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `conversation_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_type` enum('admin','teacher','student','parent','accountant','librarian','receptionist') NOT NULL,
  `last_read_at` timestamp NULL DEFAULT NULL,
  `is_muted` tinyint(1) DEFAULT 0,
  `is_archived` tinyint(1) DEFAULT 0,
  `is_deleted` tinyint(1) DEFAULT 0,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `left_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_participant` (`conversation_id`,`user_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_conversation` (`conversation_id`),
  KEY `idx_user_unread` (`user_id`,`last_read_at`),
  KEY `idx_user_archived` (`user_id`,`is_archived`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation_participants`
--

LOCK TABLES `conversation_participants` WRITE;
/*!40000 ALTER TABLE `conversation_participants` DISABLE KEYS */;
INSERT INTO `conversation_participants` VALUES
(1,1,1,'admin','2026-03-09 12:04:11',1,0,0,'2026-03-08 11:47:00',NULL,'2026-03-08 11:47:00'),
(2,1,9,'teacher',NULL,0,0,0,'2026-03-08 11:47:00',NULL,'2026-03-08 11:47:00'),
(3,2,1,'admin','2026-03-23 09:00:06',0,0,0,'2026-03-08 11:47:32',NULL,'2026-03-08 11:47:32'),
(4,2,11,'parent',NULL,0,0,0,'2026-03-08 11:47:32',NULL,'2026-03-08 11:47:32'),
(5,3,1,'admin','2026-03-09 02:38:05',0,0,0,'2026-03-08 12:11:11',NULL,'2026-03-08 12:11:11'),
(6,3,13,'parent',NULL,0,0,0,'2026-03-08 12:11:11',NULL,'2026-03-08 12:11:11'),
(7,4,1,'admin','2026-03-09 02:38:10',0,0,0,'2026-03-08 13:55:59',NULL,'2026-03-08 13:55:59'),
(8,4,6,'parent',NULL,0,0,0,'2026-03-08 13:55:59',NULL,'2026-03-08 13:55:59'),
(9,5,1,'admin','2026-03-08 13:59:51',0,0,1,'2026-03-08 13:56:27','2026-03-08 13:59:56','2026-03-08 13:56:27'),
(10,5,9,'teacher',NULL,0,0,0,'2026-03-08 13:56:27',NULL,'2026-03-08 13:56:27'),
(11,5,13,'parent',NULL,0,0,0,'2026-03-08 13:56:27',NULL,'2026-03-08 13:56:27'),
(12,5,11,'parent',NULL,0,0,0,'2026-03-08 13:56:27',NULL,'2026-03-08 13:56:27'),
(13,6,1,'admin','2026-03-08 16:53:20',0,0,0,'2026-03-08 14:07:25',NULL,'2026-03-08 14:07:25'),
(14,6,4,'parent',NULL,0,0,0,'2026-03-08 14:07:25',NULL,'2026-03-08 14:07:25'),
(15,7,1,'admin','2026-03-10 11:57:13',0,0,1,'2026-03-09 12:02:00','2026-03-10 11:57:18','2026-03-09 12:02:00'),
(16,7,13,'parent',NULL,0,0,0,'2026-03-09 12:02:00',NULL,'2026-03-09 12:02:00'),
(17,7,11,'parent',NULL,0,0,0,'2026-03-09 12:02:00',NULL,'2026-03-09 12:02:00'),
(18,8,1,'admin','2026-03-10 11:57:26',0,0,0,'2026-03-09 12:03:24',NULL,'2026-03-09 12:03:24'),
(19,8,17,'teacher',NULL,0,0,0,'2026-03-09 12:03:24',NULL,'2026-03-09 12:03:24');
/*!40000 ALTER TABLE `conversation_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversations`
--

DROP TABLE IF EXISTS `conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `conversation_type` enum('individual','group') DEFAULT 'individual',
  `subject` varchar(255) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `last_message_id` int(10) unsigned DEFAULT NULL,
  `last_message_at` timestamp NULL DEFAULT NULL,
  `is_archived` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_last_message` (`last_message_id`),
  KEY `idx_last_message_at` (`last_message_at`),
  KEY `idx_school_archived` (`school_id`,`is_archived`,`last_message_at`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversations`
--

LOCK TABLES `conversations` WRITE;
/*!40000 ALTER TABLE `conversations` DISABLE KEYS */;
INSERT INTO `conversations` VALUES
(1,6,'individual',NULL,1,18,'2026-03-08 16:40:26',0,'2026-03-08 11:47:00','2026-03-08 16:40:26'),
(2,6,'individual',NULL,1,20,'2026-03-09 11:59:21',0,'2026-03-08 11:47:32','2026-03-09 11:59:21'),
(3,6,'individual',NULL,1,6,'2026-03-08 12:19:47',0,'2026-03-08 12:11:11','2026-03-08 12:19:47'),
(4,0,'individual',NULL,1,11,'2026-03-08 14:01:38',0,'2026-03-08 13:55:59','2026-03-08 14:01:38'),
(5,0,'group','family of emezie',1,10,'2026-03-08 13:56:50',0,'2026-03-08 13:56:27','2026-03-08 13:56:50'),
(6,0,'individual',NULL,1,15,'2026-03-08 14:38:30',0,'2026-03-08 14:07:25','2026-03-08 14:38:30'),
(7,0,'group','emezie family',1,23,'2026-03-09 12:02:44',0,'2026-03-09 12:02:00','2026-03-09 12:02:44'),
(8,0,'individual',NULL,1,NULL,'2026-03-09 12:03:24',0,'2026-03-09 12:03:24','2026-03-09 12:03:24');
/*!40000 ALTER TABLE `conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `curriculum_outlines`
--

DROP TABLE IF EXISTS `curriculum_outlines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `curriculum_outlines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `subject_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `week` int(10) unsigned DEFAULT NULL,
  `topic` varchar(255) NOT NULL,
  `objectives` text DEFAULT NULL,
  `resources` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_class_subject` (`class_id`,`subject_id`),
  KEY `idx_term` (`term_id`),
  KEY `idx_school` (`school_id`),
  KEY `fk_curriculum_subject` (`subject_id`),
  CONSTRAINT `fk_curriculum_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_curriculum_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_curriculum_term` FOREIGN KEY (`term_id`) REFERENCES `academic_terms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `curriculum_outlines`
--

LOCK TABLES `curriculum_outlines` WRITE;
/*!40000 ALTER TABLE `curriculum_outlines` DISABLE KEYS */;
/*!40000 ALTER TABLE `curriculum_outlines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discipline_actions`
--

DROP TABLE IF EXISTS `discipline_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `discipline_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `incident_id` int(10) unsigned DEFAULT NULL,
  `action_type` enum('detention','suspension','expulsion','community_service','warning') NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `issued_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_incident` (`incident_id`),
  KEY `idx_school_campus` (`school_id`,`campus_id`),
  KEY `fk_discipline_actions_issued_by` (`issued_by`),
  CONSTRAINT `fk_discipline_actions_incident` FOREIGN KEY (`incident_id`) REFERENCES `incidents` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_discipline_actions_issued_by` FOREIGN KEY (`issued_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_discipline_actions_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discipline_actions`
--

LOCK TABLES `discipline_actions` WRITE;
/*!40000 ALTER TABLE `discipline_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `discipline_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `template_key` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body_html` text NOT NULL,
  `body_text` text DEFAULT NULL,
  `variables` text DEFAULT NULL COMMENT 'JSON array of available variables',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_template` (`school_id`,`template_key`),
  KEY `idx_school` (`school_id`),
  KEY `idx_template_key` (`template_key`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_school_active` (`school_id`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('holiday','exam','meeting','celebration','sports','other') DEFAULT 'other',
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `venue` varchar(255) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT 1,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_school` (`school_id`),
  KEY `idx_dates` (`start_date`,`end_date`),
  KEY `idx_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES
(1,6,'pta meeting','a guadian to a student must be present','meeting','2026-03-12','2026-03-12','10:30:00','12:30:00','school hall',1,1,'2026-03-06 21:43:54'),
(3,6,'Inter-house sports','','sports','2026-03-27','2026-03-27','08:30:00','16:00:00','School Field',1,1,'2026-03-09 11:39:38');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_grades`
--

DROP TABLE IF EXISTS `exam_grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam_grades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `exam_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `subject_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `marks_obtained` decimal(5,2) DEFAULT NULL,
  `total_marks` decimal(5,2) NOT NULL,
  `grade` varchar(5) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `entered_by` int(10) unsigned DEFAULT NULL,
  `entered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_published` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_exam_grade` (`exam_id`,`student_id`,`subject_id`),
  KEY `class_id` (`class_id`),
  KEY `entered_by` (`entered_by`),
  KEY `idx_school` (`school_id`),
  KEY `idx_exam` (`exam_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_subject` (`subject_id`),
  KEY `idx_exam_grades_exam_student` (`exam_id`,`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_grades`
--

LOCK TABLES `exam_grades` WRITE;
/*!40000 ALTER TABLE `exam_grades` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_options`
--

DROP TABLE IF EXISTS `exam_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question_id` int(10) unsigned NOT NULL,
  `option_text` text NOT NULL,
  `is_correct` tinyint(1) DEFAULT 0,
  `order` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_question` (`question_id`),
  CONSTRAINT `fk_exam_options_question` FOREIGN KEY (`question_id`) REFERENCES `exam_questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_options`
--

LOCK TABLES `exam_options` WRITE;
/*!40000 ALTER TABLE `exam_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_papers`
--

DROP TABLE IF EXISTS `exam_papers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam_papers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `exam_id` int(10) unsigned NOT NULL,
  `subject_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `teacher_id` int(10) unsigned NOT NULL COMMENT 'Teacher who created the paper',
  `title` varchar(255) NOT NULL,
  `total_marks` decimal(5,2) NOT NULL,
  `duration_minutes` int(10) unsigned DEFAULT NULL,
  `paper_type` enum('cbt','printed') NOT NULL,
  `status` enum('draft','submitted','approved','rejected') DEFAULT 'draft',
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_exam` (`exam_id`),
  KEY `idx_subject` (`subject_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_teacher` (`teacher_id`),
  CONSTRAINT `fk_exam_papers_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_exam_papers_exam` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_exam_papers_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_exam_papers_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_papers`
--

LOCK TABLES `exam_papers` WRITE;
/*!40000 ALTER TABLE `exam_papers` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_papers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_questions`
--

DROP TABLE IF EXISTS `exam_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam_questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `paper_id` int(10) unsigned NOT NULL,
  `question_text` text NOT NULL,
  `question_type` enum('multiple_choice','true_false','essay') NOT NULL,
  `marks` decimal(5,2) NOT NULL,
  `attachment` varchar(500) DEFAULT NULL,
  `order` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_paper` (`paper_id`),
  CONSTRAINT `fk_exam_questions_paper` FOREIGN KEY (`paper_id`) REFERENCES `exam_papers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_questions`
--

LOCK TABLES `exam_questions` WRITE;
/*!40000 ALTER TABLE `exam_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `exams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `academic_year_id` int(10) unsigned NOT NULL,
  `academic_term_id` int(10) unsigned NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_published` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_exam_school` (`school_id`,`academic_year_id`,`academic_term_id`,`name`),
  KEY `academic_term_id` (`academic_term_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_year` (`academic_year_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams`
--

LOCK TABLES `exams` WRITE;
/*!40000 ALTER TABLE `exams` DISABLE KEYS */;
/*!40000 ALTER TABLE `exams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fee_categories`
--

DROP TABLE IF EXISTS `fee_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fee_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_category_school` (`school_id`,`name`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fee_categories`
--

LOCK TABLES `fee_categories` WRITE;
/*!40000 ALTER TABLE `fee_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `fee_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fee_structures`
--

DROP TABLE IF EXISTS `fee_structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fee_structures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `academic_year_id` int(10) unsigned NOT NULL,
  `academic_term_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `fee_category_id` int(10) unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `due_date` date DEFAULT NULL,
  `late_fee` decimal(10,2) DEFAULT 0.00,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_fee_structure` (`academic_year_id`,`academic_term_id`,`class_id`,`fee_category_id`),
  KEY `academic_term_id` (`academic_term_id`),
  KEY `class_id` (`class_id`),
  KEY `fee_category_id` (`fee_category_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_year` (`academic_year_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fee_structures`
--

LOCK TABLES `fee_structures` WRITE;
/*!40000 ALTER TABLE `fee_structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `fee_structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_storage`
--

DROP TABLE IF EXISTS `file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_storage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(100) NOT NULL,
  `file_size` bigint(20) NOT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `storage_type` enum('local','s3','cloudinary','wasabi') DEFAULT 'local',
  `bucket_name` varchar(255) DEFAULT NULL,
  `object_key` varchar(500) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT 0,
  `access_hash` varchar(100) DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `download_count` int(10) DEFAULT 0,
  `last_downloaded` timestamp NULL DEFAULT NULL,
  `metadata` text DEFAULT NULL COMMENT 'JSON encoded metadata',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_file_type` (`file_type`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_school_type` (`school_id`,`file_type`),
  KEY `idx_access_hash` (`access_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_storage`
--

LOCK TABLES `file_storage` WRITE;
/*!40000 ALTER TABLE `file_storage` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geofence_logs`
--

DROP TABLE IF EXISTS `geofence_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `geofence_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `action` enum('clock_in','clock_out') NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `is_within_allowed` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = outside, 1 = inside',
  `distance_meters` decimal(10,2) DEFAULT NULL COMMENT 'Distance from campus center if applicable',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_geofence_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geofence_logs`
--

LOCK TABLES `geofence_logs` WRITE;
/*!40000 ALTER TABLE `geofence_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `geofence_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guardians`
--

DROP TABLE IF EXISTS `guardians`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardians` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `relationship` enum('father','mother','brother','sister','uncle','aunt','grandfather','grandmother','guardian','other') NOT NULL,
  `is_primary` tinyint(1) DEFAULT 0,
  `can_pickup` tinyint(1) DEFAULT 1,
  `emergency_contact` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_guardian_student` (`student_id`,`user_id`),
  KEY `user_id` (`user_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_primary` (`is_primary`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guardians`
--

LOCK TABLES `guardians` WRITE;
/*!40000 ALTER TABLE `guardians` DISABLE KEYS */;
INSERT INTO `guardians` VALUES
(1,6,4,1,'father',1,1,1),
(2,6,6,2,'mother',1,1,1),
(3,6,11,3,'mother',1,1,1),
(4,6,12,2,'guardian',1,1,1),
(5,6,13,3,'guardian',1,1,1),
(6,6,15,4,'father',1,1,1),
(7,6,4,5,'guardian',1,1,1),
(8,6,38,14,'father',1,1,1),
(9,6,52,21,'guardian',1,1,1),
(10,6,53,22,'guardian',1,1,1),
(11,6,54,23,'guardian',1,1,1),
(12,6,55,24,'guardian',1,1,1),
(13,6,56,25,'guardian',1,1,1),
(14,6,57,26,'guardian',1,1,1),
(15,6,58,27,'guardian',1,1,1),
(16,6,59,28,'guardian',1,1,1),
(17,6,60,29,'guardian',1,1,1),
(18,6,61,30,'guardian',1,1,1),
(19,6,62,31,'guardian',1,1,1),
(20,6,63,32,'guardian',1,1,1),
(21,6,82,33,'guardian',1,1,1);
/*!40000 ALTER TABLE `guardians` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homework`
--

DROP TABLE IF EXISTS `homework`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `homework` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned NOT NULL,
  `teacher_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `attachment` varchar(500) DEFAULT NULL,
  `due_date` date NOT NULL,
  `submission_type` enum('online','offline') DEFAULT 'offline',
  `max_marks` decimal(5,2) DEFAULT NULL,
  `is_published` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `section_id` (`section_id`),
  KEY `subject_id` (`subject_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_due_date` (`due_date`),
  KEY `idx_teacher` (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homework`
--

LOCK TABLES `homework` WRITE;
/*!40000 ALTER TABLE `homework` DISABLE KEYS */;
/*!40000 ALTER TABLE `homework` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostel_assignments`
--

DROP TABLE IF EXISTS `hostel_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hostel_assignments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `hostel_id` int(10) unsigned NOT NULL,
  `bed_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL COMMENT 'Null means currently assigned',
  `status` enum('active','inactive','transferred') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_active_bed` (`bed_id`,`start_date`),
  UNIQUE KEY `unique_active_student` (`student_id`,`hostel_id`,`start_date`),
  KEY `idx_school` (`school_id`),
  KEY `idx_campus` (`campus_id`),
  KEY `idx_hostel` (`hostel_id`),
  KEY `idx_bed` (`bed_id`),
  KEY `idx_student` (`student_id`),
  CONSTRAINT `fk_hostel_assignments_bed` FOREIGN KEY (`bed_id`) REFERENCES `hostel_beds` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_hostel_assignments_campus` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_hostel_assignments_hostel` FOREIGN KEY (`hostel_id`) REFERENCES `hostels` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_hostel_assignments_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostel_assignments`
--

LOCK TABLES `hostel_assignments` WRITE;
/*!40000 ALTER TABLE `hostel_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `hostel_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostel_beds`
--

DROP TABLE IF EXISTS `hostel_beds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hostel_beds` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `hostel_id` int(10) unsigned NOT NULL,
  `room_id` int(10) unsigned NOT NULL,
  `bed_number` varchar(20) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_bed_in_room` (`room_id`,`bed_number`),
  KEY `idx_school` (`school_id`),
  KEY `idx_campus` (`campus_id`),
  KEY `idx_hostel` (`hostel_id`),
  KEY `idx_room` (`room_id`),
  CONSTRAINT `fk_hostel_beds_campus` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_hostel_beds_hostel` FOREIGN KEY (`hostel_id`) REFERENCES `hostels` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_hostel_beds_room` FOREIGN KEY (`room_id`) REFERENCES `hostel_rooms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostel_beds`
--

LOCK TABLES `hostel_beds` WRITE;
/*!40000 ALTER TABLE `hostel_beds` DISABLE KEYS */;
/*!40000 ALTER TABLE `hostel_beds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostel_rooms`
--

DROP TABLE IF EXISTS `hostel_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hostel_rooms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `hostel_id` int(10) unsigned NOT NULL,
  `room_number` varchar(20) NOT NULL,
  `floor` varchar(10) DEFAULT NULL,
  `capacity` int(10) unsigned NOT NULL COMMENT 'Number of beds in the room',
  `gender` enum('male','female','co-ed') DEFAULT 'co-ed',
  `class_id` int(10) unsigned DEFAULT NULL COMMENT 'If set, room is reserved for students of this class',
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_room` (`hostel_id`,`room_number`),
  KEY `idx_school` (`school_id`),
  KEY `idx_campus` (`campus_id`),
  KEY `idx_hostel` (`hostel_id`),
  KEY `idx_class` (`class_id`),
  CONSTRAINT `fk_hostel_rooms_campus` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_hostel_rooms_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_hostel_rooms_hostel` FOREIGN KEY (`hostel_id`) REFERENCES `hostels` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostel_rooms`
--

LOCK TABLES `hostel_rooms` WRITE;
/*!40000 ALTER TABLE `hostel_rooms` DISABLE KEYS */;
/*!40000 ALTER TABLE `hostel_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostels`
--

DROP TABLE IF EXISTS `hostels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hostels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `capacity` int(10) unsigned DEFAULT NULL COMMENT 'Total number of beds',
  `gender` enum('male','female','co-ed') DEFAULT 'co-ed',
  `address` text DEFAULT NULL COMMENT 'Optional, if different from campus address',
  `facilities` text DEFAULT NULL COMMENT 'JSON array or comma separated list',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_hostel_code` (`school_id`,`campus_id`,`code`),
  KEY `idx_school` (`school_id`),
  KEY `idx_campus` (`campus_id`),
  CONSTRAINT `fk_hostels_campus` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostels`
--

LOCK TABLES `hostels` WRITE;
/*!40000 ALTER TABLE `hostels` DISABLE KEYS */;
/*!40000 ALTER TABLE `hostels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incident_students`
--

DROP TABLE IF EXISTS `incident_students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `incident_students` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `incident_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `role` enum('perpetrator','victim','witness') DEFAULT 'perpetrator',
  `statement` text DEFAULT NULL,
  `action_taken` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_incident_student` (`incident_id`,`student_id`),
  KEY `idx_student` (`student_id`),
  CONSTRAINT `fk_incident_students_incident` FOREIGN KEY (`incident_id`) REFERENCES `incidents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_incident_students_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incident_students`
--

LOCK TABLES `incident_students` WRITE;
/*!40000 ALTER TABLE `incident_students` DISABLE KEYS */;
/*!40000 ALTER TABLE `incident_students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidents`
--

DROP TABLE IF EXISTS `incidents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `incidents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `incident_date` date NOT NULL,
  `incident_time` time DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `reported_by` int(10) unsigned NOT NULL,
  `status` enum('open','investigating','resolved','closed') DEFAULT 'open',
  `action_taken` text DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolved_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_reported_by` (`reported_by`),
  KEY `idx_status` (`status`),
  KEY `idx_school_campus` (`school_id`,`campus_id`),
  KEY `fk_incidents_resolved_by` (`resolved_by`),
  CONSTRAINT `fk_incidents_reported_by` FOREIGN KEY (`reported_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_incidents_resolved_by` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidents`
--

LOCK TABLES `incidents` WRITE;
/*!40000 ALTER TABLE `incidents` DISABLE KEYS */;
/*!40000 ALTER TABLE `incidents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_categories`
--

DROP TABLE IF EXISTS `inventory_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_category` (`school_id`,`campus_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_categories`
--

LOCK TABLES `inventory_categories` WRITE;
/*!40000 ALTER TABLE `inventory_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_items`
--

DROP TABLE IF EXISTS `inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `item_code` varchar(50) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL COMMENT 'e.g., piece, kg, box',
  `unit_price` decimal(10,2) DEFAULT NULL,
  `quantity_in_stock` decimal(10,2) DEFAULT 0.00,
  `minimum_quantity` decimal(10,2) DEFAULT 0.00,
  `maximum_quantity` decimal(10,2) DEFAULT NULL,
  `reorder_level` decimal(10,2) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL COMMENT 'Shelf/rack location',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_item` (`school_id`,`campus_id`,`item_code`),
  KEY `idx_category` (`category_id`),
  KEY `idx_school_campus` (`school_id`,`campus_id`),
  CONSTRAINT `fk_inventory_items_category` FOREIGN KEY (`category_id`) REFERENCES `inventory_categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_items`
--

LOCK TABLES `inventory_items` WRITE;
/*!40000 ALTER TABLE `inventory_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_movements`
--

DROP TABLE IF EXISTS `inventory_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_movements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `movement_type` enum('receipt','issue','adjustment','return') NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL COMMENT 'e.g., invoice number, issue slip',
  `description` text DEFAULT NULL,
  `issued_to` varchar(255) DEFAULT NULL COMMENT 'Person/department who received',
  `issued_to_user_id` int(10) unsigned DEFAULT NULL,
  `movement_date` date NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_item` (`item_id`),
  KEY `idx_movement_type` (`movement_type`),
  KEY `idx_school_campus` (`school_id`,`campus_id`),
  KEY `fk_inventory_movements_created_by` (`created_by`),
  KEY `fk_inventory_movements_issued_to` (`issued_to_user_id`),
  CONSTRAINT `fk_inventory_movements_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_inventory_movements_issued_to` FOREIGN KEY (`issued_to_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_inventory_movements_item` FOREIGN KEY (`item_id`) REFERENCES `inventory_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_movements`
--

LOCK TABLES `inventory_movements` WRITE;
/*!40000 ALTER TABLE `inventory_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_items`
--

DROP TABLE IF EXISTS `invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(10) unsigned NOT NULL,
  `fee_category_id` int(10) unsigned NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fee_category_id` (`fee_category_id`),
  KEY `idx_invoice` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_items`
--

LOCK TABLES `invoice_items` WRITE;
/*!40000 ALTER TABLE `invoice_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `invoice_number` varchar(100) NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `academic_year_id` int(10) unsigned NOT NULL,
  `academic_term_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `issue_date` date NOT NULL,
  `due_date` date NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) DEFAULT 0.00,
  `late_fee` decimal(10,2) DEFAULT 0.00,
  `paid_amount` decimal(10,2) DEFAULT 0.00,
  `balance_amount` decimal(10,2) NOT NULL,
  `status` enum('draft','pending','partial','paid','overdue','cancelled') DEFAULT 'pending',
  `payment_method` varchar(50) DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `academic_year_id` (`academic_year_id`),
  KEY `academic_term_id` (`academic_term_id`),
  KEY `class_id` (`class_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_status` (`status`),
  KEY `idx_due_date` (`due_date`),
  KEY `idx_invoices_student_status` (`student_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices_v2`
--

DROP TABLE IF EXISTS `invoices_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices_v2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `invoice_number` varchar(100) NOT NULL,
  `billing_history_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `tax` decimal(10,2) DEFAULT 0.00,
  `discount` decimal(10,2) DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'NGN',
  `status` enum('draft','sent','viewed','paid','overdue','cancelled') DEFAULT 'draft',
  `due_date` date NOT NULL,
  `paid_date` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `pdf_path` varchar(500) DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `viewed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `billing_history_id` (`billing_history_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_status` (`status`),
  KEY `idx_due_date` (`due_date`),
  KEY `idx_school_status` (`school_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices_v2`
--

LOCK TABLES `invoices_v2` WRITE;
/*!40000 ALTER TABLE `invoices_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_requests`
--

DROP TABLE IF EXISTS `leave_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_type` enum('teacher','staff','student') NOT NULL COMMENT 'Mirrors users.user_type for clarity',
  `leave_type_id` int(10) unsigned NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` text NOT NULL,
  `status` enum('pending','approved','rejected','cancelled') DEFAULT 'pending',
  `approved_by` int(10) unsigned DEFAULT NULL COMMENT 'User ID of approver',
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `applied_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_leave_type` (`leave_type_id`),
  KEY `idx_status` (`status`),
  KEY `idx_dates` (`start_date`,`end_date`),
  KEY `idx_approved_by` (`approved_by`),
  CONSTRAINT `fk_leave_requests_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_leave_requests_leave_type` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_leave_requests_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_requests`
--

LOCK TABLES `leave_requests` WRITE;
/*!40000 ALTER TABLE `leave_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `leave_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_types`
--

DROP TABLE IF EXISTS `leave_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `max_days_per_year` int(10) unsigned DEFAULT NULL COMMENT 'Maximum allowed days per year (optional)',
  `applicable_to` enum('teacher','staff','student','all') DEFAULT 'all',
  `is_paid` tinyint(1) DEFAULT 1,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_leave_type` (`school_id`,`name`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_types`
--

LOCK TABLES `leave_types` WRITE;
/*!40000 ALTER TABLE `leave_types` DISABLE KEYS */;
INSERT INTO `leave_types` VALUES
(1,6,'spa leave','enjoyment',1,'teacher',0,1,'2026-03-09 21:24:17'),
(2,6,'Maternity leave','Just gave birth',90,'teacher',0,1,'2026-03-10 07:33:39');
/*!40000 ALTER TABLE `leave_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lesson_plans`
--

DROP TABLE IF EXISTS `lesson_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lesson_plans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned NOT NULL,
  `teacher_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `week` int(10) unsigned DEFAULT NULL,
  `topic` varchar(255) NOT NULL,
  `objectives` text DEFAULT NULL,
  `materials` text DEFAULT NULL,
  `procedure` text DEFAULT NULL,
  `assessment` text DEFAULT NULL,
  `homework` text DEFAULT NULL,
  `attachment` varchar(500) DEFAULT NULL,
  `is_approved` tinyint(1) DEFAULT 0,
  `approved_by` int(10) unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_class_subject` (`class_id`,`subject_id`),
  KEY `idx_teacher` (`teacher_id`),
  KEY `idx_term` (`term_id`),
  KEY `idx_school` (`school_id`),
  KEY `fk_lesson_plans_section` (`section_id`),
  KEY `fk_lesson_plans_subject` (`subject_id`),
  KEY `fk_lesson_plans_approved_by` (`approved_by`),
  CONSTRAINT `fk_lesson_plans_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_lesson_plans_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_lesson_plans_section` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_lesson_plans_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_lesson_plans_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_lesson_plans_term` FOREIGN KEY (`term_id`) REFERENCES `academic_terms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lesson_plans`
--

LOCK TABLES `lesson_plans` WRITE;
/*!40000 ALTER TABLE `lesson_plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `lesson_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_books`
--

DROP TABLE IF EXISTS `library_books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_books` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `isbn` varchar(20) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `publisher` varchar(255) DEFAULT NULL,
  `edition` varchar(50) DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `shelf_location` varchar(100) DEFAULT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `available_quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `price` decimal(10,2) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `cover_image` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_category` (`category_id`),
  KEY `idx_isbn` (`isbn`),
  KEY `idx_title` (`title`),
  CONSTRAINT `fk_library_books_category` FOREIGN KEY (`category_id`) REFERENCES `library_categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_books`
--

LOCK TABLES `library_books` WRITE;
/*!40000 ALTER TABLE `library_books` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_categories`
--

DROP TABLE IF EXISTS `library_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_category_school` (`school_id`,`name`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_categories`
--

LOCK TABLES `library_categories` WRITE;
/*!40000 ALTER TABLE `library_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_fine_settings`
--

DROP TABLE IF EXISTS `library_fine_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_fine_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `fine_per_day` decimal(10,2) NOT NULL DEFAULT 0.00,
  `max_fine` decimal(10,2) DEFAULT NULL,
  `grace_days` int(10) unsigned DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `school_id` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_fine_settings`
--

LOCK TABLES `library_fine_settings` WRITE;
/*!40000 ALTER TABLE `library_fine_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_fine_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_issues`
--

DROP TABLE IF EXISTS `library_issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_issues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `book_id` int(10) unsigned NOT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `issue_date` date NOT NULL,
  `due_date` date NOT NULL,
  `return_date` date DEFAULT NULL,
  `status` enum('issued','returned','overdue','lost') DEFAULT 'issued',
  `fine_amount` decimal(10,2) DEFAULT 0.00,
  `fine_paid` tinyint(1) DEFAULT 0,
  `issued_by` int(10) unsigned NOT NULL COMMENT 'Librarian user ID',
  `returned_by` int(10) unsigned DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_book` (`book_id`),
  KEY `idx_member` (`member_id`),
  KEY `idx_issued_by` (`issued_by`),
  KEY `idx_returned_by` (`returned_by`),
  KEY `idx_status` (`status`),
  KEY `idx_due_date` (`due_date`),
  CONSTRAINT `fk_library_issues_book` FOREIGN KEY (`book_id`) REFERENCES `library_books` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_library_issues_issued_by` FOREIGN KEY (`issued_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_library_issues_member` FOREIGN KEY (`member_id`) REFERENCES `library_members` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_library_issues_returned_by` FOREIGN KEY (`returned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_issues`
--

LOCK TABLES `library_issues` WRITE;
/*!40000 ALTER TABLE `library_issues` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_members`
--

DROP TABLE IF EXISTS `library_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `membership_number` varchar(50) NOT NULL,
  `membership_type` enum('student','teacher','staff') NOT NULL,
  `issued_date` date NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `membership_number` (`membership_number`),
  KEY `idx_school` (`school_id`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `fk_library_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_members`
--

LOCK TABLES `library_members` WRITE;
/*!40000 ALTER TABLE `library_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_reservations`
--

DROP TABLE IF EXISTS `library_reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_reservations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `book_id` int(10) unsigned NOT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `reservation_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `status` enum('pending','fulfilled','cancelled','expired') DEFAULT 'pending',
  `notified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_book` (`book_id`),
  KEY `idx_member` (`member_id`),
  CONSTRAINT `fk_library_reservations_book` FOREIGN KEY (`book_id`) REFERENCES `library_books` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_library_reservations_member` FOREIGN KEY (`member_id`) REFERENCES `library_members` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_reservations`
--

LOCK TABLES `library_reservations` WRITE;
/*!40000 ALTER TABLE `library_reservations` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `success` tinyint(1) DEFAULT 0,
  `failed_reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_username` (`username`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_success` (`success`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_school_ip` (`school_id`,`ip_address`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenance_logs`
--

DROP TABLE IF EXISTS `maintenance_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `maintenance_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `maintenance_type` enum('database_optimization','cache_clear','backup_cleanup','storage_cleanup','system_update') NOT NULL,
  `description` text NOT NULL,
  `status` enum('pending','running','completed','failed','cancelled') DEFAULT 'pending',
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `duration_seconds` int(10) DEFAULT NULL,
  `affected_records` int(10) DEFAULT NULL,
  `freed_space` bigint(20) DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `performed_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `performed_by` (`performed_by`),
  KEY `idx_school` (`school_id`),
  KEY `idx_maintenance_type` (`maintenance_type`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_school_type` (`school_id`,`maintenance_type`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenance_logs`
--

LOCK TABLES `maintenance_logs` WRITE;
/*!40000 ALTER TABLE `maintenance_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `maintenance_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting_bookings`
--

DROP TABLE IF EXISTS `meeting_bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting_bookings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `slot_id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `purpose` text DEFAULT NULL,
  `status` enum('booked','attended','cancelled','no_show') DEFAULT 'booked',
  `booked_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `attended_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_booking` (`slot_id`,`parent_id`,`student_id`),
  KEY `idx_parent` (`parent_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_school_campus` (`school_id`,`campus_id`),
  CONSTRAINT `fk_meeting_bookings_parent` FOREIGN KEY (`parent_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_meeting_bookings_slot` FOREIGN KEY (`slot_id`) REFERENCES `meeting_slots` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_meeting_bookings_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_bookings`
--

LOCK TABLES `meeting_bookings` WRITE;
/*!40000 ALTER TABLE `meeting_bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `meeting_bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting_slots`
--

DROP TABLE IF EXISTS `meeting_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting_slots` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `teacher_id` int(10) unsigned NOT NULL,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `max_bookings` int(10) unsigned DEFAULT 1 COMMENT 'Number of simultaneous bookings (e.g., group meeting)',
  `current_bookings` int(10) unsigned DEFAULT 0,
  `status` enum('available','full','cancelled') DEFAULT 'available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_slot` (`teacher_id`,`date`,`start_time`),
  KEY `idx_teacher` (`teacher_id`),
  KEY `idx_date` (`date`),
  KEY `idx_school_campus` (`school_id`,`campus_id`),
  CONSTRAINT `fk_meeting_slots_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_slots`
--

LOCK TABLES `meeting_slots` WRITE;
/*!40000 ALTER TABLE `meeting_slots` DISABLE KEYS */;
/*!40000 ALTER TABLE `meeting_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_attachments`
--

DROP TABLE IF EXISTS `message_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_attachments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` int(10) unsigned NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` bigint(20) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_extension` varchar(20) DEFAULT NULL,
  `thumbnail_path` varchar(500) DEFAULT NULL,
  `duration` int(10) DEFAULT NULL COMMENT 'For audio/video in seconds',
  `dimensions` varchar(50) DEFAULT NULL COMMENT 'For images (widthxheight)',
  `is_downloaded` tinyint(1) DEFAULT 0,
  `download_count` int(10) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_message` (`message_id`),
  KEY `idx_file_type` (`mime_type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_attachments`
--

LOCK TABLES `message_attachments` WRITE;
/*!40000 ALTER TABLE `message_attachments` DISABLE KEYS */;
INSERT INTO `message_attachments` VALUES
(1,8,'contact-info-img.png','uploads/messages/6/69ad7deeec815_1772977646.png',226213,'image/png','png','uploads/messages/6/thumbnails/thumb_69ad7deeec815_1772977646.png',NULL,'443x564',0,0,'2026-03-08 13:47:26'),
(2,20,'academix  456.jpg','uploads/messages/6/69aeb61986292_1773057561.jpg',606831,'image/jpeg','jpg','uploads/messages/6/thumbnails/thumb_69aeb61986292_1773057561.jpg',NULL,'3242x3194',0,0,'2026-03-09 11:59:21');
/*!40000 ALTER TABLE `message_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_blocks`
--

DROP TABLE IF EXISTS `message_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_blocks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `blocked_user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_block` (`user_id`,`blocked_user_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_blocked` (`blocked_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_blocks`
--

LOCK TABLES `message_blocks` WRITE;
/*!40000 ALTER TABLE `message_blocks` DISABLE KEYS */;
INSERT INTO `message_blocks` VALUES
(1,6,1,4,'2026-03-08 14:39:17');
/*!40000 ALTER TABLE `message_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_drafts`
--

DROP TABLE IF EXISTS `message_drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_drafts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `conversation_id` int(10) unsigned DEFAULT NULL,
  `recipient_id` int(10) unsigned DEFAULT NULL,
  `recipient_type` enum('teacher','parent','student') DEFAULT NULL,
  `message` text NOT NULL,
  `attachments` text DEFAULT NULL COMMENT 'JSON array of temporary file paths',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_conversation` (`conversation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_drafts`
--

LOCK TABLES `message_drafts` WRITE;
/*!40000 ALTER TABLE `message_drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_reactions`
--

DROP TABLE IF EXISTS `message_reactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_reactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `reaction` varchar(50) NOT NULL COMMENT 'Emoji or reaction type',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_reaction` (`message_id`,`user_id`,`reaction`),
  KEY `idx_message` (`message_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_reactions`
--

LOCK TABLES `message_reactions` WRITE;
/*!40000 ALTER TABLE `message_reactions` DISABLE KEYS */;
INSERT INTO `message_reactions` VALUES
(3,7,1,'👍','2026-03-08 14:20:22'),
(5,20,1,'👍','2026-03-09 12:00:12');
/*!40000 ALTER TABLE `message_reactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_status`
--

DROP TABLE IF EXISTS `message_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `status` enum('sent','delivered','read') DEFAULT 'sent',
  `status_changed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_message_user` (`message_id`,`user_id`),
  KEY `idx_message` (`message_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_status`
--

LOCK TABLES `message_status` WRITE;
/*!40000 ALTER TABLE `message_status` DISABLE KEYS */;
INSERT INTO `message_status` VALUES
(1,3,9,'sent','2026-03-08 11:49:47','2026-03-08 11:49:47'),
(2,4,9,'sent','2026-03-08 11:51:53','2026-03-08 11:51:53'),
(3,5,11,'sent','2026-03-08 11:58:39','2026-03-08 11:58:39'),
(4,6,13,'sent','2026-03-08 12:19:47','2026-03-08 12:19:47'),
(5,7,9,'sent','2026-03-08 13:47:13','2026-03-08 13:47:13'),
(6,8,9,'sent','2026-03-08 13:47:26','2026-03-08 13:47:26'),
(7,10,9,'sent','2026-03-08 13:56:50','2026-03-08 13:56:50'),
(8,10,11,'sent','2026-03-08 13:56:50','2026-03-08 13:56:50'),
(9,10,13,'sent','2026-03-08 13:56:50','2026-03-08 13:56:50'),
(10,11,6,'sent','2026-03-08 14:01:38','2026-03-08 14:01:38'),
(11,12,9,'sent','2026-03-08 14:14:24','2026-03-08 14:14:24'),
(12,13,9,'sent','2026-03-08 14:14:34','2026-03-08 14:14:34'),
(13,14,9,'sent','2026-03-08 14:20:45','2026-03-08 14:20:45'),
(14,15,4,'sent','2026-03-08 14:38:30','2026-03-08 14:38:30'),
(15,16,11,'sent','2026-03-08 14:49:25','2026-03-08 14:49:25'),
(16,17,9,'sent','2026-03-08 15:04:11','2026-03-08 15:04:11'),
(17,18,9,'sent','2026-03-08 16:40:26','2026-03-08 16:40:26'),
(18,19,11,'sent','2026-03-08 16:41:53','2026-03-08 16:41:53'),
(19,20,11,'sent','2026-03-09 11:59:21','2026-03-09 11:59:21'),
(20,22,11,'sent','2026-03-09 12:02:12','2026-03-09 12:02:12'),
(21,22,13,'sent','2026-03-09 12:02:12','2026-03-09 12:02:12'),
(23,23,11,'sent','2026-03-09 12:02:44','2026-03-09 12:02:44'),
(24,23,13,'sent','2026-03-09 12:02:44','2026-03-09 12:02:44');
/*!40000 ALTER TABLE `message_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `conversation_id` int(10) unsigned NOT NULL,
  `sender_id` int(10) unsigned NOT NULL,
  `sender_type` enum('admin','teacher','student','parent','accountant','librarian','receptionist') NOT NULL,
  `message_type` enum('text','image','file','audio','video','system') DEFAULT 'text',
  `message` text NOT NULL,
  `metadata` text DEFAULT NULL COMMENT 'JSON encoded metadata (file info, dimensions, etc)',
  `is_delivered` tinyint(1) DEFAULT 0,
  `delivered_at` timestamp NULL DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` timestamp NULL DEFAULT NULL,
  `is_starred` tinyint(1) DEFAULT 0,
  `is_pinned` tinyint(1) DEFAULT 0,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `reply_to_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_conversation` (`conversation_id`),
  KEY `idx_sender` (`sender_id`),
  KEY `idx_reply_to` (`reply_to_id`),
  KEY `idx_conversation_created` (`conversation_id`,`created_at`),
  KEY `idx_conversation_read` (`conversation_id`,`is_read`),
  KEY `idx_sender_conversation` (`sender_id`,`conversation_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES
(1,1,1,'admin','text','hello',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-08 11:47:09'),
(2,2,1,'admin','text','hello',NULL,0,NULL,0,NULL,0,0,1,'2026-03-08 14:40:44',NULL,'2026-03-08 11:47:42'),
(3,1,1,'admin','text','see the receipt',NULL,0,NULL,0,NULL,0,0,1,'2026-03-08 13:47:00',NULL,'2026-03-08 11:49:47'),
(4,1,1,'admin','text','hehe',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-08 11:51:53'),
(5,2,1,'admin','text','helllo oo',NULL,0,NULL,0,NULL,0,0,1,'2026-03-08 14:40:41',NULL,'2026-03-08 11:58:39'),
(6,3,1,'admin','text','🥹🥹🥹🥹',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-08 12:19:47'),
(7,1,1,'admin','text','answer me nah',NULL,0,NULL,0,NULL,0,0,0,NULL,1,'2026-03-08 13:47:13'),
(8,1,1,'admin','text','send',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-08 13:47:26'),
(9,5,0,'','system','Group created by bitflux wallet',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-08 13:56:27'),
(10,5,1,'admin','text','hello every one',NULL,0,NULL,0,NULL,0,0,0,NULL,9,'2026-03-08 13:56:50'),
(11,4,1,'admin','text','yes',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-08 14:01:38'),
(12,1,1,'admin','text','hello',NULL,0,NULL,0,NULL,0,0,0,NULL,8,'2026-03-08 14:14:24'),
(13,1,1,'admin','text','send me my money nah',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-08 14:14:34'),
(14,1,1,'admin','text','When are u coming home ?',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-08 14:20:45'),
(15,6,1,'admin','text','Bbhhhh',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-08 14:38:30'),
(16,2,1,'admin','text','Hello',NULL,0,NULL,0,NULL,0,0,1,'2026-03-09 12:00:42',NULL,'2026-03-08 14:49:25'),
(17,1,1,'admin','text','Hereby if. Fun ey c',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-08 15:04:11'),
(18,1,1,'admin','text','Hey daddy',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-08 16:40:26'),
(19,2,1,'admin','text','Hiii daddy',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-08 16:41:53'),
(20,2,1,'admin','text','Hello',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-09 11:59:21'),
(21,7,0,'','system','Group created by bitflux wallet',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-09 12:02:00'),
(22,7,1,'admin','text','hello',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-09 12:02:12'),
(23,7,1,'admin','text','❤️😂',NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,'2026-03-09 12:02:44');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `type` enum('email','sms','push','in_app','system') DEFAULT 'in_app',
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `data` text DEFAULT NULL COMMENT 'JSON encoded data',
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` timestamp NULL DEFAULT NULL,
  `is_sent` tinyint(1) DEFAULT 0,
  `sent_at` timestamp NULL DEFAULT NULL,
  `delivery_status` enum('pending','sent','delivered','failed','bounced') DEFAULT 'pending',
  `failure_reason` text DEFAULT NULL,
  `scheduled_for` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_type` (`type`),
  KEY `idx_is_read` (`is_read`),
  KEY `idx_priority` (`priority`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_school_user` (`school_id`,`user_id`,`is_read`,`created_at`),
  KEY `idx_notifications_school_user_read` (`school_id`,`user_id`,`is_read`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(1,6,12,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":1,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:43:55'),
(2,6,9,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":1,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:43:55'),
(3,6,6,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":1,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:43:55'),
(4,6,5,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":1,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:43:55'),
(5,6,13,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":1,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:43:55'),
(6,6,11,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":1,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:43:55'),
(7,6,10,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":1,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:43:55'),
(8,6,3,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":1,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:43:55'),
(9,6,4,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":1,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:43:55'),
(10,6,12,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:44:03'),
(11,6,9,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:44:03'),
(12,6,6,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:44:03'),
(13,6,5,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:44:03'),
(14,6,13,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:44:03'),
(15,6,11,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:44:03'),
(16,6,10,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:44:03'),
(17,6,3,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:44:03'),
(18,6,4,'in_app','New event scheduled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:44:03'),
(19,6,12,'in_app','Event cancelled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:51:02'),
(20,6,9,'in_app','Event cancelled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:51:02'),
(21,6,6,'in_app','Event cancelled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:51:02'),
(22,6,5,'in_app','Event cancelled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:51:02'),
(23,6,13,'in_app','Event cancelled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:51:02'),
(24,6,11,'in_app','Event cancelled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:51:02'),
(25,6,10,'in_app','Event cancelled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:51:02'),
(26,6,3,'in_app','Event cancelled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:51:02'),
(27,6,4,'in_app','Event cancelled','pta meeting - Mar 12, 2026','{\"event_id\":2,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-06 21:51:02'),
(28,6,3,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":3,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:39'),
(29,6,4,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":3,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:39'),
(30,6,5,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":3,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:39'),
(31,6,6,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":3,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:39'),
(32,6,9,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":3,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:39'),
(33,6,10,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":3,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:39'),
(34,6,11,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":3,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:39'),
(35,6,12,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":3,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:39'),
(36,6,13,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":3,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:39'),
(37,6,14,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":3,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:39'),
(38,6,15,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":3,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:39'),
(39,6,16,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":3,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:39'),
(40,6,3,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:48'),
(41,6,4,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:48'),
(42,6,5,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:48'),
(43,6,6,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:48'),
(44,6,9,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:48'),
(45,6,10,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:48'),
(46,6,11,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:48'),
(47,6,12,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:48'),
(48,6,13,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:48'),
(49,6,14,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:48'),
(50,6,15,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:48'),
(51,6,16,'in_app','New event scheduled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"created\",\"icon\":\"ri-calendar-check-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:39:48'),
(52,6,3,'in_app','Event cancelled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:40:18'),
(53,6,4,'in_app','Event cancelled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:40:18'),
(54,6,5,'in_app','Event cancelled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:40:18'),
(55,6,6,'in_app','Event cancelled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:40:18'),
(56,6,9,'in_app','Event cancelled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:40:18'),
(57,6,10,'in_app','Event cancelled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:40:18'),
(58,6,11,'in_app','Event cancelled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:40:18'),
(59,6,12,'in_app','Event cancelled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:40:18'),
(60,6,13,'in_app','Event cancelled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:40:18'),
(61,6,14,'in_app','Event cancelled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:40:18'),
(62,6,15,'in_app','Event cancelled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:40:18'),
(63,6,16,'in_app','Event cancelled','Inter-house sports - Mar 27, 2026','{\"event_id\":4,\"action\":\"deleted\",\"icon\":\"ri-calendar-close-line\"}','normal',0,NULL,0,NULL,'pending',NULL,NULL,NULL,'2026-03-09 11:40:18');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_methods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `type` enum('card','bank_transfer','mobile_money','wallet') NOT NULL,
  `provider` varchar(50) DEFAULT NULL,
  `last_four` varchar(4) DEFAULT NULL,
  `exp_month` int(2) DEFAULT NULL,
  `exp_year` int(4) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `is_verified` tinyint(1) DEFAULT 0,
  `metadata` text DEFAULT NULL COMMENT 'JSON encoded metadata',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_type` (`type`),
  KEY `idx_default` (`is_default`),
  KEY `idx_school_default` (`school_id`,`is_default`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `invoice_id` int(10) unsigned NOT NULL,
  `payment_number` varchar(100) NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('cash','cheque','bank_transfer','card','mobile_money','online') NOT NULL,
  `payment_date` date NOT NULL,
  `collected_by` int(10) unsigned DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `cheque_number` varchar(100) DEFAULT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_number` (`payment_number`),
  KEY `collected_by` (`collected_by`),
  KEY `idx_school` (`school_id`),
  KEY `idx_invoice` (`invoice_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_payment_date` (`payment_date`),
  KEY `idx_payments_invoice_date` (`invoice_id`,`payment_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_allowances`
--

DROP TABLE IF EXISTS `payroll_allowances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_allowances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) unsigned NOT NULL,
  `allowance_type` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `is_recurring` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_employee` (`employee_id`),
  CONSTRAINT `fk_payroll_allowances_employee` FOREIGN KEY (`employee_id`) REFERENCES `payroll_employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_allowances`
--

LOCK TABLES `payroll_allowances` WRITE;
/*!40000 ALTER TABLE `payroll_allowances` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_allowances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_deductions`
--

DROP TABLE IF EXISTS `payroll_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_deductions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) unsigned NOT NULL,
  `deduction_type` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `is_recurring` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_employee` (`employee_id`),
  CONSTRAINT `fk_payroll_deductions_employee` FOREIGN KEY (`employee_id`) REFERENCES `payroll_employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_deductions`
--

LOCK TABLES `payroll_deductions` WRITE;
/*!40000 ALTER TABLE `payroll_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_deductions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_employees`
--

DROP TABLE IF EXISTS `payroll_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_employees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `employee_number` varchar(50) NOT NULL,
  `department` varchar(100) DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `joining_date` date DEFAULT NULL,
  `salary_grade_id` int(10) unsigned DEFAULT NULL,
  `basic_salary` decimal(10,2) DEFAULT NULL COMMENT 'If not using grade',
  `bank_name` varchar(255) DEFAULT NULL,
  `bank_account` varchar(50) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL,
  `tax_id` varchar(50) DEFAULT NULL,
  `pan_number` varchar(20) DEFAULT NULL,
  `pf_number` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_number` (`employee_number`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_salary_grade` (`salary_grade_id`),
  CONSTRAINT `fk_payroll_employees_salary_grade` FOREIGN KEY (`salary_grade_id`) REFERENCES `payroll_salary_grades` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_payroll_employees_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_employees`
--

LOCK TABLES `payroll_employees` WRITE;
/*!40000 ALTER TABLE `payroll_employees` DISABLE KEYS */;
INSERT INTO `payroll_employees` VALUES
(1,6,9,'EMP-2026-7711','','','2026-03-10',1,NULL,'kuda','2032909568','23423',NULL,NULL,NULL,0,'2026-03-10 16:53:11','2026-03-11 05:14:09'),
(2,6,18,'EMP-2026-5748',NULL,NULL,'2026-03-10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-03-10 16:53:11','2026-03-10 16:53:11'),
(3,6,12,'EMP-2026-8680',NULL,NULL,'2026-03-10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-03-10 16:53:11','2026-03-10 17:05:21'),
(4,6,20,'EMP-2026-7669',NULL,NULL,'2026-03-10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-03-10 16:53:11','2026-03-10 16:53:11'),
(5,6,19,'EMP-2026-6483',NULL,NULL,'2026-03-10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-03-10 16:53:11','2026-03-10 16:53:11'),
(6,6,17,'EMP-2026-4480','','','2026-03-10',2,NULL,'','','',NULL,NULL,NULL,0,'2026-03-10 16:53:11','2026-03-11 05:00:03'),
(7,6,39,'TCH-2026-8372',NULL,'Teacher','2026-03-12',NULL,NULL,'','','',NULL,NULL,NULL,1,'2026-03-11 18:09:55','2026-03-11 18:09:55'),
(8,6,78,'TCH-2026-8373',NULL,'Teacher','2019-04-12',NULL,NULL,'','','',NULL,NULL,NULL,1,'2026-03-12 12:45:51','2026-03-12 12:45:51'),
(9,6,79,'TCH-2026-8374',NULL,'Teacher','2020-08-19',NULL,NULL,'','','',NULL,NULL,NULL,1,'2026-03-12 12:55:41','2026-03-12 12:55:41'),
(10,6,80,'TCH-2026-8375',NULL,'Teacher','2020-07-10',NULL,NULL,'','','',NULL,NULL,NULL,1,'2026-03-12 13:11:43','2026-03-12 13:11:43');
/*!40000 ALTER TABLE `payroll_employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_periods`
--

DROP TABLE IF EXISTS `payroll_periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_periods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('open','processing','closed','archived') DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_periods`
--

LOCK TABLES `payroll_periods` WRITE;
/*!40000 ALTER TABLE `payroll_periods` DISABLE KEYS */;
INSERT INTO `payroll_periods` VALUES
(1,6,'Cosmos','2026-03-18','2026-03-23','processing','2026-03-11 08:17:09','2026-03-11 13:54:05'),
(2,6,'Cosmos','2026-03-18','2026-03-23','processing','2026-03-11 08:17:11','2026-03-11 18:32:48'),
(3,6,'Cosmos','2026-03-18','2026-03-23','closed','2026-03-11 08:17:12','2026-03-12 04:59:19'),
(4,6,'Cosmos','2026-03-18','2026-03-23','open','2026-03-11 08:17:19','2026-03-11 08:17:19'),
(5,6,'Cosmos','2026-03-18','2026-03-23','open','2026-03-11 08:17:19','2026-03-11 08:17:19'),
(6,6,'Cosmos','2026-03-18','2026-03-23','open','2026-03-11 08:17:20','2026-03-11 08:17:20'),
(7,6,'Cosmos','2026-03-18','2026-03-23','open','2026-03-11 08:17:20','2026-03-11 08:17:20'),
(9,6,'Cosmos','2026-03-11','2026-03-13','open','2026-03-11 08:17:31','2026-03-11 08:17:31'),
(10,6,'Cosmos','2026-03-11','2026-03-13','open','2026-03-11 08:17:32','2026-03-11 08:17:32'),
(11,6,'Cosmos','2026-03-11','2026-03-13','processing','2026-03-11 08:17:32','2026-03-14 16:42:20'),
(12,6,'Cosmos','2026-03-11','2026-03-13','open','2026-03-11 08:17:32','2026-03-11 08:17:32'),
(13,6,'Cosmos','2026-03-11','2026-03-13','open','2026-03-11 08:17:33','2026-03-11 08:17:33'),
(14,6,'Cosmos','2026-03-11','2026-03-13','open','2026-03-11 08:17:33','2026-03-11 08:17:33');
/*!40000 ALTER TABLE `payroll_periods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_runs`
--

DROP TABLE IF EXISTS `payroll_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_runs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `period_id` int(10) unsigned NOT NULL,
  `processed_by` int(10) unsigned NOT NULL,
  `processed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `total_gross` decimal(12,2) DEFAULT 0.00,
  `total_deductions` decimal(12,2) DEFAULT 0.00,
  `total_net` decimal(12,2) DEFAULT 0.00,
  `status` enum('draft','approved','paid','cancelled') DEFAULT 'draft',
  `payment_date` date DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_period` (`period_id`),
  KEY `idx_processed_by` (`processed_by`),
  CONSTRAINT `fk_payroll_runs_period` FOREIGN KEY (`period_id`) REFERENCES `payroll_periods` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_payroll_runs_processed_by` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_runs`
--

LOCK TABLES `payroll_runs` WRITE;
/*!40000 ALTER TABLE `payroll_runs` DISABLE KEYS */;
INSERT INTO `payroll_runs` VALUES
(1,6,1,1,'2026-03-11 13:54:05',0.00,0.00,0.00,'draft',NULL,NULL,'2026-03-11 13:54:05','2026-03-11 13:54:05'),
(2,6,2,1,'2026-03-11 18:32:48',0.00,0.00,0.00,'draft',NULL,NULL,'2026-03-11 18:32:48','2026-03-11 18:32:48'),
(3,6,11,1,'2026-03-14 16:42:20',0.00,0.00,0.00,'draft',NULL,NULL,'2026-03-14 16:42:20','2026-03-14 16:42:20');
/*!40000 ALTER TABLE `payroll_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_salary_grades`
--

DROP TABLE IF EXISTS `payroll_salary_grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_salary_grades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `grade_name` varchar(100) NOT NULL,
  `basic_salary` decimal(10,2) NOT NULL,
  `house_allowance` decimal(10,2) DEFAULT 0.00,
  `transport_allowance` decimal(10,2) DEFAULT 0.00,
  `medical_allowance` decimal(10,2) DEFAULT 0.00,
  `other_allowances` decimal(10,2) DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_grade_school` (`school_id`,`grade_name`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_salary_grades`
--

LOCK TABLES `payroll_salary_grades` WRITE;
/*!40000 ALTER TABLE `payroll_salary_grades` DISABLE KEYS */;
INSERT INTO `payroll_salary_grades` VALUES
(1,6,'subject teacher',150000.00,0.00,0.00,0.00,0.00,'',1,'2026-03-11 04:57:11','2026-03-11 04:57:11'),
(2,6,'class teacher',180000.00,0.00,0.00,0.00,0.00,'',1,'2026-03-11 04:57:57','2026-03-11 04:57:57');
/*!40000 ALTER TABLE `payroll_salary_grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_slips`
--

DROP TABLE IF EXISTS `payroll_slips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_slips` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `payroll_run_id` int(10) unsigned NOT NULL,
  `employee_id` int(10) unsigned NOT NULL,
  `gross_salary` decimal(10,2) NOT NULL,
  `total_allowances` decimal(10,2) DEFAULT 0.00,
  `total_deductions` decimal(10,2) DEFAULT 0.00,
  `net_salary` decimal(10,2) NOT NULL,
  `payment_method` enum('bank_transfer','cash','cheque') DEFAULT 'bank_transfer',
  `payment_status` enum('pending','paid','failed') DEFAULT 'pending',
  `payment_date` date DEFAULT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `pdf_path` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_payroll_run` (`payroll_run_id`),
  KEY `idx_employee` (`employee_id`),
  CONSTRAINT `fk_payroll_slips_employee` FOREIGN KEY (`employee_id`) REFERENCES `payroll_employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_payroll_slips_payroll_run` FOREIGN KEY (`payroll_run_id`) REFERENCES `payroll_runs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_slips`
--

LOCK TABLES `payroll_slips` WRITE;
/*!40000 ALTER TABLE `payroll_slips` DISABLE KEYS */;
INSERT INTO `payroll_slips` VALUES
(1,6,1,2,0.00,0.00,0.00,0.00,'bank_transfer','pending',NULL,NULL,NULL,NULL,'2026-03-11 13:54:05','2026-03-11 13:54:05'),
(2,6,1,4,0.00,0.00,0.00,0.00,'bank_transfer','pending',NULL,NULL,NULL,NULL,'2026-03-11 13:54:05','2026-03-11 13:54:05'),
(3,6,1,5,0.00,0.00,0.00,0.00,'bank_transfer','pending',NULL,NULL,NULL,NULL,'2026-03-11 13:54:05','2026-03-11 13:54:05'),
(4,6,2,2,0.00,0.00,0.00,0.00,'bank_transfer','pending',NULL,NULL,NULL,NULL,'2026-03-11 18:32:48','2026-03-11 18:32:48'),
(5,6,2,4,0.00,0.00,0.00,0.00,'bank_transfer','pending',NULL,NULL,NULL,NULL,'2026-03-11 18:32:48','2026-03-11 18:32:48'),
(6,6,2,5,0.00,0.00,0.00,0.00,'bank_transfer','pending',NULL,NULL,NULL,NULL,'2026-03-11 18:32:48','2026-03-11 18:32:48'),
(7,6,2,7,0.00,0.00,0.00,0.00,'bank_transfer','pending',NULL,NULL,NULL,NULL,'2026-03-11 18:32:48','2026-03-11 18:32:48'),
(8,6,3,2,0.00,0.00,0.00,0.00,'bank_transfer','pending',NULL,NULL,NULL,NULL,'2026-03-14 16:42:20','2026-03-14 16:42:20'),
(9,6,3,4,0.00,0.00,0.00,0.00,'bank_transfer','pending',NULL,NULL,NULL,NULL,'2026-03-14 16:42:20','2026-03-14 16:42:20'),
(10,6,3,5,0.00,0.00,0.00,0.00,'bank_transfer','pending',NULL,NULL,NULL,NULL,'2026-03-14 16:42:20','2026-03-14 16:42:20'),
(11,6,3,7,0.00,0.00,0.00,0.00,'bank_transfer','pending',NULL,NULL,NULL,NULL,'2026-03-14 16:42:20','2026-03-14 16:42:20'),
(12,6,3,8,0.00,0.00,0.00,0.00,'bank_transfer','pending',NULL,NULL,NULL,NULL,'2026-03-14 16:42:20','2026-03-14 16:42:20'),
(13,6,3,9,0.00,0.00,0.00,0.00,'bank_transfer','pending',NULL,NULL,NULL,NULL,'2026-03-14 16:42:20','2026-03-14 16:42:20'),
(14,6,3,10,0.00,0.00,0.00,0.00,'bank_transfer','pending',NULL,NULL,NULL,NULL,'2026-03-14 16:42:20','2026-03-14 16:42:20');
/*!40000 ALTER TABLE `payroll_slips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `performance_metrics`
--

DROP TABLE IF EXISTS `performance_metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_metrics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `metric_type` enum('api_response','page_load','query_time','memory_usage','cpu_usage') NOT NULL,
  `endpoint` varchar(500) DEFAULT NULL,
  `value` decimal(10,4) NOT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `sample_count` int(10) DEFAULT 1,
  `min_value` decimal(10,4) DEFAULT NULL,
  `max_value` decimal(10,4) DEFAULT NULL,
  `avg_value` decimal(10,4) DEFAULT NULL,
  `p95_value` decimal(10,4) DEFAULT NULL,
  `metadata` text DEFAULT NULL COMMENT 'JSON encoded metadata',
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_metric_type` (`metric_type`),
  KEY `idx_recorded_at` (`recorded_at`),
  KEY `idx_school_metric` (`school_id`,`metric_type`,`recorded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `performance_metrics`
--

LOCK TABLES `performance_metrics` WRITE;
/*!40000 ALTER TABLE `performance_metrics` DISABLE KEYS */;
/*!40000 ALTER TABLE `performance_metrics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rate_limits`
--

DROP TABLE IF EXISTS `rate_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rate_limits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `endpoint` varchar(500) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `request_count` int(10) DEFAULT 1,
  `limit_reached` tinyint(1) DEFAULT 0,
  `first_request` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_request` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `window_reset` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_rate_limit` (`school_id`,`endpoint`,`ip_address`,`user_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_endpoint` (`endpoint`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_window_reset` (`window_reset`),
  KEY `idx_school_endpoint_ip` (`school_id`,`endpoint`,`ip_address`,`last_request`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rate_limits`
--

LOCK TABLES `rate_limits` WRITE;
/*!40000 ALTER TABLE `rate_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `rate_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recovery_points`
--

DROP TABLE IF EXISTS `recovery_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recovery_points` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `backup_id` int(10) unsigned DEFAULT NULL,
  `point_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `recovery_type` enum('full','partial','data_only','schema_only') DEFAULT 'full',
  `tables_included` text DEFAULT NULL COMMENT 'JSON array of tables',
  `status` enum('available','restoring','restored','failed') DEFAULT 'available',
  `file_path` varchar(500) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `checksum` varchar(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `restored_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backup_id` (`backup_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_school_status` (`school_id`,`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recovery_points`
--

LOCK TABLES `recovery_points` WRITE;
/*!40000 ALTER TABLE `recovery_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `recovery_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_cards`
--

DROP TABLE IF EXISTS `report_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_cards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `academic_year_id` int(10) unsigned NOT NULL,
  `academic_term_id` int(10) unsigned DEFAULT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `generated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `file_path` varchar(500) DEFAULT NULL,
  `is_published` tinyint(1) DEFAULT 0,
  `published_by` int(10) unsigned DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_year` (`academic_year_id`),
  KEY `idx_term` (`academic_term_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_published_by` (`published_by`),
  CONSTRAINT `fk_report_cards_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_report_cards_published_by` FOREIGN KEY (`published_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_report_cards_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_report_cards_term` FOREIGN KEY (`academic_term_id`) REFERENCES `academic_terms` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_report_cards_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_cards`
--

LOCK TABLES `report_cards` WRITE;
/*!40000 ALTER TABLE `report_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `permissions` text DEFAULT NULL,
  `is_system` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_role_school` (`school_id`,`slug`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,6,'Super Administrator','super_admin','Has full access to all features','[\"*\"]',1,'2026-02-18 17:11:36'),
(2,6,'School Administrator','school_admin','Manages school operations','[\"dashboard.view\", \"students.*\", \"teachers.*\", \"classes.*\", \"attendance.*\", \"exams.*\", \"fees.*\", \"reports.*\", \"settings.*\"]',1,'2026-02-18 17:11:36'),
(3,6,'Teacher','teacher','Can manage classes and students','[\"dashboard.view\", \"attendance.mark\", \"grades.enter\", \"homework.*\", \"students.view\"]',1,'2026-02-18 17:11:36'),
(4,6,'Student','student','Can view their own information','[\"dashboard.view\", \"timetable.view\", \"grades.view\", \"homework.view\"]',1,'2026-02-18 17:11:36'),
(5,6,'Parent','parent','Can view child information','[\"dashboard.view\", \"children.view\", \"attendance.view\", \"fees.view\"]',1,'2026-02-18 17:11:36'),
(6,6,'Accountant','accountant','Manages financial operations','[\"dashboard.view\", \"fees.*\", \"payments.*\", \"invoices.*\", \"reports.financial\"]',1,'2026-02-18 17:11:36'),
(7,6,'Librarian','librarian','Manages library operations','[\"dashboard.view\", \"library.*\"]',1,'2026-02-18 17:11:36');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `room_number` varchar(50) DEFAULT NULL,
  `capacity` int(10) unsigned DEFAULT 40,
  `class_teacher_id` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_section_class` (`class_id`,`code`),
  KEY `class_teacher_id` (`class_teacher_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_class` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES
(1,6,1,'section a','a','A101',20,NULL,1,'2026-03-04 20:30:38'),
(2,6,2,'afternoon','noon','b202',19,NULL,1,'2026-03-05 18:34:35'),
(3,6,3,'evening','e','c303',16,NULL,1,'2026-03-06 08:02:10'),
(4,6,12,'Section A','A','A101',20,NULL,1,'2026-03-09 11:54:33'),
(5,6,4,'Section A','A','101',12,18,1,'2026-03-12 09:47:57'),
(6,6,12,'section b','SEc B','',20,20,1,'2026-03-12 09:57:10');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_logs`
--

DROP TABLE IF EXISTS `security_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned DEFAULT NULL,
  `event_type` enum('login_attempt','failed_login','password_change','session_start','session_end','suspicious_activity','blocked_ip') NOT NULL,
  `severity` enum('low','medium','high','critical') DEFAULT 'low',
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `resolved` tinyint(1) DEFAULT 0,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolved_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_severity` (`severity`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_school_event` (`school_id`,`event_type`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_logs`
--

LOCK TABLES `security_logs` WRITE;
/*!40000 ALTER TABLE `security_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(50) DEFAULT 'string',
  `category` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_setting` (`school_id`,`key`),
  KEY `idx_school` (`school_id`),
  KEY `idx_key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
(1,6,'school_name','bitflux wallet','string','general','2026-02-18 17:11:36','2026-03-03 14:08:57'),
(2,6,'school_email','safebit99@gmail.com','string','general','2026-02-18 17:11:36','2026-03-03 14:08:57'),
(3,6,'school_phone','+18119999755','string','general','2026-02-18 17:11:36','2026-03-03 14:08:57'),
(4,6,'school_address','','string','general','2026-02-18 17:11:36','2026-02-18 17:11:36'),
(5,6,'currency','NGN','string','financial','2026-02-18 17:11:36','2026-03-03 14:08:57'),
(6,6,'currency_symbol','₦','string','financial','2026-02-18 17:11:36','2026-02-18 17:11:36'),
(7,6,'attendance_method','daily','string','academic','2026-02-18 17:11:36','2026-02-18 17:11:36'),
(8,6,'grading_system','percentage','string','academic','2026-02-18 17:11:36','2026-02-18 17:11:36'),
(9,6,'result_publish','immediate','string','academic','2026-02-18 17:11:36','2026-02-18 17:11:36'),
(10,6,'fee_due_days','30','number','financial','2026-02-18 17:11:36','2026-02-18 17:11:36'),
(11,6,'late_fee_percentage','5','number','financial','2026-02-18 17:11:36','2026-02-18 17:11:36'),
(12,6,'address','123 walkers street123 walkers street','string',NULL,'2026-03-03 13:55:58','2026-03-03 14:08:57'),
(13,6,'city','new york','string',NULL,'2026-03-03 13:55:58','2026-03-03 14:08:57'),
(14,6,'state','Abia','string',NULL,'2026-03-03 13:55:58','2026-03-03 14:08:57'),
(15,6,'country','Nigeria','string',NULL,'2026-03-03 13:55:58','2026-03-03 14:08:57'),
(16,6,'postal_code','40012','string',NULL,'2026-03-03 13:55:58','2026-03-03 14:08:57'),
(17,6,'timezone','Africa/Lagos','string',NULL,'2026-03-03 13:55:58','2026-03-03 14:08:57'),
(18,6,'language','en','string',NULL,'2026-03-03 13:55:58','2026-03-03 14:08:57'),
(19,6,'school_description','tesztibg','string',NULL,'2026-03-03 13:55:58','2026-03-03 14:08:57'),
(20,6,'mission_statement','testing','string',NULL,'2026-03-03 14:07:41','2026-03-03 14:08:57'),
(21,6,'vision_statement','testig','string',NULL,'2026-03-03 14:07:41','2026-03-03 14:08:57');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sick_visits`
--

DROP TABLE IF EXISTS `sick_visits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sick_visits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `visit_date` date NOT NULL,
  `visit_time` time DEFAULT NULL,
  `symptoms` text NOT NULL,
  `temperature` decimal(4,2) DEFAULT NULL,
  `weight` decimal(5,2) DEFAULT NULL,
  `diagnosis` text DEFAULT NULL,
  `treatment` text DEFAULT NULL,
  `medication_given` text DEFAULT NULL,
  `referred_to` varchar(255) DEFAULT NULL,
  `follow_up_date` date DEFAULT NULL,
  `attended_by` int(10) unsigned DEFAULT NULL COMMENT 'User ID of nurse/doctor',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_date` (`visit_date`),
  KEY `idx_school` (`school_id`),
  KEY `fk_sick_visits_attended_by` (`attended_by`),
  CONSTRAINT `fk_sick_visits_attended_by` FOREIGN KEY (`attended_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_sick_visits_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sick_visits`
--

LOCK TABLES `sick_visits` WRITE;
/*!40000 ALTER TABLE `sick_visits` DISABLE KEYS */;
/*!40000 ALTER TABLE `sick_visits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_logs`
--

DROP TABLE IF EXISTS `sms_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `recipient` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `sender_id` varchar(20) DEFAULT NULL,
  `message_id` varchar(100) DEFAULT NULL,
  `status` enum('pending','sent','delivered','failed','undelivered') DEFAULT 'pending',
  `status_code` varchar(50) DEFAULT NULL,
  `status_message` text DEFAULT NULL,
  `cost` decimal(8,4) DEFAULT NULL,
  `units` int(10) DEFAULT NULL,
  `provider` varchar(50) DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `delivered_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_recipient` (`recipient`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_school_status` (`school_id`,`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_logs`
--

LOCK TABLES `sms_logs` WRITE;
/*!40000 ALTER TABLE `sms_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_attendance`
--

DROP TABLE IF EXISTS `staff_attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff_attendance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `date` date NOT NULL,
  `clock_in_time` timestamp NULL DEFAULT NULL,
  `clock_out_time` timestamp NULL DEFAULT NULL,
  `clock_in_lat` decimal(10,8) DEFAULT NULL,
  `clock_in_lng` decimal(11,8) DEFAULT NULL,
  `clock_out_lat` decimal(10,8) DEFAULT NULL,
  `clock_out_lng` decimal(11,8) DEFAULT NULL,
  `clock_in_ip` varchar(45) DEFAULT NULL,
  `clock_out_ip` varchar(45) DEFAULT NULL,
  `clock_in_method` enum('manual','biometric','location','mobile') DEFAULT 'manual',
  `clock_out_method` enum('manual','biometric','location','mobile') DEFAULT 'manual',
  `status` enum('present','absent','late','half_day','holiday') DEFAULT 'present',
  `work_hours` decimal(5,2) GENERATED ALWAYS AS (timestampdiff(HOUR,`clock_in_time`,`clock_out_time`)) STORED COMMENT 'Calculated work hours',
  `approved_by` int(10) unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_staff_attendance` (`user_id`,`date`),
  KEY `idx_school` (`school_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_date` (`date`),
  KEY `idx_status` (`status`),
  KEY `idx_approved_by` (`approved_by`),
  KEY `idx_clock_in_coords` (`clock_in_lat`,`clock_in_lng`),
  KEY `idx_clock_out_coords` (`clock_out_lat`,`clock_out_lng`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_attendance`
--

LOCK TABLES `staff_attendance` WRITE;
/*!40000 ALTER TABLE `staff_attendance` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage_usage`
--

DROP TABLE IF EXISTS `storage_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `storage_usage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `storage_type` enum('database','files','backups','attachments') NOT NULL,
  `used_bytes` bigint(20) DEFAULT 0,
  `limit_bytes` bigint(20) DEFAULT 1073741824,
  `file_count` int(10) DEFAULT 0,
  `last_calculated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_school_storage` (`school_id`,`storage_type`),
  KEY `idx_school` (`school_id`),
  KEY `idx_type` (`storage_type`),
  KEY `idx_usage` (`used_bytes`),
  KEY `idx_school_type` (`school_id`,`storage_type`),
  KEY `idx_storage_usage_school_type` (`school_id`,`storage_type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storage_usage`
--

LOCK TABLES `storage_usage` WRITE;
/*!40000 ALTER TABLE `storage_usage` DISABLE KEYS */;
INSERT INTO `storage_usage` VALUES
(1,6,'database',0,1073741824,0,'2026-02-18 17:11:36','2026-02-18 17:11:36'),
(2,6,'files',0,1073741824,0,'2026-02-18 17:11:36','2026-02-18 17:11:36'),
(3,6,'backups',0,536870912,0,'2026-02-18 17:11:36','2026-02-18 17:11:36'),
(4,6,'attachments',0,536870912,0,'2026-02-18 17:11:36','2026-02-18 17:11:36');
/*!40000 ALTER TABLE `storage_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_health_records`
--

DROP TABLE IF EXISTS `student_health_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_health_records` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `blood_group` varchar(5) DEFAULT NULL,
  `allergies` text DEFAULT NULL,
  `chronic_conditions` text DEFAULT NULL,
  `disabilities` text DEFAULT NULL,
  `emergency_contact_name` varchar(255) DEFAULT NULL,
  `emergency_contact_phone` varchar(20) DEFAULT NULL,
  `emergency_contact_relation` varchar(50) DEFAULT NULL,
  `doctor_name` varchar(255) DEFAULT NULL,
  `doctor_phone` varchar(20) DEFAULT NULL,
  `doctor_address` text DEFAULT NULL,
  `insurance_provider` varchar(255) DEFAULT NULL,
  `insurance_policy` varchar(100) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_student` (`student_id`),
  KEY `idx_school` (`school_id`),
  CONSTRAINT `fk_student_health_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_health_records`
--

LOCK TABLES `student_health_records` WRITE;
/*!40000 ALTER TABLE `student_health_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_health_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_promotions`
--

DROP TABLE IF EXISTS `student_promotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_promotions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `from_academic_year_id` int(10) unsigned NOT NULL,
  `to_academic_year_id` int(10) unsigned NOT NULL,
  `from_class_id` int(10) unsigned NOT NULL,
  `to_class_id` int(10) unsigned NOT NULL,
  `from_section_id` int(10) unsigned DEFAULT NULL,
  `to_section_id` int(10) unsigned DEFAULT NULL,
  `from_campus_id` int(10) unsigned DEFAULT NULL,
  `to_campus_id` int(10) unsigned DEFAULT NULL,
  `promotion_date` date NOT NULL,
  `remarks` text DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_from_academic_year` (`from_academic_year_id`),
  KEY `idx_to_academic_year` (`to_academic_year_id`),
  KEY `idx_from_class` (`from_class_id`),
  KEY `idx_to_class` (`to_class_id`),
  KEY `idx_from_section` (`from_section_id`),
  KEY `idx_to_section` (`to_section_id`),
  KEY `idx_from_campus` (`from_campus_id`),
  KEY `idx_to_campus` (`to_campus_id`),
  KEY `idx_created_by` (`created_by`),
  CONSTRAINT `fk_student_promotions_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_student_promotions_from_campus` FOREIGN KEY (`from_campus_id`) REFERENCES `campuses` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_student_promotions_from_class` FOREIGN KEY (`from_class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_student_promotions_from_section` FOREIGN KEY (`from_section_id`) REFERENCES `sections` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_student_promotions_from_year` FOREIGN KEY (`from_academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_student_promotions_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_student_promotions_to_campus` FOREIGN KEY (`to_campus_id`) REFERENCES `campuses` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_student_promotions_to_class` FOREIGN KEY (`to_class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_student_promotions_to_section` FOREIGN KEY (`to_section_id`) REFERENCES `sections` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_student_promotions_to_year` FOREIGN KEY (`to_academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_promotions`
--

LOCK TABLES `student_promotions` WRITE;
/*!40000 ALTER TABLE `student_promotions` DISABLE KEYS */;
INSERT INTO `student_promotions` VALUES
(1,6,2,1,1,1,13,1,3,NULL,NULL,'2026-03-09','',1,'2026-03-09 22:58:02');
/*!40000 ALTER TABLE `student_promotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_transport`
--

DROP TABLE IF EXISTS `student_transport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_transport` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `assignment_id` int(10) unsigned NOT NULL,
  `stop_id` int(10) unsigned NOT NULL,
  `fee` decimal(10,2) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_student_transport` (`student_id`,`assignment_id`,`start_date`),
  KEY `idx_assignment` (`assignment_id`),
  KEY `idx_stop` (`stop_id`),
  KEY `idx_school_campus` (`school_id`,`campus_id`),
  CONSTRAINT `fk_student_transport_assignment` FOREIGN KEY (`assignment_id`) REFERENCES `transport_assignments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_student_transport_stop` FOREIGN KEY (`stop_id`) REFERENCES `transport_stops` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_student_transport_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_transport`
--

LOCK TABLES `student_transport` WRITE;
/*!40000 ALTER TABLE `student_transport` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_transport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `admission_number` varchar(50) NOT NULL,
  `roll_number` varchar(50) DEFAULT NULL,
  `class_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `admission_date` date NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `date_of_birth` date NOT NULL,
  `birth_place` varchar(255) DEFAULT NULL,
  `nationality` varchar(100) DEFAULT NULL,
  `mother_tongue` varchar(100) DEFAULT NULL,
  `current_address` text DEFAULT NULL,
  `permanent_address` text DEFAULT NULL,
  `previous_school` varchar(255) DEFAULT NULL,
  `previous_class` varchar(100) DEFAULT NULL,
  `transfer_certificate_no` varchar(100) DEFAULT NULL,
  `blood_group` varchar(5) DEFAULT NULL,
  `allergies` text DEFAULT NULL,
  `medical_conditions` text DEFAULT NULL,
  `doctor_name` varchar(255) DEFAULT NULL,
  `doctor_phone` varchar(20) DEFAULT NULL,
  `status` enum('active','inactive','graduated','transferred','withdrawn') DEFAULT 'active',
  `graduation_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `admission_number` (`admission_number`),
  KEY `user_id` (`user_id`),
  KEY `section_id` (`section_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_admission` (`admission_number`),
  KEY `idx_status` (`status`),
  KEY `idx_students_class_status` (`class_id`,`status`),
  KEY `idx_students_admission_date` (`admission_date`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES
(1,6,NULL,3,'BIT-2025-0001','3',1,1,'2026-03-05','favour','nzube','Zubetech','2020-03-05',NULL,NULL,NULL,'chokocho','etche','nobsams','ss3','null','A+','null','null','okafor','08033480654','active',NULL,'2026-03-05 12:59:28','2026-03-05 16:14:50'),
(2,6,NULL,5,'BIT-2025-0002','3',13,3,'2026-03-05','Bibi','Steph','Agundu','2006-10-05',NULL,NULL,NULL,'Umuchima','Etche','Damtoj','Ss3','2943283','O+','Dust','Ulcer','','','active',NULL,'2026-03-05 14:01:27','2026-03-09 22:58:02'),
(3,6,NULL,10,'BIT-2025-0003','4',2,2,'2026-03-06','Uzochukwu','Kosisochukwu','Jessica','2007-10-07',NULL,NULL,NULL,'eliozu portharcourt','2047 Walt Nuzum Farm Road','FGGC Abuloma','jss3','null','O+','null','null','','','active',NULL,'2026-03-06 07:52:59','2026-03-06 07:52:59'),
(4,6,NULL,14,'BIT-2025-0004','2',2,2,'2026-03-09','Allen','Firi','Faith','2006-06-23',NULL,NULL,NULL,'etche','igbo etech','International Unity School','JSS1','null','B+','null','null','','','active',NULL,'2026-03-09 10:14:57','2026-03-09 10:14:57'),
(5,6,NULL,16,'BIT-2025-0005','1',2,2,'2026-03-09','obinna','emmanuel','uzodinma','2006-03-09',NULL,NULL,NULL,'chokocho etche rivers state','etche','ulakwo primary school','primary 5','2005-3949','A-','null','null','','','active',NULL,'2026-03-09 11:30:05','2026-03-09 11:30:05'),
(14,6,NULL,37,'BIT-2025-0006','1',13,NULL,'2026-03-11','prosper','eche','checz','1998-09-02',NULL,NULL,NULL,'etche','chokocho\r\netche','Wisdom Gate','jss2','2098-2982','O+','null','null','','','active',NULL,'2026-03-11 07:12:33','2026-03-11 07:12:33'),
(21,6,NULL,65,'BIT-2025-0007','1',4,5,'2025-09-11','Uzochukwu','Chiemela','Victory','2023-11-02',NULL,NULL,NULL,'Igwuruta, Rivers State','Igwuruta, Rivers State','','','','','null','Asthma','','','active',NULL,'2026-03-12 10:28:06','2026-03-12 10:39:27'),
(22,6,NULL,66,'BIT-2025-0008','1',4,5,'2025-09-11','Unagbu','Chioma','Rita','2023-07-09',NULL,NULL,NULL,'Okomoko, Rivers State','Okomoko, Rivers State','','','','O-','null','null','','','active',NULL,'2026-03-12 10:33:48','2026-03-12 10:33:48'),
(23,6,NULL,68,'BIT-2025-0009','1',4,5,'2025-09-11','Okoye','Nwabuogo','Maryann','2023-04-08',NULL,NULL,NULL,'Igbo-Etche, Rivers State','Igbo-Etche, Rivers State','','','','','null','null','','','active',NULL,'2026-03-12 10:38:13','2026-03-12 10:39:00'),
(24,6,NULL,69,'BIT-2025-0010','1',4,5,'2025-09-11','Adeyemi','Toluwani','Hephzibah','2023-08-19',NULL,NULL,NULL,'Umuechem, Rivers State','Umuechem, Rivers State','','','','B+','null','null','',NULL,'active',NULL,'2026-03-12 10:43:02','2026-03-12 10:43:02'),
(25,6,NULL,70,'BIT-2025-0011','2',4,5,'2025-09-11','Adetifa','Mayorkun','Israel','2023-10-01',NULL,NULL,NULL,'Okomoko, Rivers State','Okomoko, Rivers State','','','','B-','null','null','',NULL,'active',NULL,'2026-03-12 10:50:43','2026-03-12 10:50:43'),
(26,6,NULL,71,'BIT-2025-0012','2',4,5,'2025-09-11','Ovieva','Oghenetega','Favour','2023-10-04',NULL,NULL,NULL,'Umuechem, Rivers State','Umuechem, Rivers State','','','','O-','null','null','',NULL,'active',NULL,'2026-03-12 10:57:28','2026-03-12 10:57:28'),
(27,6,NULL,72,'BIT-2025-0013','2',4,5,'2025-09-11','Tamuno','Biebele','Rejoice','2023-02-07',NULL,NULL,NULL,'Igbo-Etche, Rivers State','Igbo-Etche, Rivers State','','','','O-','null','null','',NULL,'active',NULL,'2026-03-12 11:00:17','2026-03-12 11:00:17'),
(28,6,NULL,73,'BIT-2025-0014','2',4,5,'2025-09-11','Bagshaw','Biobele','Joy','2023-05-12',NULL,NULL,NULL,'Igwuruta, Rivers State','Igwuruta, Rivers State','','','','B-','null','null','',NULL,'active',NULL,'2026-03-12 11:05:59','2026-03-12 11:05:59'),
(29,6,NULL,74,'BIT-2025-0015','3',4,5,'2025-09-11','Ogbuogu','Chibuenyim','Christopher','2023-04-06',NULL,NULL,NULL,'Umuechem, Rivers State','Umuechem, Rivers State','','','','O-','null','null','',NULL,'active',NULL,'2026-03-12 11:08:19','2026-03-12 11:08:19'),
(30,6,NULL,75,'BIT-2025-0016','3',4,5,'2025-09-11','Sylvester','Onyedikachi','Favour','2023-12-06',NULL,NULL,NULL,'Chokocho, Rivers State','Chokocho, Rivers State','','','','O+','null','null','',NULL,'active',NULL,'2026-03-12 11:11:28','2026-03-12 11:58:30'),
(31,6,NULL,76,'BIT-2025-0017','3',4,5,'2025-09-11','Okere','Iheanyi','Francis','2023-02-12',NULL,NULL,NULL,'Chokocho, Rivers State','Chokocho, Rivers State','','','','AB+','null','null','',NULL,'active',NULL,'2026-03-12 11:13:52','2026-03-12 11:13:52'),
(32,6,NULL,77,'BIT-2025-0018','3',4,5,'2025-09-11','Amadi','Kelechi','ThankGod','2023-03-12',NULL,NULL,NULL,'Umuchem, Rivers State','Umuchem, Rivers State','','','','AB+','null','null','',NULL,'active',NULL,'2026-03-12 11:21:26','2026-03-12 12:27:30'),
(33,6,NULL,81,'BIT-2025-0019','5',2,2,'2026-03-14','David','Chi','Aniago','2020-03-14',NULL,NULL,NULL,'Bom','Bag','Gh','R','34','O-','Null','Null','',NULL,'active',NULL,'2026-03-14 04:29:07','2026-03-24 08:15:08');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subjects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `type` enum('core','elective','extra_curricular') DEFAULT 'core',
  `description` text DEFAULT NULL,
  `credit_hours` decimal(4,1) DEFAULT 1.0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_subject_school` (`school_id`,`code`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES
(1,6,'mathematic','maths','core','easy',1.0,1,'2026-03-04 20:29:35'),
(2,6,'english','eng101','core','',1.0,1,'2026-03-05 18:34:56'),
(3,6,'Basic Science','BSc','core','',1.0,1,'2026-03-06 08:03:35'),
(4,6,'Basic Technnology','B.tech','core','',1.0,1,'2026-03-06 08:07:39'),
(5,6,'Creative and cultural art','CCA','core','',1.0,1,'2026-03-06 08:09:36'),
(6,6,'Civic Education','CEd','elective','',1.0,1,'2026-03-06 08:12:06'),
(7,6,'French','Frn','elective','',1.0,1,'2026-03-06 08:13:22'),
(8,6,'Igbo','IGB','elective','',1.0,1,'2026-03-06 08:14:34'),
(9,6,'Social Studies','SOS','core','',1.0,1,'2026-03-06 08:17:05'),
(10,6,'Yoruba','YOR','elective','',1.0,1,'2026-03-06 08:18:38'),
(11,6,'Hausa','HSA','elective','',1.0,1,'2026-03-06 08:19:09'),
(12,6,'Christian Religious Knowledge','CRK','elective','',1.0,1,'2026-03-06 08:20:53'),
(13,6,'History','HST','elective','',1.0,1,'2026-03-06 08:21:51'),
(14,6,'Geography','GEO','elective','',1.0,1,'2026-03-06 08:22:15'),
(15,6,'Chemistry','CHEM','core','',1.0,1,'2026-03-06 08:22:35'),
(16,6,'Biology ','BIO','core','',1.0,1,'2026-03-06 08:22:59'),
(17,6,'Physics','PHY','core','',1.0,1,'2026-03-06 08:23:31'),
(18,6,'Economics','ECO','elective','',1.0,1,'2026-03-06 08:24:40'),
(19,6,'Verbal Reasoning','VRB','elective','',1.0,1,'2026-03-06 08:26:30'),
(20,6,'Quantitative Reasoning ','QTR','elective','',1.0,1,'2026-03-06 08:28:51'),
(21,6,'Further Mathematics','F.Maths','elective','',1.0,1,'2026-03-06 08:34:22');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `plan_id` varchar(50) NOT NULL,
  `plan_name` varchar(100) NOT NULL,
  `status` enum('active','pending','cancelled','expired','past_due') DEFAULT 'pending',
  `billing_cycle` enum('monthly','quarterly','yearly') DEFAULT 'monthly',
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'NGN',
  `storage_limit` bigint(20) DEFAULT 1073741824,
  `user_limit` int(10) DEFAULT 100,
  `student_limit` int(10) DEFAULT 500,
  `features` text DEFAULT NULL COMMENT 'JSON encoded features',
  `current_period_start` date NOT NULL,
  `current_period_end` date NOT NULL,
  `cancel_at_period_end` tinyint(1) DEFAULT 0,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_school_subscription` (`school_id`),
  KEY `idx_status` (`status`),
  KEY `idx_period` (`current_period_end`),
  KEY `idx_school_plan` (`school_id`,`plan_id`),
  KEY `idx_subscriptions_status_end` (`status`,`current_period_end`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES
(1,6,'free_tier','Free Plan','active','monthly',0.00,'NGN',1073741824,100,500,NULL,'2026-02-18','2026-03-18',0,NULL,NULL,'2026-02-18 17:11:36','2026-02-18 17:11:36');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_alerts`
--

DROP TABLE IF EXISTS `system_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_alerts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `alert_type` enum('storage_limit','user_limit','subscription_expiry','payment_failed','performance_issue','security_issue','system_error') NOT NULL,
  `severity` enum('info','warning','error','critical') DEFAULT 'info',
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `data` text DEFAULT NULL COMMENT 'JSON encoded data',
  `is_resolved` tinyint(1) DEFAULT 0,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolved_by` int(10) unsigned DEFAULT NULL,
  `resolution_notes` text DEFAULT NULL,
  `acknowledged` tinyint(1) DEFAULT 0,
  `acknowledged_at` timestamp NULL DEFAULT NULL,
  `acknowledged_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_alert_type` (`alert_type`),
  KEY `idx_severity` (`severity`),
  KEY `idx_is_resolved` (`is_resolved`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_school_resolved` (`school_id`,`is_resolved`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_alerts`
--

LOCK TABLES `system_alerts` WRITE;
/*!40000 ALTER TABLE `system_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `teachers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `qualification` varchar(255) DEFAULT NULL,
  `specialization` varchar(255) DEFAULT NULL,
  `experience_years` int(10) unsigned DEFAULT NULL,
  `joining_date` date DEFAULT NULL,
  `leaving_date` date DEFAULT NULL,
  `salary_grade` varchar(50) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `bank_account` varchar(50) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_id` (`employee_id`),
  KEY `user_id` (`user_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_employee` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teachers`
--

LOCK TABLES `teachers` WRITE;
/*!40000 ALTER TABLE `teachers` DISABLE KEYS */;
INSERT INTO `teachers` VALUES
(3,6,9,'TCH-2026-8367','bsc','mathematic',1,'2026-03-06',NULL,NULL,'kuda','2032909568','23423',1),
(4,6,12,'TCH-2026-2653','bsc','Basic Technnology, Chemistry',5,'2026-03-06',NULL,NULL,'','','',1),
(5,6,17,'TCH-2026-3448','bsc','Christian Religious Knowledge, Civic Education',3,'2026-03-08',NULL,NULL,'','1874611392','',1),
(6,6,18,'TCH-2026-4791','Bsc','mathematic, Quantitative Reasoning ',2,'2026-03-02',NULL,NULL,'','','',1),
(7,6,19,'TCH-2026-0542','Bsc','Further Mathematics, mathematic, Physics',7,'2026-02-20',NULL,NULL,'','','',1),
(8,6,20,'TCH-2026-8371','Bsc','Basic Science, Basic Technnology, Biology ',9,'2023-03-13',NULL,NULL,'','','',1),
(9,6,39,'TCH-2026-8372','O level','Yoruba',1,'2026-03-12',NULL,NULL,'','','',1),
(10,6,78,'TCH-2026-8373','B.Sc','mathematic, Quantitative Reasoning ',7,'2019-04-12',NULL,NULL,'','','',1),
(11,6,79,'TCH-2026-8374','B.Ed','english, Social Studies, Verbal Reasoning',6,'2020-08-19',NULL,NULL,'','','',1),
(12,6,80,'TCH-2026-8375','B.Ed','Christian Religious Knowledge, Civic Education, Economics',8,'2020-07-10',NULL,NULL,'','','',1);
/*!40000 ALTER TABLE `teachers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetables`
--

DROP TABLE IF EXISTS `timetables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `timetables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `academic_year_id` int(10) unsigned NOT NULL,
  `academic_term_id` int(10) unsigned NOT NULL,
  `day` enum('monday','tuesday','wednesday','thursday','friday','saturday') NOT NULL,
  `period_number` int(10) unsigned NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `subject_id` int(10) unsigned NOT NULL,
  `teacher_id` int(10) unsigned NOT NULL,
  `room_number` varchar(50) DEFAULT NULL,
  `is_break` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_timetable` (`class_id`,`section_id`,`day`,`period_number`,`academic_year_id`),
  KEY `section_id` (`section_id`),
  KEY `academic_year_id` (`academic_year_id`),
  KEY `academic_term_id` (`academic_term_id`),
  KEY `subject_id` (`subject_id`),
  KEY `teacher_id` (`teacher_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_day` (`day`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetables`
--

LOCK TABLES `timetables` WRITE;
/*!40000 ALTER TABLE `timetables` DISABLE KEYS */;
INSERT INTO `timetables` VALUES
(1,6,2,NULL,1,2,'monday',1,'09:00:00','09:45:00',2,9,'A101',0,'2026-03-05 21:08:10'),
(2,6,2,NULL,1,2,'monday',2,'09:45:00','10:30:00',1,9,'R202',0,'2026-03-06 01:29:55'),
(3,6,12,NULL,1,2,'tuesday',3,'09:00:00','09:45:00',1,19,'A1',0,'2026-03-10 12:32:05'),
(4,6,2,NULL,1,2,'monday',3,'10:00:00','10:45:00',5,19,'D101',0,'2026-03-10 12:36:01');
/*!40000 ALTER TABLE `timetables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transport_assignments`
--

DROP TABLE IF EXISTS `transport_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transport_assignments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `vehicle_id` int(10) unsigned NOT NULL,
  `route_id` int(10) unsigned NOT NULL,
  `academic_term_id` int(10) unsigned NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `morning_driver` varchar(255) DEFAULT NULL,
  `evening_driver` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_assignment` (`vehicle_id`,`route_id`,`academic_term_id`,`start_date`),
  KEY `idx_route` (`route_id`),
  KEY `idx_term` (`academic_term_id`),
  KEY `idx_school_campus` (`school_id`,`campus_id`),
  CONSTRAINT `fk_transport_assignments_route` FOREIGN KEY (`route_id`) REFERENCES `transport_routes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_transport_assignments_term` FOREIGN KEY (`academic_term_id`) REFERENCES `academic_terms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_transport_assignments_vehicle` FOREIGN KEY (`vehicle_id`) REFERENCES `transport_vehicles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transport_assignments`
--

LOCK TABLES `transport_assignments` WRITE;
/*!40000 ALTER TABLE `transport_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `transport_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transport_routes`
--

DROP TABLE IF EXISTS `transport_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transport_routes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `route_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `start_point` varchar(255) NOT NULL,
  `end_point` varchar(255) NOT NULL,
  `distance_km` decimal(5,2) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_route` (`school_id`,`campus_id`,`route_name`),
  KEY `idx_school_campus` (`school_id`,`campus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transport_routes`
--

LOCK TABLES `transport_routes` WRITE;
/*!40000 ALTER TABLE `transport_routes` DISABLE KEYS */;
/*!40000 ALTER TABLE `transport_routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transport_stops`
--

DROP TABLE IF EXISTS `transport_stops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transport_stops` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `route_id` int(10) unsigned NOT NULL,
  `stop_name` varchar(100) NOT NULL,
  `address` text DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `stop_order` int(10) unsigned DEFAULT 0,
  `pickup_time` time DEFAULT NULL,
  `dropoff_time` time DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_route` (`route_id`),
  KEY `idx_school_campus` (`school_id`,`campus_id`),
  CONSTRAINT `fk_transport_stops_route` FOREIGN KEY (`route_id`) REFERENCES `transport_routes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transport_stops`
--

LOCK TABLES `transport_stops` WRITE;
/*!40000 ALTER TABLE `transport_stops` DISABLE KEYS */;
/*!40000 ALTER TABLE `transport_stops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transport_vehicles`
--

DROP TABLE IF EXISTS `transport_vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transport_vehicles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `campus_id` int(10) unsigned NOT NULL,
  `vehicle_number` varchar(50) NOT NULL,
  `registration_number` varchar(50) DEFAULT NULL,
  `type` enum('bus','van','car') DEFAULT 'bus',
  `capacity` int(10) unsigned NOT NULL,
  `driver_name` varchar(255) DEFAULT NULL,
  `driver_phone` varchar(20) DEFAULT NULL,
  `driver_license` varchar(100) DEFAULT NULL,
  `assistant_name` varchar(255) DEFAULT NULL,
  `assistant_phone` varchar(20) DEFAULT NULL,
  `insurance_expiry` date DEFAULT NULL,
  `fitness_expiry` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_vehicle` (`school_id`,`campus_id`,`vehicle_number`),
  KEY `idx_school_campus` (`school_id`,`campus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transport_vehicles`
--

LOCK TABLES `transport_vehicles` WRITE;
/*!40000 ALTER TABLE `transport_vehicles` DISABLE KEYS */;
/*!40000 ALTER TABLE `transport_vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_role` (`user_id`,`role_id`),
  KEY `role_id` (`role_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES
(1,1,2,'2026-02-18 17:11:36'),
(2,3,4,'2026-03-05 12:59:28'),
(3,4,5,'2026-03-05 12:59:29'),
(4,5,4,'2026-03-05 14:01:27'),
(5,6,5,'2026-03-05 14:01:27'),
(8,9,3,'2026-03-05 19:03:03'),
(9,10,4,'2026-03-06 07:52:59'),
(10,11,5,'2026-03-06 07:52:59'),
(11,12,3,'2026-03-06 08:28:09'),
(12,13,5,'2026-03-06 09:16:26'),
(13,14,4,'2026-03-09 10:14:57'),
(14,15,5,'2026-03-09 10:14:58'),
(15,16,4,'2026-03-09 11:30:05'),
(16,17,3,'2026-03-09 11:52:42'),
(17,18,3,'2026-03-09 12:23:49'),
(18,19,3,'2026-03-09 12:31:48'),
(19,20,3,'2026-03-09 12:46:31'),
(28,37,4,'2026-03-11 07:12:33'),
(29,38,5,'2026-03-11 07:12:33'),
(30,39,3,'2026-03-11 18:09:55'),
(37,52,5,'2026-03-12 09:19:07'),
(38,53,5,'2026-03-12 09:23:53'),
(39,54,5,'2026-03-12 09:27:54'),
(40,55,5,'2026-03-12 09:31:23'),
(41,56,5,'2026-03-12 09:36:58'),
(42,57,5,'2026-03-12 09:42:23'),
(43,58,5,'2026-03-12 09:47:16'),
(44,59,5,'2026-03-12 09:53:57'),
(45,60,5,'2026-03-12 09:58:00'),
(46,61,5,'2026-03-12 10:04:57'),
(47,62,5,'2026-03-12 10:14:39'),
(48,63,5,'2026-03-12 10:19:19'),
(49,65,4,'2026-03-12 10:28:06'),
(50,66,4,'2026-03-12 10:33:48'),
(51,68,4,'2026-03-12 10:38:13'),
(52,69,4,'2026-03-12 10:43:02'),
(53,70,4,'2026-03-12 10:50:43'),
(54,71,4,'2026-03-12 10:57:28'),
(55,72,4,'2026-03-12 11:00:17'),
(56,73,4,'2026-03-12 11:05:59'),
(57,74,4,'2026-03-12 11:08:19'),
(58,75,4,'2026-03-12 11:11:28'),
(59,76,4,'2026-03-12 11:13:52'),
(60,77,4,'2026-03-12 11:21:26'),
(61,78,3,'2026-03-12 12:45:51'),
(62,79,3,'2026-03-12 12:55:41'),
(63,80,3,'2026-03-12 13:11:43'),
(64,81,4,'2026-03-14 04:29:07'),
(65,82,5,'2026-03-14 04:29:07');
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` enum('admin','teacher','student','parent','accountant','librarian','receptionist') NOT NULL,
  `profile_photo` varchar(500) DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `blood_group` varchar(5) DEFAULT NULL,
  `religion` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone_verified_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `reset_token` varchar(100) DEFAULT NULL,
  `reset_token_expires` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_email_school` (`school_id`,`email`),
  UNIQUE KEY `unique_phone_school` (`school_id`,`phone`),
  KEY `idx_school` (`school_id`),
  KEY `idx_user_type` (`user_type`),
  KEY `idx_email` (`email`),
  KEY `idx_phone` (`phone`),
  KEY `idx_users_school_type` (`school_id`,`user_type`),
  KEY `idx_users_email_type` (`email`,`user_type`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,6,'bitflux wallet','safebit99@gmail.com','+18119999755',NULL,'$2y$12$6PMv0yocTPOo6Hv2zeDVAOgYVjinNSQN9ORGV4Fr3.FXhoRKeXawG','admin','/assets/uploads/profiles/6/profile_1_1773140938.jpg','male',NULL,'A+','chirstian',NULL,NULL,NULL,1,'2026-03-24 08:14:15','143.105.174.140',NULL,NULL,NULL,'2026-02-18 17:11:36','2026-03-24 08:14:15'),
(3,6,'favour nzube Zubetech','zubetechhub@gmail.com','09070525288','zubetechhub','$2y$12$etcmzezxAZD8lHAehh3vhutMcZnY7SccctdFzkyMv/ZEjm2mgdmyC','student',NULL,'male','2020-03-05',NULL,NULL,'chokocho',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-05 12:59:28','2026-03-05 16:14:50'),
(4,6,'hennry uzodima','zubetechhub3@gmail.com','07042424553','zubetechhub3','$2y$12$E7uW0cXDw0qc3gxlXac5jO99eiBLuTEY.9mdI/elGCT2ZULlv2KQe','parent',NULL,NULL,NULL,NULL,NULL,'chokocho\r\netche',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-05 12:59:29','2026-03-05 12:59:29'),
(5,6,'Bibi Steph Agundu','fs@gmail.com','080525288','fs','$2y$12$.cEjbQY0W1.fJRGa4.Y6reTfa.eLpK6jbyd/nuQbpTqYhAr0MI8tS','student',NULL,'female','2006-10-05',NULL,NULL,'Umuchima',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-05 14:01:27','2026-03-09 22:39:19'),
(6,6,'Fatima','fhj@gmail.con','0804344545','fhj','$2y$12$KZcSEtHnX3hLoNI2ySYNouAaK3lQJyTdiaVIQRYLN7o6AWKN74lay','parent',NULL,NULL,NULL,NULL,NULL,'Etch',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-05 14:01:27','2026-03-05 14:01:27'),
(9,6,'brook harry','favouruzodinma55@gmail.com','909888766','favouruzodinma55','$2y$12$OeWFDgIIIsggNMDfKBS9gOdRlHA4SBa4Qu8FofN8kUDI5Gu8MidzO','teacher',NULL,'male','1991-06-06',NULL,NULL,'Sbagha Bagha',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-05 19:03:03','2026-03-09 20:33:12'),
(10,6,'Uzochukwu Kosisochukwu Jessica','uzochukwukosisochukwu046@gmail.com','07041390038','uzochukwukosisochukwu046','$2y$12$x3tC9pzPLSQTRq7lGcfVp.R5otog2GdhTRR/l7Sks3ifCX72IRA02','student',NULL,'female','2007-10-07',NULL,NULL,'eliozu portharcourt',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-06 07:52:59','2026-03-09 05:24:15'),
(11,6,'Emezie Ngozi','ngozionyebuchin@gmail.com','07061052210','ngozionyebuchin','$2y$12$4XoRSauETseO/iwF6Jm0Webux3Tor3KGdEGKZmhX1rYQAnsz3w4G6','parent',NULL,NULL,NULL,NULL,NULL,'eliozu portharcourt',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-06 07:52:59','2026-03-06 07:52:59'),
(12,6,'Maxwell Acheampong','bitfluxwallet@gmail.com','8119999755','bitfluxwallet','$2y$12$ExUglz7CNZ2Tuv6CQS1IruzaYK6qvBJj5BzlRU5isy.uo.iCjBXam','teacher',NULL,'male','2026-03-19',NULL,NULL,'123 walkers street',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-06 08:28:09','2026-03-06 08:28:09'),
(13,6,'Emezie IKe','mutexia21@gmail.com','585-415-1576','mutexia21','$2y$12$VVpX7.y2GidgodEZtnIwReL1n7K908lXKhjmOpEHc3yDixJ.1Lx5S','parent',NULL,'male',NULL,NULL,NULL,'2047 Walt Nuzum Farm Road',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-06 09:16:26','2026-03-06 18:15:42'),
(14,6,'Allen Firi Faith','amina2006@gmail.com','0907052500','amina2006','$2y$12$CsfUsHH4jNtf/wgDc4ZFguUi2YZ7rtBKbNBB7Y1VTRKQIZk.v5.VG','student',NULL,'female','2006-06-23',NULL,NULL,'etche',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-09 10:14:57','2026-03-09 10:14:57'),
(15,6,'Allen Ateli','aminfather@gmail.com','07061052211','aminfather','$2y$12$WPbz1jJm0Htw9VO/eJW9QuhO/5cGhSvil2ZPMZvuokBjoypRzjTvq','parent',NULL,NULL,NULL,NULL,NULL,'chokocho\r\netche',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-09 10:14:58','2026-03-09 10:14:58'),
(16,6,'obinna emmanuel uzodinma','emmaobinna@gmail.com','08119999775','emmaobinna','$2y$12$CF6SRog7CuMGSFUScIqmNe5wR8PwZ5f/E.pLtUtWRbyqLdjdba6IK','student',NULL,'male','2006-03-09',NULL,NULL,'chokocho etche rivers state',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-09 11:30:05','2026-03-09 11:30:05'),
(17,6,'Samuel Sharon','samuelsharon@gmail.com','08144162281','samuelsharon','$2y$12$Y7vCJO91FjgGOSXAscIfL.5Khmmv3AsILCyQ9my2JStrCNuUEerq2','teacher',NULL,'female','2002-07-02',NULL,NULL,'Rumuodumaya, Rivers State.',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-09 11:52:42','2026-03-09 11:52:42'),
(18,6,'Ibim Dokubo Shannel','shannelibimdokubo@gmail.com','08177896543','shannelibimdokubo','$2y$12$t0oN2hkcHpLXkD/zM.t0bOgtC/3CPyK2R8mNliB0ZyPr6Fjcbnwtq','teacher',NULL,'female','2005-06-10',NULL,NULL,'AGIP, Port Harcourt',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-09 12:23:49','2026-03-09 12:23:49'),
(19,6,'Onyebuchi Maurice','mauricechukwunenye@gmail.com','07011432678','mauricechukwunenye','$2y$12$8yyhl9nRFOBhJh57cwPze.gim24hmxEbIWylDJ5o0mc8KfI02V.0y','teacher',NULL,'male','1999-04-26',NULL,NULL,'Rumuomasi, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-09 12:31:48','2026-03-09 12:31:48'),
(20,6,'Nwosu Jude','judejudon114@gmail.com','08076593005','judejudon114','$2y$12$.R9P2bwA34//vx.2EjlvWu6Rb/TLJ56vEAr0nrMuFGwikJPn8/QYi','teacher',NULL,'male','2002-08-19',NULL,NULL,'Amadi Road, Rivers State.',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-09 12:46:31','2026-03-09 12:46:31'),
(37,6,'prosper eche checz','prosper.checz@student.bitflux-wallet-1771434696','','prosper.checz','$2y$12$Jp7cMB/2z59nKsHxCYTSKeoY81joXU4XbvZzA7RBSEo7TquXgNzj6','student',NULL,'male','1998-09-02',NULL,NULL,'etche',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-11 07:12:33','2026-03-11 07:12:33'),
(38,6,'james checz','jameschecz@gmail.com','0908888288','jameschecz','$2y$12$BFY701JnjPeTGvTfPlgIVePvq6m.gj8EEtzAFGaMsb2WKeAbOZhRW','parent',NULL,NULL,NULL,NULL,NULL,'umuahia town , gae junction',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-11 07:12:33','2026-03-11 07:12:33'),
(39,6,'Solomon amaechi','solomon@gmail.com','08119999755','solomon','$2y$12$H43w.SxyNSMqMnsN5OWh5.5Ga1X9ug.Fx8c/VWm9Z8ht9fruK4xae','teacher',NULL,'male','1986-03-12',NULL,NULL,'',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-11 18:09:55','2026-03-11 18:09:55'),
(52,6,'Uzochukwu Uzomaka Rachael','uzoamakarach678@mail.com','707-308-9496','uzoamakarach678','$2y$12$kHwnaf8BstRkIC2Y/zVxXOEiSIlwN0vWYCF8ZhBTKVcHJ25ArptRO','parent',NULL,'female',NULL,NULL,NULL,'Igwuruta, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 09:19:07','2026-03-12 09:19:07'),
(53,6,'Unagbu Udochukwu Simon','unagbusimon098@gmail.com','707-571-2549','unagbusimon098','$2y$12$Ilp9omBZSgiGrwW4Js3u7uqt6gM2PoeHiTCz8OgyoSsYlMfNShTC2','parent',NULL,'male',NULL,NULL,NULL,'Okomoko, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 09:23:53','2026-03-12 09:23:53'),
(54,6,'Okoye Ifunnanya Jennifer','ifunnanyajenn09@gmail.com','706-105-2210','ifunnanyajenn09','$2y$12$HOHeUbsoimQr/TjwEdwTUOeiwCNiJeRUKwprSA5QeTU0ffGtpiruS','parent',NULL,'female',NULL,NULL,NULL,'Igbo-Etche, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 09:27:54','2026-03-12 09:27:54'),
(55,6,'Adeyemi Kehinde Joshua','adeyemijoshua@gmail.com','814-416-2281','adeyemijoshua','$2y$12$nkwcSLv6voJTGALPQ/rZ4eVUsjyzJndAkvCiUjxuHeGHDxDDsOdHC','parent',NULL,'male',NULL,NULL,NULL,'Umuechem, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 09:31:23','2026-03-12 09:31:23'),
(56,6,'Adetifa Ayomide Shedrach','sheddytifa1972@gmail.com','700-896-9436','sheddytifa1972','$2y$12$DWH5XRmVFeQFounCU5tbQe5wX4sWJFO9DxcP2JfK8QAWtYioE0/OK','parent',NULL,'male',NULL,NULL,NULL,'Okomoko, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 09:36:58','2026-03-12 09:36:58'),
(57,6,'Ovieva Oghenerukevwe Simona','oghenerukevwemona@gmail.com','814-415-7784','oghenerukevwemona','$2y$12$INnZWnty3ynADfPiQQX7XO/w1WkqiyNVKP0GOVXgcWhu8OOAsj3IK','parent',NULL,'female',NULL,NULL,NULL,'Umuechem, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 09:42:23','2026-03-12 09:42:23'),
(58,6,'Pere Tokoni Joy','tokonipere001@gmail.com','911-846-0472','tokonipere001','$2y$12$j8yPextLjPlPHxa1FVeiZeWM5.75qJHJnhaOCO67Dwb1lPuglxHzq','parent',NULL,'female',NULL,NULL,NULL,'Igbo-Etche, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 09:47:16','2026-03-12 09:47:16'),
(59,6,'Bagshaw Boma Hephzibah','bomahephzibah@gmail.com','907-536-3889','bomahephzibah','$2y$12$jfMDRYlrezNOs3KEJjZ6M.wopXG0RJMnl5qnKNKeC3o8/UNJ4bB4S','parent',NULL,'female',NULL,NULL,NULL,'Igwuruta, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 09:53:57','2026-03-12 09:53:57'),
(60,6,'Ogbuogu Chukwuma Benson','bennchukss111@gmail.com','816-744-9957','bennchukss111','$2y$12$Cksmom5nSkgfkiJoQuRv9uF4Pr0Hj5zyxfz0ANW4rJDlS5O7cBqAG','parent',NULL,'male',NULL,NULL,NULL,'Umuechem, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 09:58:00','2026-03-12 09:58:00'),
(61,6,'Sylvester Chioma Monica','monicachioma002@gmail.com','809-655-4738','monicachioma002','$2y$12$SXqHip5G8Cj.8gtRNjfyXeaos.HE8EiefrwkekTExX7kzqYe8LrbO','parent',NULL,'female',NULL,NULL,NULL,'Chokocho, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 10:04:57','2026-03-12 10:04:57'),
(62,6,'Okere Chiamaka Juliet','okerejuliet90@gmail.com','806-277-2775','okerejuliet90','$2y$12$tx6GGH3qTCHyznIRwZH3uOxHk7.juczlu5Z3VhbV2OnTpFHU5MAgu','parent',NULL,'female',NULL,NULL,NULL,'Chokocho, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 10:14:39','2026-03-12 10:14:39'),
(63,6,'Amadi Otonsiki Benita','otonsikibenita@gmail.com','708-966-5434','otonsikibenita','$2y$12$zG8o8JCp8uKZSsh3kQlreO1bfq3cgV/Vy.TTvD1suYHfhMuxV2JgC','parent',NULL,'female',NULL,NULL,NULL,'Umuechem, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 10:19:19','2026-03-12 10:19:19'),
(65,6,'Uzochukwu Chiemela Victory','zubuetechhub@gmail.com','09099926700','zubuetechhub','$2y$12$2yOOTUc.pHD3l2yFrF8H1OxXnCNKOrnWvJ78AsUEXlryhzG9C45kS','student',NULL,'female','2023-11-02',NULL,NULL,'Igwuruta, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 10:28:06','2026-03-12 10:39:27'),
(66,6,'Unagbu Chioma Rita','unagbusimon018@gmail.com','08172689365','unagbusimon018','$2y$12$i3WQ70MzdtNDCECfw.kW9O0XKiU/Twmpvrj86NTHKvnFTDvW.amC2','student',NULL,'female','2023-07-09',NULL,NULL,'Okomoko, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 10:33:48','2026-03-12 10:33:48'),
(68,6,'Okoye Nwabuogo Maryann','okoye.maryann@student.bitflux-wallet-1771434696.1773311892','08144162280','okoye.maryann','$2y$12$aoEJ6HM7wDrpjRmnHfqHce9JYko59e5jOVL.EvLOI1zNZo0WVfcN2','student',NULL,'female','2023-04-08',NULL,NULL,'Igbo-Etche, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 10:38:13','2026-03-12 10:39:00'),
(69,6,'Adeyemi Toluwani Hephzibah','adeyemi.hephzibah@student.bitflux-wallet-1771434696',NULL,'adeyemi.hephzibah','$2y$12$8ZyFUm9ULp1AF0Ng0iSCQ.Vy3pMCb6U8Hydcw1PAQcLeRj5wfPKbG','student',NULL,'female','2023-08-19',NULL,NULL,'Umuechem, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 10:43:02','2026-03-12 10:43:02'),
(70,6,'Adetifa Mayorkun Israel','adetifa.israel@student.bitflux-wallet-1771434696',NULL,'adetifa.israel','$2y$12$a9OWQLlexFbmbKIgSY7gO.YvcU/jZuHnyMrEA62ohrghNDl/sZrvu','student',NULL,'male','2023-10-01',NULL,NULL,'Okomoko, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 10:50:43','2026-03-12 10:50:43'),
(71,6,'Ovieva Oghenetega Favour','ovieva.favour@student.bitflux-wallet-1771434696',NULL,'ovieva.favour','$2y$12$H0tacIKF4uRDWBUtVd9bkuI0.oYnXg0mFNdebK1kjNdCgmVT9k/A.','student',NULL,'male','2023-10-04',NULL,NULL,'Umuechem, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 10:57:28','2026-03-12 10:57:28'),
(72,6,'Tamuno Biebele Rejoice','tamuno.rejoice@student.bitflux-wallet-1771434696',NULL,'tamuno.rejoice','$2y$12$Kl/K20kyMwu6j50KCFjzPOHOLi.O.8G3SrtXp9swVrkQGch3nL2O.','student',NULL,'female','2023-02-07',NULL,NULL,'Igbo-Etche, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 11:00:17','2026-03-12 11:00:17'),
(73,6,'Bagshaw Biobele Joy','bagshaw.joy@student.bitflux-wallet-1771434696',NULL,'bagshaw.joy','$2y$12$985oMnOuu2swRQj6ypAxPObYWwcWd3.DD1Qt1r3YzfUH7rtqaIDke','student',NULL,'female','2023-05-12',NULL,NULL,'Igwuruta, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 11:05:59','2026-03-12 11:05:59'),
(74,6,'Ogbuogu Chibuenyim Christopher','ogbuogu.christopher@student.bitflux-wallet-1771434696',NULL,'ogbuogu.christopher','$2y$12$lyl9523khoV6JP2M23vY7e6UT5gwP5qzT7o4gMg/FbEzMg7J3kUbC','student',NULL,'male','2023-04-06',NULL,NULL,'Umuechem, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 11:08:19','2026-03-12 11:08:19'),
(75,6,'Sylvester Onyedikachi Favour','sylvester.favour@student.bitflux-wallet-1771434696',NULL,'sylvester.favour','$2y$12$g0YgpoDJAn6TbqBX48AQMeiH267H8jVnc4y3aOcn2rfFRaXt/KueS','student',NULL,'male','2023-12-06',NULL,NULL,'Chokocho, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 11:11:28','2026-03-12 11:58:30'),
(76,6,'Okere Iheanyi Francis','okere.francis@student.bitflux-wallet-1771434696',NULL,'okere.francis','$2y$12$aXIadlzJY3evDo5jW6WER.dEZexUA29uCpYhJh2hNKQ0.BwZcY1O.','student',NULL,'male','2023-02-12',NULL,NULL,'Chokocho, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 11:13:52','2026-03-12 11:13:52'),
(77,6,'Amadi Kelechi ThankGod','amadi.thankgod@student.bitflux-wallet-1771434696',NULL,'amadi.thankgod','$2y$12$Mvo8svR6c4pjSnDBVFgMIOT84nlM5KjlvFGEgretEgODz.EBM4Coa','student',NULL,'male','2023-03-12',NULL,NULL,'Umuchem, Rivers State',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 11:21:26','2026-03-12 12:27:30'),
(78,6,'Uzodinma Udochukwu Timothy','zubetechub@gmail.com','09070520000','zubetechub','$2y$12$71vU8NKmQD7CfxyHmSwjSeNFBZeOT/X0b.jgW90wV1PHJdtCirYK6','teacher',NULL,'male','2004-09-02',NULL,NULL,'chokocho',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 12:45:51','2026-03-12 12:45:51'),
(79,6,'Okpobiri Ijeoma Felicia','feliciaonyebuchi@gmail.com','08057646999','feliciaonyebuchi','$2y$12$j9BfqneG6xcEIbe.eVisBuYH7ediyCRFvnG1qYSMDHSVBdU1nkWAa','teacher',NULL,'female','1971-06-11',NULL,NULL,'chokocho',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 12:55:41','2026-03-12 12:55:41'),
(80,6,'Onyeuchi Nkechi Katherine','katrell009@gmail.com','08097667541','katrell009','$2y$12$6BC6HDk0jYlhSDbfzYHZhOtwxNvHAc1Tcgy4jJDohclnJiHL2p7/y','teacher',NULL,'female','1983-04-09',NULL,NULL,'chokocho',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-12 13:11:43','2026-03-12 13:11:43'),
(81,6,'David Chi Aniago','daveaniago91@gmail.com',NULL,'daveaniago91','$2y$12$8nD.OqSXGOi09Z3z0rZUkesQo8DDez5ozvlWukBueuRFUwjbAC/46','student',NULL,'male','2020-03-14',NULL,NULL,'Bom',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-14 04:29:07','2026-03-24 08:15:08'),
(82,6,'Beatrice','davidaniag78@gmail.com','023','davidaniag78','$2y$12$hok3rtwpm9EBKgl8mu9apu1YPiwVC6iFsxojIk3dzW91Sx9SPGOPe','parent',NULL,NULL,NULL,NULL,NULL,'Gu',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2026-03-14 04:29:07','2026-03-14 04:29:07');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vaccinations`
--

DROP TABLE IF EXISTS `vaccinations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vaccinations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `vaccine_name` varchar(100) NOT NULL,
  `date_administered` date NOT NULL,
  `next_due_date` date DEFAULT NULL,
  `administered_by` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_school` (`school_id`),
  CONSTRAINT `fk_vaccinations_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vaccinations`
--

LOCK TABLES `vaccinations` WRITE;
/*!40000 ALTER TABLE `vaccinations` DISABLE KEYS */;
/*!40000 ALTER TABLE `vaccinations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voting_candidates`
--

DROP TABLE IF EXISTS `voting_candidates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `voting_candidates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `election_id` int(10) unsigned NOT NULL,
  `position_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `manifesto` text DEFAULT NULL,
  `photo` varchar(500) DEFAULT NULL,
  `approved` tinyint(1) DEFAULT 0,
  `approved_by` int(10) unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_candidate` (`election_id`,`position_id`,`student_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_position` (`position_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_approved_by` (`approved_by`),
  CONSTRAINT `fk_voting_candidates_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_voting_candidates_election` FOREIGN KEY (`election_id`) REFERENCES `voting_elections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_voting_candidates_position` FOREIGN KEY (`position_id`) REFERENCES `voting_positions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_voting_candidates_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voting_candidates`
--

LOCK TABLES `voting_candidates` WRITE;
/*!40000 ALTER TABLE `voting_candidates` DISABLE KEYS */;
/*!40000 ALTER TABLE `voting_candidates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voting_elections`
--

DROP TABLE IF EXISTS `voting_elections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `voting_elections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `status` enum('upcoming','active','closed','archived') DEFAULT 'upcoming',
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_status` (`status`),
  KEY `idx_dates` (`start_date`,`end_date`),
  KEY `idx_created_by` (`created_by`),
  CONSTRAINT `fk_voting_elections_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voting_elections`
--

LOCK TABLES `voting_elections` WRITE;
/*!40000 ALTER TABLE `voting_elections` DISABLE KEYS */;
/*!40000 ALTER TABLE `voting_elections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voting_positions`
--

DROP TABLE IF EXISTS `voting_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `voting_positions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `election_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `eligibility_criteria` text DEFAULT NULL COMMENT 'JSON: e.g., {"class_id": 12, "min_grade": "10"}',
  `max_candidates` int(10) unsigned DEFAULT 1,
  `max_votes_per_voter` int(10) unsigned DEFAULT 1,
  `is_active` tinyint(1) DEFAULT 1,
  `order` int(10) unsigned DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_election` (`election_id`),
  CONSTRAINT `fk_voting_positions_election` FOREIGN KEY (`election_id`) REFERENCES `voting_elections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voting_positions`
--

LOCK TABLES `voting_positions` WRITE;
/*!40000 ALTER TABLE `voting_positions` DISABLE KEYS */;
/*!40000 ALTER TABLE `voting_positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voting_results`
--

DROP TABLE IF EXISTS `voting_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `voting_results` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `election_id` int(10) unsigned NOT NULL,
  `position_id` int(10) unsigned NOT NULL,
  `candidate_id` int(10) unsigned NOT NULL,
  `vote_count` int(10) unsigned NOT NULL DEFAULT 0,
  `percentage` decimal(5,2) DEFAULT NULL,
  `is_winner` tinyint(1) DEFAULT 0,
  `calculated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_result` (`election_id`,`position_id`,`candidate_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_election` (`election_id`),
  KEY `idx_position` (`position_id`),
  KEY `idx_candidate` (`candidate_id`),
  CONSTRAINT `fk_voting_results_candidate` FOREIGN KEY (`candidate_id`) REFERENCES `voting_candidates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_voting_results_election` FOREIGN KEY (`election_id`) REFERENCES `voting_elections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_voting_results_position` FOREIGN KEY (`position_id`) REFERENCES `voting_positions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voting_results`
--

LOCK TABLES `voting_results` WRITE;
/*!40000 ALTER TABLE `voting_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `voting_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voting_votes`
--

DROP TABLE IF EXISTS `voting_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `voting_votes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) unsigned NOT NULL,
  `election_id` int(10) unsigned NOT NULL,
  `position_id` int(10) unsigned NOT NULL,
  `candidate_id` int(10) unsigned NOT NULL,
  `voter_id` int(10) unsigned NOT NULL COMMENT 'Student ID of voter',
  `vote_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_vote` (`election_id`,`position_id`,`voter_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_election` (`election_id`),
  KEY `idx_position` (`position_id`),
  KEY `idx_candidate` (`candidate_id`),
  KEY `idx_voter` (`voter_id`),
  CONSTRAINT `fk_voting_votes_candidate` FOREIGN KEY (`candidate_id`) REFERENCES `voting_candidates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_voting_votes_election` FOREIGN KEY (`election_id`) REFERENCES `voting_elections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_voting_votes_position` FOREIGN KEY (`position_id`) REFERENCES `voting_positions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_voting_votes_voter` FOREIGN KEY (`voter_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voting_votes`
--

LOCK TABLES `voting_votes` WRITE;
/*!40000 ALTER TABLE `voting_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `voting_votes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-03-24  8:20:20
