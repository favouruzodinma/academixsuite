<!DOCTYPE html>
<html>
<head>
    <title>400 Bad Request</title>
</head>
<body>
    <h1>400 - Bad Request</h1>
    <p>Your request could not be processed.</p>
    <a href="/">Return to Homepage</a>
</body>
</html>